package com.gwstern.flipper;

import com.gwstern.flipper.util.IntCycle;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test the SQUARE enum.
 */
public class IntCycleTest {
    /**
     * Just some simple tests to make sure the enum is coded correctly
     */
    @Test
    public void IntCycleTests() {
        IntCycle cycle = new IntCycle(11);

        Assert.assertEquals(0, cycle.getCount());

        // Loop forward
        for (int i = 0; i < 11*4+1; i++) {
            int expected = cycle.checkNext();
            int actual = cycle.next();

            Assert.assertEquals(expected, actual);
        }
        Assert.assertEquals(1, cycle.getCount());

        // Loop backwards
        cycle.prev();
        Assert.assertEquals(0, cycle.getCount());

        for (int i = 0; i < 11*2; i++) {
            int expected = cycle.checkPrev();
            int actual = cycle.prev();

            Assert.assertEquals(expected, actual);
        }
        Assert.assertEquals(0, cycle.getCount());
    }
}
