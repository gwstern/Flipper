package com.gwstern.flipper;

import com.gwstern.flipper.game.SQUARE;

import org.junit.Test;
import org.junit.Assert;

/**
 * Test the SQUARE enum.
 */
public class SQUARETest {
    /**
     * Just some simple tests to make sure the enum is coded correctly
     */
    @Test
    public void EnumTests() {
        SQUARE se = SQUARE.EMPTY;
        SQUARE sl = SQUARE.LIGHT;
        SQUARE sd = SQUARE.DARK;
        SQUARE s;
        String actual;

        Assert.assertNotEquals(se, sl);
        Assert.assertNotEquals(se, sd);
        Assert.assertNotEquals(sl, sd);

        s = se;
        Assert.assertEquals(s, se);

        actual = s.toString();
        Assert.assertEquals("EMPTY", actual);

        s = sd;
        Assert.assertFalse (s.equals(se));
        Assert.assertFalse(s == se);

        s = SQUARE.map("EMPTY");
        Assert.assertEquals (s, se);
        s = SQUARE.map("LIGHT");
        Assert.assertEquals (s, sl);
        s = SQUARE.map("DARK");
        Assert.assertEquals (s, sd);
    }
}
