package com.gwstern.flipper;

import com.gwstern.flipper.database.IMyPropsDAO;
import com.gwstern.flipper.database.MyPropsHardcodeImpl;
import com.gwstern.flipper.database.MyPropsSerializeImpl;
import com.gwstern.flipper.toolbar.SETTING_KEYS;
import com.gwstern.flipper.util.MyProps;

import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Test the MyProps Property replacement
 */
public class IMyPropsDAOTest {
    private static final String NEW_NAME = "This name won't ever exist in the application";
    private static final SETTING_KEYS[] EXPECTED_KEYS = {
            SETTING_KEYS.PLAYER1_TYPE,
            SETTING_KEYS.PLAYER1_NAME,
            SETTING_KEYS.PLAYER1_ICON,
            SETTING_KEYS.PLAYER2_TYPE,
            SETTING_KEYS.PLAYER2_NAME,
            SETTING_KEYS.PLAYER2_ICON,
            SETTING_KEYS.PLAYER1_LEVEL,
            SETTING_KEYS.PLAYER2_LEVEL,
            SETTING_KEYS.FORCE_CAPTURE,
            SETTING_KEYS.START_WITH_4,
            SETTING_KEYS.DAYS_UNTIL_PROMPT,
            SETTING_KEYS.LAUNCHES_UNTIL_PROMPT,
            SETTING_KEYS.PREF_NAME,
            SETTING_KEYS.DSA_KEY,
            SETTING_KEYS.LAUNCH_COUNT_KEY,
            SETTING_KEYS.DATE_KEY,
    };
    private HashSet<SETTING_KEYS> _expected_keys = new HashSet<>(Arrays.asList(EXPECTED_KEYS));

    /**
     * Test that the hardcoded MyProps works
     */
    @Test
    public void HardcodeImplTests() {
        IMyPropsDAO myprops_dao = new MyPropsHardcodeImpl();
        MyProps<SETTING_KEYS> actual = myprops_dao.getAll();

        // Values might change as the program develops so we'll simply check
        // that all the keys exist.
        Assert.assertEquals(_expected_keys, actual.keySet());

        // Test that MyProps isn't saved (remember, this is simply hardcoded data)
        // but we always want to test assumptions.
        actual.put(SETTING_KEYS.PLAYER1_NAME, NEW_NAME);

        myprops_dao.saveAll(actual);

        // Just confirming - don't want to discover the reason this works is
        // because clear() wasn't working as _expected_keys.
        actual.clear();
        Assert.assertEquals(0, actual.keySet().size());

        actual = myprops_dao.getAll();
        Assert.assertNotEquals(actual.get(SETTING_KEYS.PLAYER1_NAME), NEW_NAME);
    }

    /**
     * Test that the serialized MyProps works
     */
    @Test
    public void SerializedImplTests() {
        IMyPropsDAO myprops_dao = new MyPropsSerializeImpl();
        MyProps<SETTING_KEYS> actual;
        MyProps<SETTING_KEYS> expected;
        MyProps<SETTING_KEYS> save = myprops_dao.getAll();

        myprops_dao.reset();

        // Values might change as the program develops so we'll simply check
        // that all the keys exist.
        actual = myprops_dao.getAll();
        expected = myprops_dao.getAll();
        Assert.assertEquals(_expected_keys, actual.keySet());

        // Make changes to the values
        actual.put(SETTING_KEYS.PLAYER1_NAME, NEW_NAME);
        actual.put(SETTING_KEYS.PLAYER2_NAME, NEW_NAME);
        actual.put(SETTING_KEYS.PREF_NAME, NEW_NAME);
        myprops_dao.saveAll(actual);

        // Values should be loaded
        MyProps<SETTING_KEYS> actual2 = myprops_dao.getAll();
        Assert.assertFalse(actual.equals(expected));
        Assert.assertTrue(actual.equals(actual2));

        // Restore the original values
        myprops_dao.saveAll(save);
    }
}
