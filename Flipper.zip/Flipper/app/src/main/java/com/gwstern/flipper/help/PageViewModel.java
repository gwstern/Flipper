package com.gwstern.flipper.help;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import android.content.res.Resources;

import com.gwstern.flipper.R;
import com.gwstern.flipper.util.MyLog;

import java.util.List;

/**
 * Handles the data that will be displayed. Invoked whenever the needed by the
 * appropriate UI lifecycle stage.
 */
public class PageViewModel extends ViewModel {
    // The holder class for data. Handles things like changing data and UI lifecycles
    private MutableLiveData<String> _data;

    /**
     * Depending on which page is asked for return the appropriate list.
     *
     * @param index Which page is asking for its' data.
     */
    public void setPage(Resources resources, int index) {
        MyLog.d("PageViewModel.setPage (" + resources + "," + index + ")");

        if (_data == null) {
            MyLog.d("Initial load");

            List<String> l;

            _data = new MutableLiveData<>();

            switch (index) {
                case 0:
                    break;
                case 1:
                    _data.setValue(resources.getString(R.string.help_page_2));
                    break;
                case 2:
                    _data.setValue(resources.getString(R.string.help_page3_text));
                    break;

                default: // Should never get here
                    MyLog.wtf("Page #" + index + " found but only [0-2] was expected");
                    break;
            }
        }
    }

    /**
     * Return the data for this ViewModel.
     *
     * @return The data.
     */
    public LiveData<String> getHelp() {
        MyLog.d("PageViewModel.getHelp ()");

        return _data;
    }
}
