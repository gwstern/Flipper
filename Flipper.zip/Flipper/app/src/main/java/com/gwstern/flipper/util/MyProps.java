package com.gwstern.flipper.util;

import android.os.Parcel;
import android.os.Parcelable;

import com.gwstern.flipper.toolbar.SETTING_KEYS;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Nothing more than a simple wrapper around Properties. I do this because:
 * 1) I don't have to cast in get (no longer needed in Java).
 * i.e. props.set ((SETTING_KEY)key, (String)value);
 * 2) I don't have to cast in put.
 * i.e. String value = props.get (SETTING_KEY.KEY).toString();
 * 3) Since Properties all have to be Strings declaring methods to
 * take String reduces casting.
 * <p>
 * It implements Iterable because I like to iterate over things.
 * <p>
 * It implements Parcelable because it's Android's recommend way of passing
 * complex classes via Intent.
 */
public class MyProps<T> implements Iterable<Map.Entry<T, String>>, Parcelable, Serializable {

    private HashMap<T, String> _props = new HashMap<>();

    /**
     * Default constructor
     */
    public MyProps() {
    }

    /**
     * Put a key/value into the properties hash.
     *
     * @param key   The key (only T are allowed).
     * @param value The value (only strings are allowed).
     */
    public void put(T key, String value) {
        _props.put(key, value);
    }

    /**
     * Put everything from props into this instance - @see java.util.Hashtable#putAll(Map) ()
     *
     * @param props key/value pairs to be stored.
     */
    public void putAll(MyProps<T> props) {
        for (Map.Entry<T, String> item : props) {
            _props.put(item.getKey(), item.getValue());
        }
    }

    /**
     * Retrieve the value associated with the passed key.
     *
     * @param key The key to look for.
     * @return The value of the key or null if it wasn't found.
     */
    public String get(T key) {
        return (_props.get(key));
    }

    /**
     * Returns the number of keys in this HashMap.
     *
     * @return THe number of keys.
     */
    public int size() {
        return (_props.size());
    }

    /**
     * @return A string representing this instance.
     * @see Hashtable#toString() ()
     */
    public String toString() {
        return (_props.toString());
    }

    /**
     * @see Hashtable#clear() ()
     */
    public void clear() {
        _props.clear();
    }

    /**
     * Check to see if the passed value is in this property - @see java.util.Hashtable#containsValue(Object) ()
     *
     * @param value The value to look for.
     * @return true if the value exits; false otherwise.
     */
    public boolean containsValue(String value) {
        return (_props.containsValue(value));
    }

    /**
     * Check to see if the passed key is in this property - @see java.util.Hashtable#containsKey(Object)
     *
     * @param key The key to look for.
     * @return true if the key exits; false otherwise.
     */
    public boolean containsKey(SETTING_KEYS key) {
        return (_props.containsKey(key));
    }

    /**
     * Compare two MyProps - @see java.util.Hashtable#equals(Object) ()
     *
     * @param props What to compare to.
     * @return true if they are the same; false otherwise.
     */
    public boolean equals(MyProps<T> props) {
        boolean rc = false;

        // We can't simply do this.equals(props) or keySet().equals(props.keySet()) && values().equals(props.values())
        // because props will sometimes act as if it's HashMap<Object,Object> and
        // that doesn't equal HashMap<T,String> in Java's mind.
        if (keySet().size() == props.keySet().size()) {
            HashMap<String, String> h1 = new HashMap<>();
            HashMap<String, String> h2 = new HashMap<>();

            for (Map.Entry<T, String> item : this) {
                h1.put(item.getKey().toString(), item.getValue());
            }

            for (Map.Entry<T, String> item : props) {
                h2.put(item.getKey().toString(), item.getValue());
            }

            rc = h1.equals(h2);
        }

        return (rc);
    }

    /**
     * Retrieve a set of the elements - @see java.util.Hashtable#entrySet()
     *
     * @return The key/values contained in this map.
     */
    public Set<Map.Entry<T, String>> entrySet() {
        return (_props.entrySet());
    }

    /**
     * Retrieve a set of values - @see java.util.Hashtable#values()
     *
     * @return The values contained in this map.
     */
    public Collection<String> values() {
        return (_props.values());
    }

    /**
     * Get a set of keys - @see java.util.Hashtable#keySet()
     *
     * @return The keys contained in this map.
     */
    public Set<T> keySet() {
        return (_props.keySet());
    }

    /**
     * Remove the passed key from this instance - @see java.util.Hashtable#remove(Object)
     *
     * @param key The key to delete.
     * @return The value deleted.
     */
    public String remove(SETTING_KEYS key) {
        return (_props.remove(key));
    }

    /*
     * Implements Parcelable interface
     */

    /**
     * Describe the kinds of special objects contained in this Parcelable
     * instance's marshaled representation.
     *
     * @return A bitmask indicating the set of special object types marshaled
     * by this Parcelable object instance.
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * Flatten this object in to a Parcel.
     *
     * @param out The Parcel in which the object should be written.
     * @param i   Additional flags about how the object should be written.
     */
    @Override
    public void writeToParcel(Parcel out, int i) {
        ArrayList<String> al = new ArrayList<>();

        for (T key : _props.keySet()) {
            al.add(key + ":" + _props.get(key));
        }

        out.writeList(al);
    }

    /**
     * Classes implementing the Parcelable interface must also have a non-null
     * static field called CREATOR of a type that implements the
     * Parcelable.Creator interface.
     */
    public static final Parcelable.Creator<MyProps> CREATOR = new Parcelable.Creator<MyProps>() {
        /**
         * Create a new instance of the Parcelable class, instantiating it from
         * the given Parcel whose data had previously been written by
         * Parcelable#writeToParcel.
         *
         * @param in The Parcel to read the object's data from.
         * @return Returns a new instance of the Parcelable class.
         */
        public MyProps createFromParcel(Parcel in) {
            MyLog.d("MyProps.writeToParcel<Creator>(" + in + ")");

            return new MyProps(in);
        }

        /**
         * Create a new array of the Parcelable class.
         *
         * @param size Size of the array.
         * @return Returns an array of the Parcelable class, with every entry
         *         initialized to null.
         */
        public MyProps[] newArray(int size) {
            return new MyProps[size];
        }
    };

    /**
     * Constructor that builds an instance of MyProps from the Parcel.
     *
     * @param in The Parcel to read the object's data from.
     */
    private MyProps(Parcel in) {
        ArrayList<String> al = in.readArrayList(String.class.getClassLoader());

        for (String s : al) {
            String[] pieces = s.split(":");

            _props.put((T) (pieces[0]), pieces[1]);
        }
    }

    /*
     * Implements Iterator interface
     */

    /**
     * Returns an iterator over a set of elements of type T.
     *
     * @return The Iterator.
     */
    @Override
    public Iterator<Map.Entry<T, String>> iterator() {
        return (_props.entrySet().iterator());
    }

    /*
     * Implements Serializable interface.
     */
    private void writeObject(ObjectOutputStream oos) throws IOException {

        oos.writeInt(size());
        for (Map.Entry<T, String> item : this) {
            // The leading "" seems useless but it's needed to ensure that
            // java writes a string and not a SETTING_KEYS (the latter gives
            // you a NotSerializableException)
            oos.writeObject("" + item.getKey() + "/" + item.getValue());
        }
    }

    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        _props = new HashMap<>();

        try {
            int num_items = ois.readInt();
            for (int i = 0; i < num_items; i++) {
                String s = (String)ois.readObject();
                String[] pieces = s.split("/");

                _props.put((T) (SETTING_KEYS.map(pieces[0])), pieces[1]);
            }
        } catch (Exception e) {
            System.out.println (e);
        }
    }
}
