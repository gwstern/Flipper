package com.gwstern.flipper.util;

/**
 * A utility class that handles number wrapping. Used to go from one player to
 * the other without having to handle edge cases - i.e. last player always
 * wraps to first player.
 */
public class IntCycle {
    private int _current;
    private int _max;

    /**
     * Create an integer wrapping object for [0,num).
     *
     * @param num The largest number allowed.
     */
    public IntCycle(int num) {
//        MyLog.d ("Players.IntCycle.IntCycle (" + num + ")");

        _max = num;
        _current = 0;
    }

    /**
     * Return the next number in sequence, wrapping to 0 if necessary.
     *
     * @return The next number.
     */
    public int next() {
//        MyLog.d ("Players.IntCycle.next ()");

        _current++;
        if (_current == _max) {
            _current = 0;
        }

        return (_current);
    }

    /**
     * Return the previous number in sequence, wrapping to max-1 if necessary.
     *
     * @return The previous number.
     */
    public int prev() {
//        MyLog.d ("Players.IntCycle.prev ()");

        _current--;
        if (_current < 0) {
            _current = _max - 1;
        }

        return (_current);
    }

    /**
     * Get the current number.
     *
     * @return The current number.
     */
    public int getCount() {
        return (_current);
    }

    /**
     * Return what the previous number would be.
     *
     * @return What the previous number will be.
     */
    public int checkPrev() {
        int rc = _current - 1;

        if (rc < 0) {
            rc = _max - 1;
        }

        return (rc);
    }

    /**
     * Return what the next number would be.
     *
     * @return What the next number will be.
     */
    public int checkNext() {
        int rc = _current + 1;

        if (rc == _max) {
            rc = 0;
        }

        return (rc);
    }

    /**
     * Reset the count to 0.
     */
    public void reset() {
//        MyLog.d ("Players.IntCycle.reset ()");

        _current = 0;
    }
}