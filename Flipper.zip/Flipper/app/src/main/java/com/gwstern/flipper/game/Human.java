package com.gwstern.flipper.game;

import com.gwstern.flipper.util.MyLog;

/**
 * Implements a human opponent. Doesn't really do a lot as the 'human' stuff
 * is handled by, well, the human.
 */
public class Human implements IPlayer {
    private String _name;
    private int _icon_id;
    private SQUARE _piece;
    private long _shortest_time;
    private int _num_moves;
    private long _total_move_time;
    private long _longest_time;

    /**
     * Handles the computer opponent.
     *
     * @param name The name of this opponent.
     * @param icon_id The icon used by this player.
     * @param piece The piece used by this player.
     */
    public Human(String name,
                 int icon_id,
                 SQUARE piece) {
        MyLog.d ("Human.Human (" + name + "," + icon_id + "," + piece + ")");

        _name = name;
        _icon_id = icon_id;
        _piece = piece;
        _shortest_time = Integer.MAX_VALUE;
        _num_moves = 0;
        _total_move_time = 0;
        _longest_time = Integer.MIN_VALUE;
    }

    /**
     * Return the player's name.
     *
     * @return The name.
     */
    public String getName() {
        return (_name);
    }

    /**
     * Return the player's icon.
     *
     * @return The icon.
     */
    public int getIconId() {
        return (_icon_id);
    }

    /**
     * Returns the piece used for this player.
     *
     * @return The player's piece.
     */
    public SQUARE getPiece () {
        return (_piece);
    }

    /**
     * Who this player is.
     *
     * @return String representing this player.
     */
    @Override
    public String toString () {
        return ("Human: " + _name);
    }

    @Override
    public void setMoveTime(long ticks) {
        _shortest_time = (ticks < _shortest_time) ? ticks : _shortest_time;
        _longest_time = (ticks > _longest_time) ? ticks : _longest_time;
        _num_moves++;
        _total_move_time += ticks;
    }

    @Override
    public int getMeanMoveTime() {
        int mean = (int) (_total_move_time/_num_moves);

        return (mean);
    }

    @Override
    public int getQuickestTime() {
        return ((int)_shortest_time);
    }

    @Override
    public int getLongestTime() {
        return ((int)_longest_time);
    }
}
