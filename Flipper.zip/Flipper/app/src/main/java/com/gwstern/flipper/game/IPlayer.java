package com.gwstern.flipper.game;

/**
 * The interface that defines a player's methods.
 */
public interface IPlayer {
    /**
     * Return the name of the player.
     *
     * @return The player's name.
     */
    String getName();

    /**
     * Get the ID representing the player's piece.
     *
     * @return Android ID of the player's piece
     */
    int getIconId();

    /**
     * Return the piece (i.e. DARK/LIGHT) that represents this player.
     *
     * @return DARK/LIGHT.
     */
    SQUARE getPiece();

    /**
     * Convert this player to a readable string.
     *
     * @return The player, in a line (or two).
     */
    String toString();

    /**
     * Tells the player how long their move took.
     *
     * @param ticks How long the move took.
     */
    void setMoveTime (long ticks);

    /**
     * Return the average time a move took.
     *
     * @return The average time a move took.
     */
    int getMeanMoveTime ();

    /**
     * Return teh quickest time for a move.
     *
     * @return The fastest move.
     */
    int getQuickestTime ();

    /**
     * Return the slowest time for a move.
     *
     * @return The slowest time.
     */
    int getLongestTime ();
}
