package com.gwstern.flipper.game;

import java.util.HashMap;
import java.util.Map;

/**
 * Enumeration for the level of computer play. Note that UT_* represent
 * various types of unit testing.
 */
public enum COMPUTER_LEVEL {
    UT_1 ("UT_1"),
    UT_2 ("UT_2"),
    Easy ("Easy"),
    Hard ("Hard");

    private String _value;
    private static Map<String, COMPUTER_LEVEL> _xlat = new HashMap<>();

    /*
     * Convert integers to their enum representation
     */
    static {
        for (COMPUTER_LEVEL sq : COMPUTER_LEVEL.values()) {
            _xlat.put (sq._value, sq);
        }
    }

    /**
     * Create this enum. It's private because we down want additional enums.
     *
     * @param value THe value to assign to the enum.
     */
    COMPUTER_LEVEL(String value) { _value = value;}

    /**
     * Map the passed value to the appropriate enum.
     *
     * @param value The book value to map.
     * @return The representative enum.
     */
    static public COMPUTER_LEVEL map (String value) {
        COMPUTER_LEVEL xlat = Easy;

        if ((value != null) && (value != "") && (!value.equals("")))
            xlat = _xlat.get(value);
        else
            // Since we're dealing with data that might be modified by a user
            // we'll leave this in to help with debugging
            throw new Error ("Invalid SQUARE type of null or empty");

        return xlat;
    }
}
