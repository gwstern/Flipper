package com.gwstern.flipper.database;

import com.gwstern.flipper.toolbar.SETTING_KEYS;
import com.gwstern.flipper.util.MyProps;
import com.gwstern.flipper.toolbar.STARTING_POSITIONS;

/**
 * Implements the DAO for MyPros via hardcoded constants. Not *really* a
 * database but serves as a starting point - i.e. I can validate that this
 * works instead of having to validate that this works and that a database
 * access works at the same time.
 */
public class MyPropsHardcodeImpl implements IMyPropsDAO {
    /**
     * @see IMyPropsDAO#getAll()
     */
    public MyProps<SETTING_KEYS> getAll () {
        MyProps<SETTING_KEYS> props = new MyProps<>();

        props.put (SETTING_KEYS.PLAYER1_TYPE, "H");
        props.put (SETTING_KEYS.PLAYER1_NAME, "Human (L)");
        props.put (SETTING_KEYS.PLAYER1_ICON, "piece4a");
        props.put (SETTING_KEYS.PLAYER1_LEVEL, "Easy");
        props.put (SETTING_KEYS.PLAYER2_TYPE, "C");
        props.put (SETTING_KEYS.PLAYER2_NAME, "Computer (D)");
        props.put (SETTING_KEYS.PLAYER2_ICON, "piece4b");
        props.put (SETTING_KEYS.PLAYER2_LEVEL, "Easy");
        props.put (SETTING_KEYS.FORCE_CAPTURE, "true");
        props.put (SETTING_KEYS.START_WITH_4, STARTING_POSITIONS.EMPTY.toString());
        props.put (SETTING_KEYS.DAYS_UNTIL_PROMPT, "3");
        props.put (SETTING_KEYS.LAUNCHES_UNTIL_PROMPT, "3");
        props.put (SETTING_KEYS.PREF_NAME, "apprater");
        props.put (SETTING_KEYS.DSA_KEY, "dontshowagain");
        props.put (SETTING_KEYS.LAUNCH_COUNT_KEY, "launch_count");
        props.put (SETTING_KEYS.DATE_KEY, "date_firstlaunch");

        return (props);
    }

    /**
     * @see IMyPropsDAO#saveAll(MyProps)
     */
    public void saveAll (MyProps<SETTING_KEYS> to_save) {
        // Doesn't matter - this isn't persistent
    }

    /**
     * @see IMyPropsDAO#reset()
     */
    public void reset () {
        // Pretty much a noop for this implementation
    }
}
