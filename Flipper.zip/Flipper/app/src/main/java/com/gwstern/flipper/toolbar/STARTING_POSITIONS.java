package com.gwstern.flipper.toolbar;

import java.util.HashMap;
import java.util.Map;

/**
 * There's three possible starting positions, empty, black in the
 * upper left or white in the upper left.
 */
public enum STARTING_POSITIONS {
    EMPTY ("EMPTY"),
    OPPOSITE_W ("OPPOSITE_W"),
    OPPOSITE_B ("OPPOSITE_B"),
    PARALLEL ("PARALLEL");

    private String _value;
    private static Map<String, STARTING_POSITIONS> _xlat = new HashMap<>();

    /*
     * Convert integers to their enum representation
     */
    static {
        for (STARTING_POSITIONS sq : STARTING_POSITIONS.values()) {
            _xlat.put (sq._value, sq);
        }
    }

    /**
     * Create this enum. It's private because we don't want additional enums.
     *
     * @param value THe value to assign to the enum.
     */
    STARTING_POSITIONS(String value) { _value = value;}

    /**
     * Map the passed value to the appropriate enum.
     *
     * @param value The book value to map.
     * @return The representative enum.
     */
    static public STARTING_POSITIONS map (String value) {
        STARTING_POSITIONS xlat = null;

        if ((value != null) && (!value.equals("")))
            xlat = _xlat.get(value.toUpperCase());
        else
            // Should never get here, but you never know
            throw new Error ("Invalid STARTING_POSITIONS type of null or empty");

        return xlat;
    }
}
