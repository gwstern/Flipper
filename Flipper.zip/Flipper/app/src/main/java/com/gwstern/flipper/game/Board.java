package com.gwstern.flipper.game;

import android.graphics.Point;
import android.view.View;
import android.widget.ImageView;

import com.gwstern.flipper.R;
import com.gwstern.flipper.util.MyLog;
import com.gwstern.flipper.util.WeIsBroken;

import java.util.ArrayList;
import java.util.Stack;

/**
 * Handle things that concern the game board - i.e. valid move, undo,
 * getters/setters, ...
 */
public class Board {
    private static final int BOARD_SIZE = 8;

    private View[][] _board;
    private int _move_num;
    private boolean _force_capture;
    private boolean _start_4;

    private enum DIRECTION {
        N, NE, E, SE, S, SW, W, NW
    }

    /**
     * Create the board.
     *
     * @param board   The GUI views that make up the board. Contain useful information
     *                needed by the board object - i.e. tags.
     * @param force   Can a move be made that doesn't capture?
     * @param start_4 Whether to force four-in-the-middle
     */
    public Board(View[][] board,
                 boolean force,
                 boolean start_4) {
        MyLog.d("Board.Board (" + board + "," + force + "," + start_4 + ")");

        _board = board;
        _move_num = 0;
        _force_capture = force;
        _start_4 = start_4;
    }

    /**
     * Set the 'force capture' parameter.
     *
     * @param force Whether to force a capture or not.
     */
    public void setForceCapture (boolean force) {
        _force_capture = force;
    }

    /**
     * Set the 'first four moves must be in center' paraemter.
     *
     * @param start_4 Whether the first four moves must be in the center.
     */
    public void setStartCenter4 (boolean start_4) {
        _start_4 = start_4;
    }

    /**
     * Return the current move number.
     *
     * @return The current move number.
     */
    public int getMoveNum() {
        return (_move_num);
    }

    /**
     * Are we off the board?
     *
     * @param x X coordinate to check.
     * @param y Y coordinate to check,
     * @return true if we're still in bounds; false otherwise.
     */
    private boolean boundsCheck(int x, int y) {
        return ((x >= 0) && (x < BOARD_SIZE) && (y >= 0) && (y < BOARD_SIZE));
    }

    /**
     * Convert a direction into a x,y delta in array coordinates, not screen coordinates.
     *
     * @param dir The direction we want to go in.
     * @return The point representing the x,y we're traveling in.
     */
    private Point convertDirToXY(DIRECTION dir) {
        Point rc = new Point();

        switch (dir) {
            case N:
                rc.set(0, -1);
                break;
            case NE:
                rc.set(1, -1);
                break;
            case E:
                rc.set(1, 0);
                break;
            case SE:
                rc.set(1, 1);
                break;
            case S:
                rc.set(0, 1);
                break;
            case SW:
                rc.set(-1, 1);
                break;
            case W:
                rc.set(-1, 0);
                break;
            case NW:
                rc.set(-1, -1);
                break;
            default:
                throw new WeIsBroken("DIRECTION had a direction that shouldn't be possible - " + dir);
        }

        return (rc);
    }

    /**
     * Return the piece at x,y
     *
     * @param x The x coordinate to look at.
     * @param y The y coordinate to look at.
     * @return The SQUARE representation of what's at x,y
     */
    public SQUARE getPiece(int x, int y) {
//        MyLog.v("Board.getPiece (" + x + "," + y + ")");
//        MyLog.v ("@="+SQUARE.map(_board[y][x].getTag().toString()));

        return (SQUARE.map(_board[y][x].getTag().toString()));
    }

    /**
     * Return a simplified version of the board. Useful for computer players to examine.
     *
     * @return char[][] The current state of the board.
     */
    public SQUARE[][] getSnapshot() {
        SQUARE[][] snapshot = new SQUARE[BOARD_SIZE][BOARD_SIZE];

        for (int y = 0; y < BOARD_SIZE; y++) {
            for (int x = 0; x < BOARD_SIZE; x++) {
                snapshot[y][x] = getPiece(x, y);
            }
        }

        return (snapshot);
    }

    /**
     * Set the piece at x,y to be the passed 'piece'
     *
     * @param x     X coordinate needing the piece.
     * @param y     Y coordinate needing the piece.
     * @param piece The piece to set x,y to.
     */
    public void setPiece(int x, int y, SQUARE piece) {
        MyLog.v("Board.setPiece (" + x + "," + y + "," + piece + ")");

        ImageView iv = (ImageView) _board[y][x];

        switch (piece) {
            case EMPTY:
                iv.setImageResource(R.drawable.empty);
                break;
            case DARK:
                iv.setImageResource(R.drawable.dark_piece);
                break;
            case LIGHT:
                iv.setImageResource(R.drawable.light_piece);
                break;
            default:
                MyLog.wtf("Unexpected switch - " + piece);
                break;
        }

        _board[y][x].setTag(piece.toString());
    }

    /**
     * Remove the last move from the list of moves and reset the GUI.
     *
     * @param moves The moves that have already occured.
     * @return true if the information was changed; false otherwise.
     */
    public boolean undoLastMove(ArrayList<Move> moves) {
        MyLog.d("Board.undoLastMove ()");

        boolean rc = false;

        MyLog.d("size=" + moves.size());
        MyLog.d("moves=" + moves);
        if (moves.size() > 0) {
            Move last_move = moves.remove(moves.size() - 1);
            int x = last_move.getX();
            int y = last_move.getY();
            SQUARE piece = last_move.getPiece();
            Stack<Move> to_flip = new Stack<>();
            MyLog.d("last move=" + last_move);

            // Remove the last move
            setPiece(x, y, SQUARE.EMPTY);

            // Reset any flipped pieces
            for (DIRECTION dir : DIRECTION.values()) {
                MyLog.v("dir=" + dir);

                // Theory:
                //   o) While it's possible to build a layout that doesn't
                //      work with the following rules it's a layout that
                //      can't be built using Reversi rules.
                //      DD(*)E - flip everything between
                //      DD(*)L - nothing
                //      DL     - nothing
                //      DE     - nothing
                //      DD     - nothing
                to_flip.clear();
                for (int delta = 1; delta < BOARD_SIZE; delta++) {
                    int adj_x = convertDirToXY(dir).x * delta + x;
                    int adj_y = convertDirToXY(dir).y * delta + y;
                    MyLog.v(adj_x + "," + adj_y);
                    SQUARE on_board = getPiece(adj_x, adj_y);//SQUARE.map(_board[adj_y][adj_x].getTag().toString());

                    if (delta == 1) { // Looking at the piece directly adjacent
                        if (on_board.equals(piece)) {
                            MyLog.v("pushing");
                            to_flip.push(new Move(adj_x, adj_y, piece));
                        } else {
                            MyLog.v("DE/DL case");
                            break; // DE and DL cases
                        }
                    } else { // DD<something> cases
                        if (on_board.equals(piece)) {
                            // Need to keep looking
                            to_flip.push(new Move(adj_x, adj_y, piece));
                            MyLog.v("pushing");
                        } else if (on_board.equals(SQUARE.EMPTY)) {
                            to_flip.pop(); // Don't flip the end

                            MyLog.v("flipping");
                            for (Move m : to_flip) {
                                MyLog.d(m.getX() + "," + m.getY());
                                setPiece(m.getX(), m.getY(), piece.equals(SQUARE.LIGHT) ? SQUARE.DARK : SQUARE.LIGHT);
                            }
                            break;
                        } else { // DD(*)L case
                            MyLog.v("DD(*)L case");
                            break;
                        }
                    }
                }
            }

            rc = true;
            _move_num--;
        }

        return (rc);
    }

    /**
     * Checks to see if there's a possible move in any legal direction (N, S,
     * E, W, NE, NW, SE, SW). Note this simply checks if there is, doesn't
     * flip any pieces.
     *
     * @param x     X coordinate of the position being checked from.
     * @param y     Y coordinate of the position being checked from.
     * @param piece The piece that will be placed.
     * @return A list of directions where a legal move is possible.
     */
    public ArrayList<DIRECTION> checkDiagonals(int x, int y, SQUARE piece) {
        MyLog.d("Board.checkDiagonals (" + x + "," + y + "," + piece + ")");

        boolean opposing_piece = false;
        boolean player_piece = false;
        ArrayList<DIRECTION> rc = new ArrayList<>();

        for (DIRECTION dir : DIRECTION.values()) {
            opposing_piece = false;
            player_piece = false;
            for (int delta = 1; delta < BOARD_SIZE; delta++) {
                int adj_x = convertDirToXY(dir).x * delta + x;
                int adj_y = convertDirToXY(dir).y * delta + y;
                MyLog.v("adj=" + adj_x + "," + adj_y);

                if (boundsCheck(adj_x, adj_y)) {
                    SQUARE on_board = getPiece(adj_x, adj_y);
                    MyLog.v("\t->" + on_board);

                    if (on_board.equals(SQUARE.EMPTY)) {
                        break;
                    } else if (on_board.equals(piece)) {
                        if (opposing_piece) {
                            MyLog.v("found player's piece");
                            player_piece = true;
                        } else {
                            // Must be at least one opposing piece between player pieces
                            break;
                        }
                    } else {
                        MyLog.v("found opposing_piece");
                        opposing_piece = true;
                    }
                } else {
                    // Went past the edge of the board
                    MyLog.v("out of bounds");
                    break;
                }
            }

            if (opposing_piece && player_piece) {
                MyLog.v("possible move " + dir);
                rc.add(dir);
            } else {
                MyLog.v("no valid move " + dir);
            }
        }

        return (rc);
    }

    /**
     * Check to see if the proposed move is valid or not.
     *
     * @param x     X coordinate of the proposed move.
     * @param y     Y coordinate of the proposed move.
     * @param piece The piece that is proposed to use.
     * @return True if the move is valid; false otherwise.
     */
    public boolean isValid(int x, int y, SQUARE piece) {
        MyLog.d("Board.isValid (" + x + "," + y + "," + piece + ")");

        boolean rc = true;

        // Position must be empty
        MyLog.d ("_move#="+_move_num);
        MyLog.d ("4="+_start_4);
        MyLog.d ("piece="+getPiece(x,y));
        if (!getPiece(x, y).equals(SQUARE.EMPTY)) {
            MyLog.d("Desired position must be empty");
            rc = false;
        } else if ((_move_num < 4) && (_start_4)) {
            // First four moves must be in center, unless they're already there
            if (((x < 3) || (x > 4)) || ((y < 3) || (y > 4))) {
                MyLog.d("First moves must be in center");
                rc = false;
            }
        } else if (_force_capture) {
            // Player must place a their piece in such a position that there exists
            // at least one straight (horizontal, vertical, or diagonal) occupied
            // line between the new piece and another of their pieces, with one
            // or more contiguous opposing player pieces between them
            ArrayList<DIRECTION> possible_moves = checkDiagonals(x, y, piece);

            rc = possible_moves.size() > 0;
        }

        MyLog.d("Board.isValid="+rc);
        return (rc);
    }

    /**
     * Handle flipping between the user's choice.
     *
     * @param x     X coordinate of where the start the flip.
     * @param y     Y coordinate of where to start the flip.
     * @param piece The piece that started it all.
     */
    private void flip(int x, int y, SQUARE piece) {
        MyLog.d("Board.flip (" + x + "," + y + "," + piece + ")");

        if ((_move_num < 4) && (!_start_4)) { // Ignore if the move must go in the center four
            // Never anything to flip in the first four moves
        } else {
            ArrayList<DIRECTION> possible_moves = checkDiagonals(x, y, piece);

            // Start flipping in the directions we know there is a legal move.
            MyLog.d("start flipping in " + possible_moves.size() + " directions");
            for (DIRECTION dir : possible_moves) {
                for (int i = 1; i < BOARD_SIZE - 1; i++) {
                    int adj_x = convertDirToXY(dir).x * i + x;
                    int adj_y = convertDirToXY(dir).y * i + y;
                    MyLog.d(dir + "->" + adj_x + "," + adj_y);

                    if ((!boundsCheck(adj_x, adj_y)) || getPiece(adj_x, adj_y).equals(piece)) {
                        break; // No more pieces to flip
                    } else {
                        setPiece(adj_x, adj_y, piece);
                    }
                }
            } // foreach (dir)
        }
    }

    /**
     * Make the move, taking into account things like flipping.
     *
     * @param x      X coordinate to move to.
     * @param y      Y coordinate to move to.
     * @param player The piece to place.
     */
    public void makeMove(int x, int y, IPlayer player) {
        MyLog.d("Board.makeMove (" + x + "," + y + "," + player + ")");

        setPiece(x, y, player.getPiece());
        flip(x, y, player.getPiece());
        _move_num++;
    }

    /**
     * Reset board to starting state.
     */
    public void reset() {
        MyLog.d("Board.reset ()");

        for (int y = 0; y < BOARD_SIZE; y++) {
            for (int x = 0; x < BOARD_SIZE; x++) {
                setPiece(x, y, SQUARE.EMPTY);
            }
        }
        _move_num = 0;
    }

    /**
     * Determine how many pieces each player has.
     *
     * @param player The player pieces' to look for.
     * @return How many pieces a particular player has.
     */
    public int countPlayerPieces(IPlayer player) {
        MyLog.v("Board.countPlayerPieces (" + player + ")");

        int rc = 0;

        for (int y = 0; y < BOARD_SIZE; y++) {
            for (int x = 0; x < BOARD_SIZE; x++) {
                if (getPiece(x, y).equals(player.getPiece())) {
                    rc++;
                }
            }
        }

        return (rc);
    }

    /**
     * Determines if there are still moves to make.
     *
     * @return true if there are; false otherwise.
     */
    public boolean stillMoves(IPlayer player) {
//        MyLog.d("Board.stillMoves (" + player + ")");

        boolean rc = true;
        int num_pieces = countPlayerPieces(player);

        if (_move_num < 5) {
            MyLog.v("_move_num < 5");
            rc = true;
        } else if ((_move_num >= BOARD_SIZE * BOARD_SIZE)) {
            MyLog.v("Full board (" + _move_num + ")");
            rc = false;
        } else if (num_pieces == 0) {
            MyLog.v("No pieces to capture with");
            rc = false;
        } else if (! _force_capture) {
            MyLog.v("Board not full and ! force capture");
            rc = true;
        } else {
            boolean found_valid = false;

            for (int y = 0; ((y < BOARD_SIZE) && (!found_valid)); y++) {
                for (int x = 0; ((x < BOARD_SIZE) && (!found_valid)); x++) {
                    MyLog.v("tag @ (" + x + "," + y + ")=" + getPiece(x, y));
                    if (getPiece(x, y).equals(SQUARE.EMPTY)) {
                        MyLog.v("checking " + player.getPiece());
                        if (isValid(x, y, player.getPiece())) {
                            MyLog.v("found " + player.getPiece() + " @ (" + x + "," + y + ")");
                            found_valid = true;
                        }
                    }
                }
            }

            rc = found_valid;
        }

        return (rc);
    }
}
