package com.gwstern.flipper.toolbar;

import java.util.HashMap;
import java.util.Map;

/**
 * An enumeration that uses strings rather than integers for the keys
 * representing various settings.
 */
public enum SETTING_KEYS {
    PLAYER1_TYPE ("PLAYER1_TYPE"),
    PLAYER2_TYPE ("PLAYER2_TYPE"),
    PLAYER1_NAME ("PLAYER1_NAME"),
    PLAYER2_NAME ("PLAYER2_NAME"),
    PLAYER1_ICON ("PLAYER1_ICON"),
    PLAYER2_ICON ("PLAYER2_ICON"),
    PLAYER1_LEVEL ("PLAYER1_LEVEL"),
    PLAYER2_LEVEL ("PLAYER2_LEVEL"),
    FORCE_CAPTURE ("FORCE_CAPTURE"),
    START_WITH_4 ("START_WITH_4"),
    DAYS_UNTIL_PROMPT ("DAYS_UNTIL_PROMPT"), // Min number of days to wait to before rate prompting
    LAUNCHES_UNTIL_PROMPT ("LAUNCHES_UNTIL_PROMPT"), // Min number of launches to wait before rate prompting
    PREF_NAME ("PREF_NAME"),
    DSA_KEY ("DSA_KEY"),
    LAUNCH_COUNT_KEY ("LAUNCH_COUNT_KEY"),
    DATE_KEY ("DATE_KEY"),
    ;

    private String _value;
    private static Map<String, SETTING_KEYS> _xlat = new HashMap<>();

    /*
     * Convert integers to their enum representation
     */
    static {
        for (SETTING_KEYS sq : SETTING_KEYS.values()) {
            _xlat.put (sq._value, sq);
        }
    }

    /**
     * Create this enum. It's private because we don't want additional enums.
     *
     * @param value THe value to assign to the enum.
     */
    SETTING_KEYS(String value) { _value = value;}

    /**
     * Map the passed value to the appropriate enum.
     *
     * @param value The book value to map.
     * @return The representative enum.
     */
    static public SETTING_KEYS map (String value) {
        SETTING_KEYS xlat = null;

        if ((value != null) && (value != "") && (!value.equals("")))
            xlat = _xlat.get(value.toUpperCase());
        else
            // Should never get here, but you never know
            throw new Error ("Invalid SETTING_KEYS type of null or empty");

        return xlat;
    }
}
