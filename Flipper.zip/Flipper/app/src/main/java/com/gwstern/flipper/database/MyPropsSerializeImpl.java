package com.gwstern.flipper.database;

import com.gwstern.flipper.toolbar.SETTING_KEYS;
import com.gwstern.flipper.util.MyLog;
import com.gwstern.flipper.util.MyProps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Implements the DAO for MyPros via serialization.
 */
public class MyPropsSerializeImpl implements IMyPropsDAO {
    private final String FILENAME = "Flipper.ser";

    /**
     * @see IMyPropsDAO#getAll()
     */
    public MyProps<SETTING_KEYS> getAll() {
        MyProps<SETTING_KEYS> props = null;
        ObjectInputStream ois = null;

        try {
            ois = new ObjectInputStream(new FileInputStream(FILENAME));

            props = (MyProps<SETTING_KEYS>)ois.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            MyLog.e ("Unable to read MyProps from " + FILENAME + ": " + ex);
        } finally {
            if (ois != null) {
                try {
                    ois.close();
                } catch (IOException ioe) {
                    // Don't really care at this point
                }
            }
        }

        // Regardless of the reason we couldn't read MyProps we need some default values
        if (props == null) {
            MyPropsHardcodeImpl myprops_dao = new MyPropsHardcodeImpl();
            props = myprops_dao.getAll();
        }

        return (props);
    }

    /**
     * @see IMyPropsDAO#saveAll(MyProps)
     */
    public void saveAll(MyProps<SETTING_KEYS> to_save) {
        ObjectOutputStream oos = null;

        try {
            oos = new ObjectOutputStream(new FileOutputStream(FILENAME));

            oos.writeObject(to_save);
        } catch (IOException ex) {
            MyLog.e ("Unable to write MyPros to " + FILENAME + ": " + ex);
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException ioe) {
                    // Don't really care at this point
                }
            }
        }
    }

    /**
     * @see IMyPropsDAO#reset()
     */
    public void reset () {
        new File("Flipper.ser").delete();
    }
}
