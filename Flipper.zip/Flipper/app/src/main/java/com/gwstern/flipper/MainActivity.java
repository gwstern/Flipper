/**
 * This is a simple Reversi/Othello-type program designed to show how one might
 * build an Android application. This is the 'final' one.
 * <p>
 * History:
 * 22 Jul 2019 Initial creation
 */
package com.gwstern.flipper;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.os.Parcelable;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.gwstern.flipper.database.IMyPropsDAO;
import com.gwstern.flipper.database.MoveSQLITEImpl;
import com.gwstern.flipper.database.MyPropsHardcodeImpl;
import com.gwstern.flipper.game.Board;
import com.gwstern.flipper.game.COMPUTER_LEVEL;
import com.gwstern.flipper.game.Computer;
import com.gwstern.flipper.game.Human;
import com.gwstern.flipper.game.IPlayer;
import com.gwstern.flipper.game.Move;
import com.gwstern.flipper.game.Players;
import com.gwstern.flipper.game.SQUARE;
import com.gwstern.flipper.help.HelpDialogFragment;
import com.gwstern.flipper.ticker.TickerImpl;
import com.gwstern.flipper.toolbar.AboutActivity;
import com.gwstern.flipper.toolbar.RateItActivity;
import com.gwstern.flipper.toolbar.SETTING_KEYS;
import com.gwstern.flipper.toolbar.STARTING_POSITIONS;
import com.gwstern.flipper.toolbar.SettingsDialogFragment;
import com.gwstern.flipper.util.MyLog;
import com.gwstern.flipper.util.MyProps;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This is where it all begins. Class currently does nothing more than run a
 * app that has a simple menu, FAB and greeting
 * <p>
 * <p>
 * https://en.wikipedia.org/wiki/Reversi
 * https://bonaludo.com/2016/02/18/reversi-and-othello-two-different-games-do-you-know-their-different-rules/
 * https://www.yourturnmyturn.com/rules/reversi.php
 */
public class MainActivity extends AppCompatActivity implements SettingsDialogFragment.SettingsListener, NavigationView.OnNavigationItemSelectedListener {

    /*package*/ MyProps<SETTING_KEYS> _game_props = new MyProps<>();
    /*package*/ TickerImpl _ticker;
    /*package*/ Players _players;
    /*package*/ Board _board;
    private MoveSQLITEImpl _db;
    private boolean _paused;

    /**
     * I like to have at least *some* information displayed if the program
     * exists unexpectedly.
     */
    public MainActivity() {
        Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread,
                                          Throwable ex) {
                MyLog.wtf(getApplicationContext(), "uncaughtException - ", ex);
            }
        });
    }

    /**
     * Called when the window is created.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it
     *                           has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("MainActivity.onCreate (" + savedInstanceState + ")");

        // Create the layout
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Create the navigation drawer
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_bar, R.string.close_bar);

        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        // Create the instance that will handle MyProps
        IMyPropsDAO myprops_dao = new MyPropsHardcodeImpl();

        _game_props = myprops_dao.getAll();
        _paused = false;

        // Create a timer
        _ticker = new TickerImpl();
        _ticker.start((TextView) findViewById(R.id.ticker));
        _ticker.stop();

        // Create the database
        _db = new MoveSQLITEImpl(getApplicationContext());
        _db.eraseAll();

        // Define some actions for the buttons on the bottom
        findViewById(R.id.pause).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_paused) {
                    unpauseGame(view.getRootView());
                } else {
                    pauseGame(view.getRootView());
                }
            }
        });

        findViewById(R.id.quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<quit> (" + view + ")");

                // Create a popup dialog with an entry field and two buttons
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                MyLog.d("player=" + _players);
                int p0 = _board.countPlayerPieces(_players.getPlayer(0));
                int p1 = _board.countPlayerPieces(_players.getPlayer(1));
                String winner_name = (p0 > p1) ? _players.getPlayer(0).getName() : _players.getPlayer(1).getName();
                String loser_name = (p0 > p1) ? _players.getPlayer(1).getName() : _players.getPlayer(0).getName();
                int winner_mean_time = 0;
                int winner_fastest_time = 0;
                int winner_longest_time = 0;
                int loser_mean_time = 0;
                int loser_fastest_time = 0;
                int loser_longest_time = 0;

                if (p0 > p1) { // Player #0 won
                    winner_name =  _players.getPlayer(0).getName();
                    loser_name = _players.getPlayer(1).getName();
                    winner_mean_time = _players.getPlayer(0).getMeanMoveTime();
                    winner_fastest_time = _players.getPlayer(0).getQuickestTime();
                    winner_longest_time = _players.getPlayer(0).getLongestTime();
                    loser_mean_time = _players.getPlayer(1).getMeanMoveTime();
                    loser_fastest_time = _players.getPlayer(1).getQuickestTime();
                    loser_longest_time = _players.getPlayer(1).getLongestTime();
                } else { // Player #1 won
                    winner_name =  _players.getPlayer(1).getName();
                    loser_name = _players.getPlayer(0).getName();
                    winner_mean_time = _players.getPlayer(1).getMeanMoveTime();
                    winner_fastest_time = _players.getPlayer(1).getQuickestTime();
                    winner_longest_time = _players.getPlayer(1).getLongestTime();
                    loser_mean_time = _players.getPlayer(0).getMeanMoveTime();
                    loser_fastest_time = _players.getPlayer(0).getQuickestTime();
                    loser_longest_time = _players.getPlayer(0).getLongestTime();
                }

                String info = "Winner is: " + winner_name + " capturing " + ((p0 > p1) ? p0 : p1) + " vs " + ((p0 > p1) ? p1 : p0) + " pieces!!!\n\n"
                        + winner_name + " averaged " + winner_mean_time + " seconds per move. Fastest was " + winner_fastest_time + " seconds, longest was " + winner_longest_time + " seconds.\n"
                        + loser_name + " averaged " + loser_mean_time + " seconds per move. Fastest was " + loser_fastest_time + " seconds, longest was " + loser_longest_time + " seconds.";

                EditText et = new EditText(getApplicationContext());
                et.setText(info);
                builder.setView(et);

                builder.setCancelable(false).setPositiveButton(getApplicationContext().getString(R.string.ok_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d("MainActivity.alertDialogBuilder.onClick<ok> (" + dialog + "," + id + ")");
                    }
                });

                // Close the report and return to program
                builder.setCancelable(false).setNegativeButton(getApplicationContext().getString(R.string.cancel_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d("MainActivity.onClick<cancel> (" + dialog + "," + id + ")");
                    }
                });

                // Show the dialog
                AlertDialog ad = builder.create();

                ad.setTitle("Game Stats");
                ad.show();

                resetGame(view.getRootView());
            }
        });

        findViewById(R.id.help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<help> (" + view + ")");

                pauseGame(view.getRootView());

                HelpDialogFragment hdf = HelpDialogFragment.newInstance();
                hdf.show(getSupportFragmentManager(), "help fragement");
            }
        });

        // Currently not selectable by the user
        findViewById(R.id.undo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<undoLastMove> (" + view + ")");

                if (_board.undoLastMove(_db.getAll())) {
                    _players.prev();
                    _db.deleteLastMove();
                }
            }
        });

        // Yeah, still a bit ugly but at least it's an array and a loop rather
        // than simply a bunch of statements.
        View[][] views = {
                {findViewById(R.id.posA1), findViewById(R.id.posB1), findViewById(R.id.posC1), findViewById(R.id.posD1), findViewById(R.id.posE1), findViewById(R.id.posF1), findViewById(R.id.posG1), findViewById(R.id.posH1)},
                {findViewById(R.id.posA2), findViewById(R.id.posB2), findViewById(R.id.posC2), findViewById(R.id.posD2), findViewById(R.id.posE2), findViewById(R.id.posF2), findViewById(R.id.posG2), findViewById(R.id.posH2)},
                {findViewById(R.id.posA3), findViewById(R.id.posB3), findViewById(R.id.posC3), findViewById(R.id.posD3), findViewById(R.id.posE3), findViewById(R.id.posF3), findViewById(R.id.posG3), findViewById(R.id.posH3)},
                {findViewById(R.id.posA4), findViewById(R.id.posB4), findViewById(R.id.posC4), findViewById(R.id.posD4), findViewById(R.id.posE4), findViewById(R.id.posF4), findViewById(R.id.posG4), findViewById(R.id.posH4)},
                {findViewById(R.id.posA5), findViewById(R.id.posB5), findViewById(R.id.posC5), findViewById(R.id.posD5), findViewById(R.id.posE5), findViewById(R.id.posF5), findViewById(R.id.posG5), findViewById(R.id.posH5)},
                {findViewById(R.id.posA6), findViewById(R.id.posB6), findViewById(R.id.posC6), findViewById(R.id.posD6), findViewById(R.id.posE6), findViewById(R.id.posF6), findViewById(R.id.posG6), findViewById(R.id.posH6)},
                {findViewById(R.id.posA7), findViewById(R.id.posB7), findViewById(R.id.posC7), findViewById(R.id.posD7), findViewById(R.id.posE7), findViewById(R.id.posF7), findViewById(R.id.posG7), findViewById(R.id.posH7)},
                {findViewById(R.id.posA8), findViewById(R.id.posB8), findViewById(R.id.posC8), findViewById(R.id.posD8), findViewById(R.id.posE8), findViewById(R.id.posF8), findViewById(R.id.posG8), findViewById(R.id.posH8)}
        };
        boolean start_with_4 = STARTING_POSITIONS.map(_game_props.get(SETTING_KEYS.START_WITH_4)).equals(STARTING_POSITIONS.EMPTY);
        boolean force_capture = _game_props.get(SETTING_KEYS.FORCE_CAPTURE).equalsIgnoreCase("true");

        _board = new Board(views,
                force_capture,
                !start_with_4);

        // Set player info
        ((TextView) findViewById(R.id.player1_name)).setText(_game_props.get(SETTING_KEYS.PLAYER1_NAME));
        ((TextView) findViewById(R.id.player2_name)).setText(_game_props.get(SETTING_KEYS.PLAYER2_NAME));

        _players = new Players(null, null);

        resetGame(findViewById(R.id.flipper_layout));
    }

    /**
     * Helper function to ensure that everywhere the game is reset it does
     * the same thing.
     *
     * @param view The parent view of what's being updated.
     */
    private void resetGame(View view) {
        MyLog.d("MainActivity.resetGame (" + view + ")");

        ImageButton ib = view.findViewById(R.id.pause);
        boolean start_with_4 = STARTING_POSITIONS.map(_game_props.get(SETTING_KEYS.START_WITH_4)).equals(STARTING_POSITIONS.EMPTY);
        boolean force_capture = _game_props.get(SETTING_KEYS.FORCE_CAPTURE).equalsIgnoreCase("true");

        ib.setImageResource(android.R.drawable.ic_media_pause);

        // Create player #1
        IPlayer new_player;

        if (_game_props.get(SETTING_KEYS.PLAYER1_TYPE).equals("H")) {
            new_player = new Human(_game_props.get(SETTING_KEYS.PLAYER1_NAME), R.drawable.light_piece, SQUARE.LIGHT);
            _players.setPlayer(0, new_player);
        } else {
            new_player = new Computer(this, COMPUTER_LEVEL.map(_game_props.get(SETTING_KEYS.PLAYER1_LEVEL)), _game_props.get(SETTING_KEYS.PLAYER1_NAME), R.drawable.light_piece, SQUARE.LIGHT);
            _players.setPlayer(0, new_player);
        }
        ((TextView) view.findViewById(R.id.player1_name)).setText(new_player.getName());

        // Create player #2
        if (_game_props.get(SETTING_KEYS.PLAYER2_TYPE).equals("H")) {
            new_player = new Human(_game_props.get(SETTING_KEYS.PLAYER2_NAME), R.drawable.dark_piece, SQUARE.DARK);
            _players.setPlayer(1, new_player);
        } else {
            new_player = new Computer(this, COMPUTER_LEVEL.map(_game_props.get(SETTING_KEYS.PLAYER2_LEVEL)), _game_props.get(SETTING_KEYS.PLAYER2_NAME), R.drawable.dark_piece, SQUARE.DARK);
            _players.setPlayer(1, new_player);
        }
        ((TextView) view.findViewById(R.id.player2_name)).setText(new_player.getName());

        _ticker.stop();
        _paused = false;
        _board.reset();
        _players.reset();

        _board.setForceCapture(force_capture);
        _board.setStartCenter4(start_with_4);

        // Draw starting positions
        STARTING_POSITIONS sp = STARTING_POSITIONS.map(_game_props.get(SETTING_KEYS.START_WITH_4));
        Point[] moves;

        switch (sp) {
            case OPPOSITE_W: {
                moves = new Point[]{
                        new Point(3, 3),
                        new Point(3, 4),
                        new Point(4, 4),
                        new Point(4, 3),
                };
            }
            break;
            case OPPOSITE_B: {
                moves = new Point[]{
                        new Point(3, 4),
                        new Point(3, 3),
                        new Point(4, 3),
                        new Point(4, 4),
                };
            }
            break;
            case PARALLEL: {
                moves = new Point[]{
                        new Point(3, 3),
                        new Point(3, 4),
                        new Point(4, 3),
                        new Point(4, 4),
                };
            }
            break;
            default: // STARTING_POSITIONS.EMPTY :
                moves = new Point[0];
                break;
        }

        // Put in the center pieces, if needed
        for (Point p : moves) {
            _board.makeMove(p.x, p.y, _players.getCurrentPlayer());
            _db.add(_board.getMoveNum(), p.x, p.y, _players.getCurrentPlayer().getPiece());

            _players.next();
        }

        updateCaptureCount(view,
                0,
                0,
                0);
    }

    /**
     * Helper function to ensure that everywhere the game is paused it does
     * the same thing.
     *
     * @param view The parent view of what's being updated.
     */
    private void pauseGame(View view) {
        MyLog.d("MainActivity.pauseGame (" + view + ")");

        ImageButton ib = view.findViewById(R.id.pause);
        ib.setImageResource(android.R.drawable.ic_media_play);

        _ticker.pause();
        _paused = true;
    }

    /**
     * Helper function to ensure that everywhere the game is unpaused it does
     * the same thing.
     *
     * @param view The parent view of what's being updated.
     */
    private void unpauseGame(View view) {
        MyLog.d("MainActivity.unpauseGame (" + view + ")");

        ImageButton ib = view.findViewById(R.id.pause);
        ib.setImageResource(android.R.drawable.ic_media_pause);

        _ticker.resume();
        _paused = false;
    }

    /**
     * Helper function to ensure that everywhere the game sets the player piece
     * count it's done the same way.
     *
     * @param view    The parent view of what's being updated.
     * @param player1 The number of pieces captured for player #1.
     * @param player2 The number of pieces captured for player #2.
     */
    private void updateCaptureCount(View view, int current_player, int player1, int player2) {
        MyLog.d("MainActivity.updateCaptureCount (" + view + "," + current_player + "," + player1 + "," + player2 + ")");

        TextView tv = view.getRootView().findViewById(R.id.player1_score);
        String count = Integer.toString(player1); // Needs to be a String otherwise it conflicts with TextView.setText(<resource id>)

        // Set the first player's name, count and active status
        tv = view.getRootView().findViewById(R.id.player1_score);
        tv.setText(count);
        if (current_player == 0) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }

        tv = view.getRootView().findViewById(R.id.player1_name);
        if (current_player == 0) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }

        // Set the second player's name, count and active status
        tv = view.getRootView().findViewById(R.id.player2_score);
        count = Integer.toString(player2);
        tv.setText(count);
        if (current_player == 1) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }

        tv = view.getRootView().findViewById(R.id.player2_name);
        if (current_player == 1) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }
    }

    /**
     * We 'hide' the actual implementation of a board mouse click so that we
     * can:
     * 1) Ignore Human clicks if it's the computer's turn
     * 2) 'Fake a click' when the computer's made it's move
     *
     * @param view The view (ImageView) of this board position.
     */
    private void _handleBoardClick(View view) {
        MyLog.d("MainActivity._handleBoardClick (" + view + ")");
//        ImageView iv = (ImageView) view;

        // In order to translate click coordinates we need to know where the
        // board is relative to the screen because the coordinates are given
        // relative to the screen. So view is the piece position, view.getParent()
        // is the TableRow, view.getParent().getParent() is the TableLayout
        // and view.getParent().getParent().getParent() is the ConstraintLayout
        // everything is in. So getChildVisibleRect asks ConstraintLayout
        // where the TableLayout is.
        Rect table = new Rect(0, 0, 2, 4);
        view.getParent().getParent().getParent().getChildVisibleRect((View) (view.getParent().getParent()), table, null);
        MyLog.d("view=" + view.getParent().getParent().getParent());
        MyLog.d("(c) view=" + view.getParent().getParent());
        MyLog.d("table=" + table);

        Rect r = new Rect(0, 0, 2, 2);
        view.getParent().getChildVisibleRect(view, r, null);
        MyLog.d("view2=" + view.getParent());
        MyLog.d("r=" + r);

        int x = Math.round((float) (r.left - table.left) / (float) view.getWidth());
        MyLog.d("r.l=" + r.left + " t.l=" + table.left + " wid=" + view.getWidth());
//        int y = Math.round((float) (r.top - table.top) / (float) view.getHeight());
//        MyLog.d ("r.t="+r.top+" t.t="+table.top+" he="+view.getHeight());
        int y = Math.round((float) (r.top - table.top) / (float) 165);
        MyLog.d("r.t=" + r.top + " t.t=" + table.top + " he=" + 165);
        MyLog.d("x=" + x + ", y=" + y);

        // Check desired move
        if (_board.isValid(x, y, _players.getCurrentPlayer().getPiece())) {
            // Stop timer
            _ticker.stop();
            _players.getCurrentPlayer().setMoveTime(_ticker.getTicks());

            // Move piece and flip any captures
            _board.makeMove(x, y, _players.getCurrentPlayer());
            _db.add(_board.getMoveNum(), x, y, _players.getCurrentPlayer().getPiece());

            _players.next();

            // Update board
            updateCaptureCount(view,
                    _players.getCurrentPlayerNumber(),
                    _board.countPlayerPieces(_players.getPlayer(0)),
                    _board.countPlayerPieces(_players.getPlayer(1)));

            if (!_board.stillMoves(_players.getCurrentPlayer())) {
                if (_board.stillMoves(_players.checkNextPlayer())) {
                    MyLog.d(_players.getCurrentPlayer().getName() + " has no moves left!");
                    Snackbar.make(view, _players.getCurrentPlayer().getName() + " has no moves left!", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                } else {
                    MyLog.d("Nobody has moves left!");
                    Snackbar.make(view, "Nobody has moves left!", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            } else if (_players.getCurrentPlayer() instanceof Computer) {
                ((Computer) _players.getCurrentPlayer()).startThinking(_board);
            }

            // start timer
            _ticker.restart();
        }
    }

    /**
     * Rather than using setOnClickListener() we define a method that handles
     * the clicks and set onClick in styles.xml.
     *
     * @param view The view (ImageView) of this board position.
     */
    public void handleBoardClick(View view) {
        MyLog.d("MainActivity.handleBoardClick (" + view + ")");

        if (_players.getCurrentPlayer() instanceof Human) {
            _handleBoardClick(view);
        }
    }

    public void handleBoardClick(int move) {
        MyLog.d("MainActivity.handleBoardClick (" + move + ")");

        _handleBoardClick(findViewById(move));
    }

    /**
     * Called when a fragment is attached as a child of this fragment.
     *
     * @param f Child fragment being attached.
     */
    @Override
    public void onAttachFragment(Fragment f) {
        MyLog.d("MainActivity.onAttachFragment (" + f + ")");

        if (f instanceof SettingsDialogFragment) {
            ((SettingsDialogFragment) f).setMyListener(this);
        }
    }

    /**
     * Method called when the settings have changed.
     *
     * @param new_settings New settings if !null
     */
    public void getNewSettings(MyProps<SETTING_KEYS> new_settings) {
        MyLog.d("MainActivity.getNewSettings (" + new_settings + ")");

        if (new_settings != null) {
            _game_props.clear();
            _game_props.putAll(new_settings);

            resetGame(findViewById(R.id.flipper_layout));
        }
    }

    /**
     * Creates the options menu for the main activity.
     *
     * @param menu The instance selected.
     * @return true to display the menu; false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MyLog.d("MainActivity.onCreateOptionsMenu (" + menu + ")");

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callAboutActivity(MenuItem item) {
        MyLog.d("MainActivity.callAboutActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), AboutActivity.class);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);

            // To be consistent with the other menu items we close the navigation drawer
            ((DrawerLayout) findViewById(R.id.drawer_layout)).closeDrawer(GravityCompat.START);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'AboutActivity'");
        }
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callRateItActivity(MenuItem item) {
        MyLog.d("MainActivity.callRateItActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), RateItActivity.class);

        intent.putExtra("PROPS", (Parcelable) _game_props);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'RateItActivity'");
        }
    }

    /**
     * Since some menu items can be called from the nav drawer or from the drop
     * down menu we handle all menu items here.
     *
     * @param item The item selected.
     * @return true if the selection has been processed.
     */
    private boolean handleMenuItems(MenuItem item) {
        MyLog.d("MainActivity.handleMenuItems (" + item + ")");
        boolean rc = false;

        switch (item.getItemId()) {
            case R.id.app_settings:
                SettingsDialogFragment sdf = SettingsDialogFragment.newInstance(_game_props);
                // Seems the default for dialogs is no window title after API 23
                // so we have to 'fix' that by setting R.style.DialogFragment
                sdf.setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragment);
                sdf.show(getSupportFragmentManager(), "settings_fragment");

                rc = true;
                break;

            case R.id.report_bug:
                // Create a popup dialog with an entry field and two buttons
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                final EditText et = new EditText(getApplicationContext());

                builder.setView(et);

                // Send the bug report
                builder.setCancelable(false).setPositiveButton(getApplicationContext().getString(R.string.submit_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d("MainActivity.alertDialogBuilder.onClick<ok> (" + dialog + "," + id + ")");

                        // Send a email bug report via email
                        Intent email_intent = new Intent(Intent.ACTION_SENDTO);
                        String[] addresses = {getApplicationContext().getString(R.string.bug_email_text),};

                        email_intent.setData(Uri.fromParts(
                                "mailto", getApplicationContext().getString(R.string.bug_email_text), null));
                        email_intent.putExtra(Intent.EXTRA_SUBJECT, getApplicationContext().getString(R.string.email_subject_text));
                        email_intent.putExtra(Intent.EXTRA_TEXT, et.getText());
                        email_intent.putExtra(Intent.EXTRA_EMAIL, addresses); // Android 4.3 requires an additional field with email addresses

                        try {
                            ArrayList<Move> moves = _db.getAll();
                            File file = new File(getApplicationContext().getExternalCacheDir(), "moves.txt");
                            FileWriter writer = new FileWriter(file);

                            for (Move m : moves) {
                                writer.write(m + System.lineSeparator());
                            }
                            writer.close();

                            Uri uri = Uri.fromFile(file);
                            email_intent.putExtra(Intent.EXTRA_STREAM, uri);
                        } catch (IOException e) {
                            MyLog.e("Unable to retrieve lists of moves!!!");
                        }

                        startActivity(Intent.createChooser(email_intent, getApplicationContext().getString(R.string.sending_email_text)));
                    }
                });

                // Close the report and return to program
                builder.setCancelable(false).setNegativeButton(getApplicationContext().getString(R.string.cancel_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d("MainActivity.onClick<cancel> (" + dialog + "," + id + ")");
                    }
                });

                // Show the dialog
                AlertDialog ad = builder.create();

                ad.setTitle(R.string.describe_bug_text);
                ad.show();

                rc = true;
                break;

            default:
                rc = super.onOptionsItemSelected(item);
                break;
        }

        return (rc);
    }

    /**
     * Handle action bar item clicks here. The action bar will
     * automatically handle clicks on the Home/Up button, so long
     * as you specify a parent activity in AndroidManifest.xml.
     *
     * @param item The menu item selected.
     * @return false to allow normal menu processing; true to consume it.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onOptionsItemSelected (" + item + ")");

        boolean rc = handleMenuItems(item);

        if (!rc) {
            rc = super.onOptionsItemSelected(item);
        }

        return (rc);
    }

    /**
     * Called when an item in the navigation drawer is selected.
     *
     * @param item The item selected.
     * @return true to display the item; (?) false not to display it.
     */
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onNavigationItemSelected (" + item + ")");

        // Handle navigation view item clicks here.

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        handleMenuItems(item);

        return true;
    }

    /**
     * Called when the back key is pressed. Here we close the drawer if it's
     * open otherwise let Android handle it.
     */
    @Override
    public void onBackPressed() {
        MyLog.d("MainActivity.onBackPressed ()");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
