package com.gwstern.flipper.util;

/**
 * Utility class that handles really bad/fatal exceptions.
 */
public class WeIsBroken extends RuntimeException {
    /**
     * Log the message before continuing on. Doesn't do anything at this time
     * other than what's done by default.
     *
     * @param msg - A (hopefully) helpful message.
     */
    public WeIsBroken (String msg) {
        super (msg);
    }

    /**
     * Log the message and display a stack trace before continuing on.Doesn't
     * do anything at this time other than what's done by default.
     *
     * @param msg - A (hopefully) helpful message.
     * @param cause - A (hopefully) helpful stack trace.
     */
    public WeIsBroken (String msg,
                       Throwable cause) {
        super (msg, cause);
    }
}
