package com.gwstern.flipper.game;

import android.os.AsyncTask;

import com.gwstern.flipper.MainActivity;
import com.gwstern.flipper.util.MyLog;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Implements a computer opponent.
 */
public class Computer implements IPlayer {
    // Used in unit testing to confirm that Human vs. Computer works
    private static final Move[] _ut_player1_moves = {
            new Move(3, 3, SQUARE.LIGHT), new Move(4, 3, SQUARE.LIGHT), new Move(3, 5, SQUARE.LIGHT),
            new Move(5, 3, SQUARE.LIGHT), new Move(2, 5, SQUARE.LIGHT), new Move(3, 2, SQUARE.LIGHT),
            new Move(2, 6, SQUARE.LIGHT), new Move(5, 1, SQUARE.LIGHT), new Move(1, 1, SQUARE.LIGHT),
            new Move(6, 2, SQUARE.LIGHT), new Move(1, 2, SQUARE.LIGHT), new Move(3, 7, SQUARE.LIGHT),
            new Move(1, 3, SQUARE.LIGHT), new Move(0, 4, SQUARE.LIGHT), new Move(0, 6, SQUARE.LIGHT),
            new Move(1, 0, SQUARE.LIGHT), new Move(0, 1, SQUARE.LIGHT), new Move(1, 7, SQUARE.LIGHT),
            new Move(7, 2, SQUARE.LIGHT), new Move(2, 4, SQUARE.LIGHT), new Move(4, 0, SQUARE.LIGHT),
            new Move(3, 0, SQUARE.LIGHT), new Move(6, 0, SQUARE.LIGHT), new Move(5, 4, SQUARE.LIGHT),
            new Move(1, 4, SQUARE.LIGHT), new Move(4, 6, SQUARE.LIGHT), new Move(5, 6, SQUARE.LIGHT),
            new Move(6, 6, SQUARE.LIGHT), new Move(6, 4, SQUARE.LIGHT), new Move(6, 7, SQUARE.LIGHT),
            new Move(7, 5, SQUARE.LIGHT), new Move(6, 3, SQUARE.LIGHT),
    };

    // Used in unit testing to confirm that Computer vs. Computer works
    private static final Move[] _ut_player2_moves = {
            new Move(3, 4, SQUARE.DARK), new Move(4, 4, SQUARE.DARK), new Move(2, 2, SQUARE.DARK),
            new Move(3, 6, SQUARE.DARK), new Move(1, 5, SQUARE.DARK), new Move(4, 2, SQUARE.DARK),
            new Move(2, 7, SQUARE.DARK), new Move(5, 2, SQUARE.DARK), new Move(4, 5, SQUARE.DARK),
            new Move(0, 0, SQUARE.DARK), new Move(4, 1, SQUARE.DARK), new Move(2, 3, SQUARE.DARK),
            new Move(0, 2, SQUARE.DARK), new Move(0, 5, SQUARE.DARK), new Move(6, 1, SQUARE.DARK),
            new Move(0, 3, SQUARE.DARK), new Move(0, 7, SQUARE.DARK), new Move(7, 1, SQUARE.DARK),
            new Move(2, 1, SQUARE.DARK), new Move(3, 1, SQUARE.DARK), new Move(2, 0, SQUARE.DARK),
            new Move(5, 0, SQUARE.DARK), new Move(7, 0, SQUARE.DARK), new Move(1, 6, SQUARE.DARK),
            new Move(4, 7, SQUARE.DARK), new Move(5, 7, SQUARE.DARK), new Move(6, 5, SQUARE.DARK),
            new Move(5, 5, SQUARE.DARK), new Move(7, 7, SQUARE.DARK), new Move(7, 6, SQUARE.DARK),
            new Move(7, 4, SQUARE.DARK), new Move(7, 3, SQUARE.DARK),
    };

    private int _ut_index = 0;

    // Instance variables
    private String _name;
    private int _icon_id;
    private SQUARE _piece;
    private MainActivity _ma;
    private COMPUTER_LEVEL _level;
    private long _shortest_time;
    private int _num_moves;
    private long _total_move_time;
    private long _longest_time;

    /**
     * Background task thread. Executed by android it determines the next move
     * and then passes that information back to the GUI thread via
     * MainActivity.handleBoardClick()
     */
    class Thinker extends AsyncTask<Board, Integer, Move> {
        /**
         * Does the actual 'thinking'
         *
         * @param full_board The game full_board.
         * @return Computer's move.
         */
        @Override
        protected Move doInBackground(Board... full_board) {
            MyLog.d("Thinker<" + _name + ">.doInBackground (" + full_board + ")");

            Move rc = null;

            // Make the unit test ones (UT_1, UT_2) match what's in ComputerTest
            MyLog.d("_level=" + _level);
            switch (_level) {
                case UT_1:
                    rc = _ut_player1_moves[_ut_index++];
                    break;
                case UT_2:
                    rc = _ut_player2_moves[_ut_index++];
                    break;
                case Hard:
                    MyLog.d("***IT'S TOO HARD! MY BRAIN IS MELTING!!!");
                    break;
                default:
                    SQUARE[][] board = full_board[0].getSnapshot();
                    ArrayList<Move> empties = new ArrayList<>();
                    for (int y = 0; y < board.length; y++) {
                        for (int x = 0; x < board[0].length; x++) {
                            if (board[y][x].equals(SQUARE.EMPTY)) {
                                empties.add(new Move(x, y, _piece));
                            }
                        }
                    }
                    if (empties.size() < 1) {
                        MyLog.d("*********UNABLE TO FIND EMPTIES**********");
                    }
                    Collections.shuffle(empties);
                    for (Move m : empties) {
                        if (full_board[0].isValid(m.getX(), m.getY(), _piece)) {
                            rc = m;
                            break;
                        }
                    }
                    if (rc == null) {
                        MyLog.d("*********UNABLE TO FIND VALID MOVE IN (#" + empties.size() + ")**********");
                    }
                    break;
            }

            return (rc);
        }

        /**
         * Used for a progress indicator. Not currently used but might later on.
         *
         * @param o A parameter.
         */
        @Override
        protected void onProgressUpdate(Integer... o) {
            MyLog.d("Thinker<" + _name + ">.onProgressUpdate (" + o + ")");
        }

        /**
         * Called when Computer is done thinking.
         *
         * @param move The move.
         */
        @Override
        protected void onPostExecute(Move move) {
            MyLog.d("Thinker<" + _name + ">.onPostExecute (" + move + ")");

            // Sometimes during unit testing this is null - maybe because things
            // are shutdown before it finishes thinking?
            if (move != null) {
                _ma.handleBoardClick(move.toImageViewId());
            }
        }
    }

    /**
     * Handles the computer opponent.
     *
     * @param ma      Used to communicate move decisions to the main thread.
     * @param level   The level of play for this opponent.
     * @param name    The name of this opponent.
     * @param icon_id The icon used by this player.
     * @param piece   The piece used by this player.
     */
    public Computer(MainActivity ma,
                    COMPUTER_LEVEL level,
                    String name,
                    int icon_id,
                    SQUARE piece) {
        MyLog.d("Computer.Computer (" + ma + "," + level + "," + name + "," + icon_id + "," + piece + ")");

        _name = name;
        _icon_id = icon_id;
        _piece = piece;
        _ma = ma;
        _level = level;
        _shortest_time = Integer.MAX_VALUE;
        _num_moves = 0;
        _total_move_time = 0;
        _longest_time = Integer.MIN_VALUE;
    }

    /**
     * Return the player's name.
     *
     * @return The name.
     */
    public String getName() {
        return (_name);
    }

    /**
     * Return the player's icon.
     *
     * @return The icon.
     */
    public int getIconId() {
        return (_icon_id);
    }

    /**
     * Returns the piece used for this player.
     *
     * @return The player's piece.
     */
    public SQUARE getPiece() {
        return (_piece);
    }

    /**
     * Set's the computer playing level.
     *
     * @param new_level The level for this computer opponent.
     */
    public void setLevel(COMPUTER_LEVEL new_level) {
        _level = new_level;
    }

    /**
     * Who this player is.
     *
     * @return String representing this player.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Computer{");
        sb.append("_name=" + _name + ",");
        sb.append("_level=" + _level);
        sb.append("}");
        return (sb.toString());
    }

    @Override
    public void setMoveTime(long ticks) {
        _shortest_time = (ticks < _shortest_time) ? ticks : _shortest_time;
        _longest_time = (ticks > _longest_time) ? ticks : _longest_time;
        _num_moves++;
        _total_move_time += ticks;
    }

    @Override
    public int getMeanMoveTime() {
        int mean = (int) (_total_move_time/_num_moves);

        return (mean);
    }

    @Override
    public int getQuickestTime() {
        return ((int)_shortest_time);
    }

    @Override
    public int getLongestTime() {
        return ((int)_longest_time);
    }

    /**
     * Called to start thinking about the next move.
     *
     * @param board The game board.
     */
    public void startThinking(Board board) {
        MyLog.d("Computer<" + _name + ">.startThinking ()");

        new Thinker().execute(board);
    }

    /**
     * Currently not used.
     */
    public void stopThinking() {
        MyLog.d("Computer<" + _name + ">.stopThinking ()");
    }
}
