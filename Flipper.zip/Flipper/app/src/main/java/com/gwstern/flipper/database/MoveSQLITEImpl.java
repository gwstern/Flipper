package com.gwstern.flipper.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.gwstern.flipper.game.Move;
import com.gwstern.flipper.game.SQUARE;
import com.gwstern.flipper.util.MyLog;

import java.util.ArrayList;

/**
 * Implements the DAO for MyPros via serialization.
 */
public class MoveSQLITEImpl extends SQLiteOpenHelper implements IMoveDAO {

    private static final String DBNAME = "FlipperMoves";
    private static final String DBNAME_FILENAME = DBNAME + ".db";
    private static final int DBVERSION = 1;
    private static final String table_sql = "CREATE TABLE " + DBNAME +
            " (num integer not null," +
            " x integer not null," +
            " y integer not null," +
            " piece text not null)";

    private Context _context;

    /**
     * @param context
     */
    public MoveSQLITEImpl(Context context) {
        super(context, DBNAME_FILENAME, null, DBVERSION);

        _context = context;

        MyLog.d("MoveSQLITEImpl.MoveSQLITEImpl (" + context + ")");
    }

    /*
     * Implement the IMOveDAO interface
     */

    /**
     * @see IMoveDAO#getAll()
     */
    @Override
    public ArrayList<Move> getAll() {
        MyLog.d("MoveSQLITEImpl.getAll ()");

        ArrayList<Move> rc = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor crsr = db.query(DBNAME,
                new String[]{"num", "x", "y", "piece"},
                null, null, null, null, null);
        crsr.moveToFirst();
        while (!crsr.isAfterLast()) {
            Move move = new Move(crsr.getInt(0),
                    crsr.getInt(1),
                    crsr.getInt(2),
                    SQUARE.map(crsr.getString(3)));
            rc.add(move);
            crsr.moveToNext();
        }
        crsr.close();

        return (rc);
    }

    /**
     * @see IMoveDAO#add(int, int, int, SQUARE)
     */
    @Override
    public void add(int num, int x, int y, SQUARE piece) {
        MyLog.d("MoveSQLITEImpl.add (" + num + "," + x + "," + y + "," + piece + ")");

        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("num", num);
        cv.put("x", x);
        cv.put("y", y);
        cv.put("piece", piece.toString());

        long row = db.insert(DBNAME, null, cv);

        db.close();
    }

    /**
     * @see IMoveDAO#deleteLastMove()
     */
    @Override
    public void deleteLastMove() {
        MyLog.d("MoveSQLITEImpl.deleteLastMove ()");

        SQLiteDatabase db = getReadableDatabase();

        Cursor crsr = db.query(DBNAME,
                new String[]{"num", "x", "y", "piece"},
                null, null, null, null, null);
        crsr.moveToLast();
        Move move = new Move(crsr.getInt(0),
                crsr.getInt(1),
                crsr.getInt(2),
                SQUARE.map(crsr.getString(3)));
        MyLog.d("Last move=" + move);
        db.delete(DBNAME, "x=? and y=?", new String[]{"" + move.getX(), "" + move.getY()});
        crsr.close();

        db.close();
    }

    /**
     * @see IMoveDAO#eraseAll()
     */
    @Override
    public void eraseAll() {
        MyLog.d("MoveSQLITEImpl.eraseAll ()");

        SQLiteDatabase db = getWritableDatabase();

        db.delete(DBNAME, null, null);

        db.close();
    }

    /**
     * @see MoveSQLITEImpl#remove()
     */
    @Override
    public void remove() {
        MyLog.d("MoveSQLITEImpl.remove ()");

        _context.deleteDatabase(DBNAME);
    }

    /*
     * Extend the SQLiteOpenHelper
     */

    /**
     * @see SQLiteOpenHelper#onCreate(SQLiteDatabase)
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        MyLog.d("MoveSQLITEImpl.onCreate (" + db + ")");

        MyLog.d("SQL=" + table_sql);
        db.execSQL(table_sql);
    }

    /**
     * @see SQLiteOpenHelper#onUpgrade(SQLiteDatabase, int, int)
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        MyLog.d("MoveSQLITEImpl.onUpgrade (" + db + "," + oldVersion + "," + newVersion + ")");

        db.execSQL("DROP TABLE IF EXISTS " + DBNAME);

        onCreate(db);
    }
}
