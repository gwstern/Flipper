package com.gwstern.flipper.database;

import com.gwstern.flipper.game.Move;
import com.gwstern.flipper.game.SQUARE;

import java.util.ArrayList;

public interface IMoveDAO {
    /**
     * Retrieve moves from whatever data storage is used.
     *
     * @return A list of moves that have been made.
     */
    ArrayList<Move> getAll();

    /**
     * Add the passed move to the end of the list.
     *
     * @param num The number of move this is.
     * @param x X coordinate to move to.
     * @param y Y coordinate to move to.
     * @param piece The piece to place.
     */
    void add(int num, int x, int y, SQUARE piece);

    /**
     * Remove the last move from the list of moves.
     */
    void deleteLastMove();

    /**
     * Erase all moves in the data storage.
     */
    void eraseAll();

    /**
     * Remove the data storage.
     */
    void remove();
}
