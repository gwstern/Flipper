package com.gwstern.flipper.util;

/**
 * Create the matching types we need.
 */
public class EspressoTestMatchers {

    /**
     * The matcher the compares drawables.
     *
     * @param id The resource that we want to check.
     * @return A ViewMatcher representing this drawable.
     */
    public static DrawableMatcher withDrawable(final int id) {
        MyLog.v ("DrawableMatcher.withDrawable (" + id + ")");

        return new DrawableMatcher(id);
    }

    /**
     * A matcher that checks for an empty drawable.
     *
     * @return A ViewMatcher representing this drawable.
     */
    public static DrawableMatcher noDrawable() {
        MyLog.v ("DrawableMatcher.noDrawable ()");

        return new DrawableMatcher(DrawableMatcher.EMPTY);
    }

    /**
     * A matcher that checks for any drawable.
     *
     * @return A ViewMatcher representing this drawable.
     */
    public static DrawableMatcher hasDrawable() {
        MyLog.v ("DrawableMatcher.hasDrawable ()");

        return new DrawableMatcher(DrawableMatcher.ANY);
    }
}
