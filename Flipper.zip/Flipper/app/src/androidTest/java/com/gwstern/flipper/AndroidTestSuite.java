package com.gwstern.flipper;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Defines all the tests that are part of this suite
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        AboutTest.class,
        ClickTest.class,
        HelpTest.class,
        MyPropsParcelTest.class,
        RateItTest.class,
        SettingsTest.class,
        TickerTest.class,
        ComputerTest.class,
        IMoveDAOTest.class,
        GameTest.class,
        BoardTest.class,
})

public class AndroidTestSuite {
}
