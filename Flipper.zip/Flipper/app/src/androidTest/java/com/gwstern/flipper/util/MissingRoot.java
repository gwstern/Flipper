package com.gwstern.flipper.util;

import android.view.View;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.espresso.FailureHandler;
import androidx.test.espresso.NoMatchingRootException;
import androidx.test.espresso.base.DefaultFailureHandler;

import org.hamcrest.Matcher;

/**
 * Handles the NoMatchingRootException thrown when Expresso can't find a toast message.
 */
public class MissingRoot implements FailureHandler {
    // Our NoMatchingRootException handler
    private final FailureHandler defaultHandler
            = new DefaultFailureHandler(InstrumentationRegistry.getInstrumentation().getTargetContext());

    /**
     * Called when there's an assertion failure in the Hamcrest checks.
     *
     * @param error What caused the exception.
     * @param viewMatcher The match that the exception occurred in.
     */
    @Override public void handle(Throwable error, Matcher<View> viewMatcher) {
        MyLog.d ("MissingRoot.handle()");

        if (!(error instanceof NoMatchingRootException)) {
            defaultHandler.handle(error, viewMatcher);
        }
    }
}
