package com.gwstern.flipper;

import android.content.res.Resources;
import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper.game.Board;
import com.gwstern.flipper.game.Players;
import com.gwstern.flipper.toolbar.SETTING_KEYS;
import com.gwstern.flipper.toolbar.STARTING_POSITIONS;
import com.gwstern.flipper.util.MyLog;
import com.gwstern.flipper.util.MyProps;
import com.gwstern.flipper.util.MyUtils;

import org.hamcrest.Matcher;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.ThreadLocalRandom;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.AllOf.allOf;

/**
 * Test actual games with the various settings. Note that computer games are
 * tested elsewhere.
 */
@RunWith(AndroidJUnit4.class)
public class GameTest {
    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    // 'Presses' the 'quit' button
    private ViewAction _quit_action = new ViewAction() {
        @Override
        public Matcher<View> getConstraints() {
            return ViewMatchers.isEnabled(); // no constraints, they are checked above
        }

        @Override
        public String getDescription() {
            return ("don't care - required");
        }

        @Override
        public void perform(UiController uiController, View view) {
            view.performClick();
        }
    };

    /**
     * Run a game:
     * o) Two humans
     * o) Force capture
     * o) Start with blank board
     */
    @Test
    public void test_H2_Capture_Blank() {
        MyLog.d("GameTest.test_H2_Capture_Blank ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        // Check that the expected defaults didn't change since we last ran this
        // Really only need to check once
        Assert.assertEquals("H", props.get(SETTING_KEYS.PLAYER1_TYPE));
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals("true", props.get(SETTING_KEYS.FORCE_CAPTURE));
        Assert.assertEquals(STARTING_POSITIONS.EMPTY.toString(), props.get(SETTING_KEYS.START_WITH_4));

        Espresso.onView(withId(R.id.h2_or_c2))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        // A game that fills the entire board
        int[] moves = {
                R.id.posD4, R.id.posD5, R.id.posE5, R.id.posE4, R.id.posE3, R.id.posF3,
                R.id.posC5, R.id.posD3, R.id.posE2, R.id.posD6, R.id.posC3, R.id.posB3,
                R.id.posD7, R.id.posC6, R.id.posD2, R.id.posD8, R.id.posA3, R.id.posD1,
                R.id.posC7, R.id.posB5, R.id.posC4, R.id.posB4, R.id.posA5, R.id.posB6,
                R.id.posC2, R.id.posA4, R.id.posC1, R.id.posE6, R.id.posC8, R.id.posA6,
                R.id.posF6, R.id.posF5, R.id.posF4, R.id.posE1, R.id.posF1, R.id.posF2,
                R.id.posA7, R.id.posG5, R.id.posH5, R.id.posH6, R.id.posH7, R.id.posF7,
                R.id.posF8, R.id.posG4, R.id.posH4, R.id.posH3, R.id.posE7, R.id.posH8,
                R.id.posG3, R.id.posG8, R.id.posG6, R.id.posB7, R.id.posE8, R.id.posH2,
                R.id.posA2, R.id.posG7, R.id.posA8, R.id.posG1, R.id.posH1, R.id.posB2,
                R.id.posB1, R.id.posB8, R.id.posG2, R.id.posA1,
        };
        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            // Very last move
            if (i > (moves.length - 2)) {
                // Game is over
                Espresso.onView(withText("Nobody has moves left!"))
                        .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                        .check(matches(isDisplayed()));
            }

            // Slow things down so we can have some timing information to display
            MyUtils.sleep(ThreadLocalRandom.current().nextInt(1, 3 + 1));
        }

        Assert.assertEquals(30, b.countPlayerPieces(p.getPlayer(0)));
        Assert.assertEquals(34, b.countPlayerPieces(p.getPlayer(1)));

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);

        MyUtils.sleep(42);
    }

    /**
     * Run a game:
     * o) Two humans
     * o) Force capture
     * o) Start with green in upper left
     */
    @Test
    public void test_H2_Capture_GUL() {
        MyLog.d("GameTest.test_H2_Capture_GUL ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h2_or_c2))
                .perform(click());

        Espresso.onView(withId(R.id.starting_opposing1))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        // A game that fills the entire board
        int[] moves = {
                R.id.posE3, R.id.posF3,
                R.id.posC5, R.id.posD3, R.id.posE2, R.id.posD6, R.id.posC3, R.id.posB3,
                R.id.posD7, R.id.posC6, R.id.posD2, R.id.posD8, R.id.posA3, R.id.posD1,
                R.id.posC7, R.id.posB5, R.id.posC4, R.id.posB4, R.id.posA5, R.id.posB6,
                R.id.posC2, R.id.posA4, R.id.posC1, R.id.posE6, R.id.posC8, R.id.posA6,
                R.id.posF6, R.id.posF5, R.id.posF4, R.id.posE1, R.id.posF1, R.id.posF2,
                R.id.posA7, R.id.posG5, R.id.posH5, R.id.posH6, R.id.posH7, R.id.posF7,
                R.id.posF8, R.id.posG4, R.id.posH4, R.id.posH3, R.id.posE7, R.id.posH8,
                R.id.posG3, R.id.posG8, R.id.posG6, R.id.posB7, R.id.posE8, R.id.posH2,
                R.id.posA2, R.id.posG7, R.id.posA8, R.id.posG1, R.id.posH1, R.id.posB2,
                R.id.posB1, R.id.posB8, R.id.posG2, R.id.posA1,
        };
        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            // Very last move
            if (i > (moves.length - 2)) {
                // Game is over
                Espresso.onView(withText("Nobody has moves left!"))
                        .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                        .check(matches(isDisplayed()));
            }
        }

        Assert.assertEquals(30, b.countPlayerPieces(p.getPlayer(0)));
        Assert.assertEquals(34, b.countPlayerPieces(p.getPlayer(1)));

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two humans
     * o) Force capture
     * o) Start with red in upper left
     */
    @Test
    public void test_H2_Capture_RUL() {
        MyLog.d("GameTest.test_H2_Capture_RUL ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h2_or_c2))
                .perform(click());

        Espresso.onView(withId(R.id.starting_opposing2))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        // A game that fills the entire board
        int[] moves = {
                R.id.posE3, R.id.posF3,
                R.id.posC5, R.id.posD3, R.id.posE2, R.id.posD6, R.id.posC3, R.id.posB3,
                R.id.posD7, R.id.posC6, R.id.posD2, R.id.posD8, R.id.posA3, R.id.posD1,
                R.id.posC7, R.id.posB5, R.id.posC4, R.id.posB4, R.id.posA5, R.id.posB6,
                R.id.posC2, R.id.posA4, R.id.posC1, R.id.posE6, R.id.posC8, R.id.posA6,
                R.id.posF6, R.id.posF5, R.id.posF4, R.id.posE1, R.id.posF1, R.id.posF2,
                R.id.posA7, R.id.posG5, R.id.posH5, R.id.posH6, R.id.posH7, R.id.posF7,
                R.id.posF8, R.id.posG4, R.id.posH4, R.id.posH3, R.id.posE7, R.id.posH8,
                R.id.posG3, R.id.posG8, R.id.posG6, R.id.posB7, R.id.posE8, R.id.posH2,
                R.id.posA2, R.id.posG7, R.id.posA8, R.id.posG1, R.id.posH1, R.id.posB2,
                R.id.posB1, R.id.posB8, R.id.posG2, R.id.posA1,
        };

        p.flip();
        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            // Very last move
            if (i > (moves.length - 2)) {
                // Game is over
                Espresso.onView(withText("Nobody has moves left!"))
                        .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                        .check(matches(isDisplayed()));
            }
        }

        Assert.assertEquals(30, main.getActivity()._board.countPlayerPieces(main.getActivity()._players.getPlayer(0)));
        Assert.assertEquals(34, main.getActivity()._board.countPlayerPieces(main.getActivity()._players.getPlayer(1)));

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two humans
     * o) Force capture
     * o) Start with parallel
     */
    @Test
    public void test_H2_Capture_Parallel() {
        MyLog.d("GameTest.test_H2_Capture_Parallel ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h2_or_c2))
                .perform(click());

        Espresso.onView(withId(R.id.starting_opposing3))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        // A game that fills the entire board

        int[] moves = MyUtils.cvtDB2Moves(new String[]{
                "1|3|3|LIGHT", "2|3|4|DARK", "3|4|3|LIGHT", "4|4|4|DARK",
                "5|3|5|LIGHT", "6|2|2|DARK", "7|5|3|LIGHT", "8|3|6|DARK",
                "9|2|5|LIGHT", "10|1|5|DARK", "11|3|2|LIGHT", "12|4|2|DARK",
                "13|2|6|LIGHT", "14|2|7|DARK", "15|5|1|LIGHT", "16|5|2|DARK",
                "17|1|1|LIGHT", "18|4|5|DARK", "19|6|2|LIGHT", "20|0|0|DARK",
                "21|1|2|LIGHT", "22|4|1|DARK", "23|3|7|LIGHT", "24|2|3|DARK",
                "25|1|3|LIGHT", "26|0|2|DARK", "27|0|4|LIGHT", "28|0|5|DARK",
                "29|0|6|LIGHT", "30|6|1|DARK", "31|1|0|LIGHT", "32|0|3|DARK",
                "33|0|1|LIGHT", "34|0|7|DARK", "35|1|7|LIGHT", "36|7|1|DARK",
                "37|7|2|LIGHT", "38|2|1|DARK", "39|2|4|LIGHT", "40|3|1|DARK",
                "41|4|0|LIGHT", "42|2|0|DARK", "43|3|0|LIGHT", "44|5|0|DARK",
                "45|6|0|LIGHT", "46|7|0|DARK", "47|5|4|LIGHT", "48|1|6|DARK",
                "49|1|4|LIGHT", "50|4|7|DARK", "51|4|6|LIGHT", "52|5|7|DARK",
                "53|5|6|LIGHT", "54|6|5|DARK", "55|6|6|LIGHT", "56|5|5|DARK",
                "57|6|4|LIGHT", "58|7|7|DARK", "59|6|7|LIGHT", "60|7|6|DARK",
                "61|7|5|LIGHT", "62|7|4|DARK", "63|6|3|LIGHT", "64|7|3|DARK"
        });

        for (int i = 4; i < moves.length; i++) { // First four moves are already done
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            // Very last move
            if (i > (moves.length - 2)) {
                // Game is over
                Espresso.onView(withText("Nobody has moves left!"))
                        .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                        .check(matches(isDisplayed()));
            }
        }

        Assert.assertEquals(14, main.getActivity()._board.countPlayerPieces(main.getActivity()._players.getPlayer(0)));
        Assert.assertEquals(50, main.getActivity()._board.countPlayerPieces(main.getActivity()._players.getPlayer(1)));

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }
}