package com.gwstern.flipper;

import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper.game.Board;
import com.gwstern.flipper.game.COMPUTER_LEVEL;
import com.gwstern.flipper.game.Computer;
import com.gwstern.flipper.game.Players;
import com.gwstern.flipper.toolbar.SETTING_KEYS;
import com.gwstern.flipper.toolbar.STARTING_POSITIONS;
import com.gwstern.flipper.util.MyLog;
import com.gwstern.flipper.util.MyProps;
import com.gwstern.flipper.util.MyUtils;

import org.hamcrest.Matcher;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.ThreadLocalRandom;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.AllOf.allOf;

/**
 * Test the placement of pieces on the board. This class starts out simple and
 * as I test and play the game things I missed or edge cases or random thoughts
 * late at night get added. Personally, I prefer arrays and loops to simply
 * repeating perform(click()) or check().
 * And yes, I know it's not real Points I'm using but neither Java or Android has
 * a generic Pair class and I didn't feel the need to create one.
 */
@RunWith(AndroidJUnit4.class)
public class ComputerTest {
    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    // 'Presses' the 'quit' button
    private ViewAction _quit_action = new ViewAction() {
        @Override
        public Matcher<View> getConstraints() {
            return ViewMatchers.isEnabled(); // no constraints, they are checked above
        }

        @Override
        public String getDescription() {
            return ("don't care - required");
        }

        @Override
        public void perform(UiController uiController, View view) {
            view.performClick();
        }
    };

    /**
     * Run a game:
     * o) One Human and one computer (hardcoded moves)
     * o) Force capture
     * o) Start with blank board
     */
    @Test
    public void test_C2_Capture_Blank() {
        MyLog.d("GameTest.test_C2_Capture_Blank ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
//        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
//        Espresso.onView(withText("Settings"))
//                .perform(click());
//
//        Espresso.onView(withId(R.id.ok)).perform(click());

        // Check that the expected defaults didn't change since we last ran this
        // Really only need to check once
        Assert.assertEquals("H", props.get(SETTING_KEYS.PLAYER1_TYPE));
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals("true", props.get(SETTING_KEYS.FORCE_CAPTURE));
        Assert.assertEquals(STARTING_POSITIONS.EMPTY.toString(), props.get(SETTING_KEYS.START_WITH_4));

        //???
        ((Computer) p.getPlayer(1)).setLevel(COMPUTER_LEVEL.UT_2);

        // A game that fills the entire board
        int[] moves = {
                R.id.posD4, R.id.posE4, R.id.posD6,
                R.id.posF4, R.id.posC6, R.id.posD3,
                R.id.posC7, R.id.posF2, R.id.posB2,
                R.id.posG3, R.id.posB3, R.id.posD8,
                R.id.posB4, R.id.posA5, R.id.posA7,
                R.id.posB1, R.id.posA2, R.id.posB8,
                R.id.posH3, R.id.posC5, R.id.posE1,
                R.id.posD1, R.id.posG1, R.id.posF5,
                R.id.posB5, R.id.posE7, R.id.posF7,
                R.id.posG7, R.id.posG5, R.id.posG8,
                R.id.posH6, R.id.posG4,
        };
        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            // Very last move
            if (i > (moves.length - 2)) {
                // Game is over
                Espresso.onView(withText("Nobody has moves left!"))
                        .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                        .check(matches(isDisplayed()));
            }
        }

        Assert.assertEquals(14, b.countPlayerPieces(p.getPlayer(0)));
        Assert.assertEquals(50, b.countPlayerPieces(p.getPlayer(1)));

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two computers (hardcoded moves)
     * o) Force capture
     * o) Start with blank board
     */
    @Test
    public void test_C1_C2_Capture_Blank() {
        MyLog.d("GameTest.test_C1_C2_Capture_Blank ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h1_or_c1))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        // Check that the expected defaults didn't change since we last ran this
        // Really only need to check once
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER1_TYPE));
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals("true", props.get(SETTING_KEYS.FORCE_CAPTURE));
        Assert.assertEquals(STARTING_POSITIONS.EMPTY.toString(), props.get(SETTING_KEYS.START_WITH_4));

        ((Computer) p.getPlayer(0)).setLevel(COMPUTER_LEVEL.UT_1);
        ((Computer) p.getPlayer(1)).setLevel(COMPUTER_LEVEL.UT_2);

        ((Computer) main.getActivity()._players.getPlayer(0)).startThinking(main.getActivity()._board);

        // Not a production-quality way of waiting for the players to finish
        boolean p1;
        boolean p2;
        do {
            p1 = b.stillMoves(p.getPlayer(0));
            Thread.yield();
            p2 = b.stillMoves(p.getPlayer(1));
            Thread.yield();
        } while (p1 && p2);

        Assert.assertEquals(14, b.countPlayerPieces(p.getPlayer(0)));
        Assert.assertEquals(50, b.countPlayerPieces(p.getPlayer(1)));

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two computers
     * o) Force capture
     * o) Start with blank board
     */
    @Test
    public void test_C_Battle_Capture_Blank() {
        MyLog.d("GameTest.test_C_Battle_Capture_Blank ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h1_or_c1))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        // Check that the expected defaults didn't change since we last ran this
        // Really only need to check once
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER1_TYPE));
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals("true", props.get(SETTING_KEYS.FORCE_CAPTURE));
        Assert.assertEquals("Easy", props.get(SETTING_KEYS.PLAYER1_LEVEL));
        Assert.assertEquals("Easy", props.get(SETTING_KEYS.PLAYER2_LEVEL));
        Assert.assertEquals(STARTING_POSITIONS.EMPTY.toString(), props.get(SETTING_KEYS.START_WITH_4));

        ((Computer) main.getActivity()._players.getPlayer(0)).startThinking(main.getActivity()._board);

        // Not a production-quality way of waiting for the players to finish
        boolean p1;
        boolean p2;
        do {
            p1 = b.stillMoves(p.getPlayer(0));
            Thread.yield();
            p2 = b.stillMoves(p.getPlayer(1));
            Thread.yield();
        } while (p1 && p2);
        MyUtils.sleep(5); // Needed to let GUI catch up.

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two computers
     * o) Force capture
     * o) Start with green in upper left
     */
    @Test
    public void test_C_Battle_Capture_GUL() {
        MyLog.d("GameTest.test_C_Battle_Capture_GUL ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h1_or_c1))
                .perform(click());

        Espresso.onView(withId(R.id.starting_opposing1))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        ((Computer) main.getActivity()._players.getPlayer(0)).startThinking(main.getActivity()._board);

        // Not a production-quality way of waiting for the players to finish
        boolean p1;
        boolean p2;
        do {
            p1 = b.stillMoves(p.getPlayer(0));
            Thread.yield();
            p2 = b.stillMoves(p.getPlayer(1));
            Thread.yield();
        } while (p1 && p2);
        MyUtils.sleep(5); // Needed to let GUI catch up.

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two computers
     * o) Force capture
     * o) Start with red in upper left
     */
    @Test
    public void test_C_Battle_Capture_RUL() {
        MyLog.d("GameTest.test_C_Battle_Capture_RUL ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h1_or_c1))
                .perform(click());

        Espresso.onView(withId(R.id.starting_opposing2))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        ((Computer) main.getActivity()._players.getPlayer(0)).startThinking(main.getActivity()._board);

        // Not a production-quality way of waiting for the players to finish
        boolean p1;
        boolean p2;
        do {
            p1 = b.stillMoves(p.getPlayer(0));
            Thread.yield();
            p2 = b.stillMoves(p.getPlayer(1));
            Thread.yield();
        } while (p1 && p2);
        MyUtils.sleep(5); // Needed to let GUI catch up.

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }

    /**
     * Run a game:
     * o) Two computers
     * o) Force capture
     * o) Start with parallel
     */
    @Test
    public void test_C_Battle_Capture_Parallel() {
        MyLog.d("GameTest.test_C_Battle_Capture_Parallel ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        Espresso.onView(withId(R.id.h1_or_c1))
                .perform(click());

        Espresso.onView(withId(R.id.starting_opposing3))
                .perform(click());

        Espresso.onView(withId(R.id.ok)).perform(click());

        ((Computer) main.getActivity()._players.getPlayer(0)).startThinking(main.getActivity()._board);

        // Not a production-quality way of waiting for the players to finish
        boolean p1;
        boolean p2;
        do {
            p1 = b.stillMoves(p.getPlayer(0));
            Thread.yield();
            p2 = b.stillMoves(p.getPlayer(1));
            Thread.yield();
        } while (p1 && p2);
        MyUtils.sleep(5); // Needed to let GUI catch up.

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);
    }
}