package com.gwstern.flipper;

import android.widget.TextView;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper.ticker.TickerImpl;
import com.gwstern.flipper.util.MyLog;
import com.gwstern.flipper.util.MyUtils;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class TickerTest {

    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Called before each test
     */
    @Before
    public void getTicker() {
    }

    /**
     * Test the ticker.
     */
    @Test
    public void testTicker() {
        MyLog.d("TickerTest.testTicker ()");

        TickerImpl ticker_under_test = main.getActivity()._ticker;
        long start;
        long end;

        // Timer should start and count to 1
        ticker_under_test.start((TextView) main.getActivity().findViewById(R.id.ticker));
        start = ticker_under_test.getTicks();
//        MyLog.d ("start="+start);
        MyUtils.sleep(1);
        end = ticker_under_test.getTicks();
//        MyLog.d ("end="+end);
        Assert.assertTrue(start <= end && end <= start + 1);

        // Timer should run for 30 seconds
        start = ticker_under_test.getTicks();
//        MyLog.d("start=" + start);
        MyUtils.sleep(30);
        end = ticker_under_test.getTicks();
//        MyLog.d("end=" + end);
        Assert.assertTrue(start <= end && end <= start + 31);

        ticker_under_test.stop();

        // Timer should stop and not count anymore
        start = ticker_under_test.getTicks();
//        MyLog.d("start=" + start);
        MyUtils.sleep(30);
//        MyLog.d("end=" + end);
        Assert.assertEquals(start, end);
    }

    /**
     * Test pausing/resuming of ticker.
     */
    @Test
    public void testPauseResume() {
        MyLog.d("TickerTest.testPauseResume ()");

        TickerImpl ticker_under_test = main.getActivity()._ticker;
        long start;
        long end;

        // Timer should run for 5 seconds (Basically put some time on it)
        ticker_under_test.start((TextView) main.getActivity().findViewById(R.id.ticker));
        start = ticker_under_test.getTicks();
//        MyLog.d("start=" + start);
        MyUtils.sleep(5);
        end = ticker_under_test.getTicks();
//        MyLog.d("end=" + end);
        Assert.assertTrue(start <= end && end <= start + 6);

        // Pause the timer - no time should accrue
        start = ticker_under_test.getTicks();
//        MyLog.d("before pause: " + start);
        ticker_under_test.pause();
        MyUtils.sleep(10);
        end = ticker_under_test.getTicks();
//        MyLog.d("after pause: " + end);
        Assert.assertTrue(start <= end && end <= start + 1);

        // Start the timer. Time should start accruing.
//        MyLog.d("before resume: " + ticker_under_test.getTicks());
        ticker_under_test.resume();
        start = ticker_under_test.getTicks();
        MyUtils.sleep(10);
//        MyLog.d("after resume: " + ticker_under_test.getTicks());
        Assert.assertTrue(start <= end && end <= start + 11);

        ticker_under_test.stop();
    }

    /**
     * Test starting/stopping of ticker.
     */
    @Test
    public void testStartStop() {
        MyLog.d("TickerTest.testStartStop ()");

        TickerImpl ticker_under_test = main.getActivity()._ticker;
        long start;
        long end;
        int[] maxes = {5, 9, 6, 7, 10};

        // Start it but don't let it run.
        ticker_under_test.start((TextView) main.getActivity().findViewById(R.id.ticker));

        // Test it a few times with different values
        for (int i = 0; i < maxes.length; i++) {
            ticker_under_test.restart ();

            // (Restarted) Timer should run for 'max' seconds (Basically put some time on it)
            start = ticker_under_test.getTicks();
            MyLog.d ("(" + i + ") start="+start);
            MyUtils.sleep(maxes[i]);
            MyLog.d ("slept for "+maxes[i]);
            ticker_under_test.stop();
            end = ticker_under_test.getTicks();
            MyLog.d("end=" + end);
            Assert.assertTrue(start <= end && end <= start + (maxes[i]+1));
        }
    }

    /**
     * Test out of order calling. I.e. ensure that things don't throw exceptions.
     */
    @Test
    public void testOutOfOrder() {
        MyLog.d("TickerTest.testOutOfOrder ()");

        TickerImpl ticker_under_test = main.getActivity()._ticker;

        Assert.assertEquals(0, ticker_under_test.getTicks());
        ticker_under_test.restart();
        Assert.assertEquals(0, ticker_under_test.getTicks());
        ticker_under_test.stop();
        Assert.assertEquals(0, ticker_under_test.getTicks());
        ticker_under_test.pause();
        Assert.assertEquals(0, ticker_under_test.getTicks());
        ticker_under_test.resume();
        Assert.assertEquals(0, ticker_under_test.getTicks());

        // Timer should start and count to 3
        long start;
        long end;

        ticker_under_test.start((TextView) main.getActivity().findViewById(R.id.ticker));
        start = ticker_under_test.getTicks();
//        MyLog.d ("start="+start);
        MyUtils.sleep(3);
        end = ticker_under_test.getTicks();
//        MyLog.d ("end="+end);
        Assert.assertTrue(start <= end && end <= start + 3);
    }
}
