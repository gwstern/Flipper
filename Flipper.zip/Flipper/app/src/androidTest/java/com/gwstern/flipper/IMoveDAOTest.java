package com.gwstern.flipper;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper.database.IMoveDAO;
import com.gwstern.flipper.database.MoveSQLITEImpl;
import com.gwstern.flipper.game.Move;
import com.gwstern.flipper.game.SQUARE;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;

/**
 * Test the MyProps Property replacement
 */
@RunWith(AndroidJUnit4.class)
public class IMoveDAOTest {

    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Test that the hardcoded MyProps works
     */
    @Test
    public void SQLiteTests() {
        IMoveDAO db = new MoveSQLITEImpl(main.getActivity().getWindow().getContext());
        ArrayList<Move> actual;
        ArrayList<Move> expected;

        db.remove();

        // Database is empty
        actual = db.getAll ();
        Assert.assertEquals (0, actual.size());

        // Add some moves
        db.add (1, 1, 1, SQUARE.DARK);
        db.add (2, 2, 2, SQUARE.LIGHT);
        db.add (3, 3, 3, SQUARE.DARK);
        expected = new ArrayList<>();
        expected.add (new Move (1, 1,1, SQUARE.DARK));
        expected.add (new Move (2, 2,2, SQUARE.LIGHT));
        expected.add (new Move (3, 3,3, SQUARE.DARK));
        actual = db.getAll ();
        Assert.assertEquals (3, actual.size());
        // Note that Assert.assertEquals doesn't compare lists like one would
        // expect, so I use toString() which works in this case.
        Assert.assertEquals (expected.toString(), actual.toString());

        // Delete until they're all gon
        for (int i = 2; i >= 0; i--) {
            db.deleteLastMove();
            actual = db.getAll();
            expected.remove(i);
            Assert.assertEquals(i, actual.size());
            Assert.assertEquals(expected.toString(), actual.toString());
        }

        // Add some moves and then erase them all
        db.add (4, 4,4, SQUARE.DARK);
        db.add (5, 5,5, SQUARE.LIGHT);
        db.add (6, 6,6, SQUARE.DARK);
        db.add (7, 7,7, SQUARE.LIGHT);
        db.add (8, 8,8, SQUARE.DARK);
        db.add (9, 9,9, SQUARE.LIGHT);
        expected.add (new Move (4, 4,4, SQUARE.DARK));
        expected.add (new Move (5, 5,5, SQUARE.LIGHT));
        expected.add (new Move (6, 6,6, SQUARE.DARK));
        expected.add (new Move (7, 7,7, SQUARE.LIGHT));
        expected.add (new Move (8, 8,8, SQUARE.DARK));
        expected.add (new Move (9, 9,9, SQUARE.LIGHT));
        actual = db.getAll ();
        Assert.assertEquals (6, actual.size());
        // Note that Assert.assertEquals doesn't compare lists like one would
        // expect, so I use toString() which works in this case.
        Assert.assertEquals (expected.toString(), actual.toString());

        db.eraseAll ();
        actual = db.getAll ();
        Assert.assertEquals (0, actual.size());
    }
}
