package com.gwstern.flipper.util;

import com.gwstern.flipper.R;

import org.junit.Assert;

/**
 * Routines I find useful during unit testing.
 */
public class MyUtils {
    /**
     * Just a helper function to make the testing code easier to read.
     *
     * @param wait How long to sleep/pause/yield in seconds.
     */
    public static void sleep(long wait) {
        try {
            Thread.sleep(wait * 1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
            Assert.fail("Thread.sleep() failed - " + ie);
        }
    }

    /**
     * Since I find some of these tests by playing the game I wrote this routine
     * to take what's saved in FlipperMoves.db and convert it to a series of moves.
     * Since FlipperMoves.db isn't saved between runs and I didn't want to deal with
     * copying it, storing it, reading it I simply dump the contents (via sqlite3)
     * and paste it into an array of Strings.
     */
    public static int[] cvtDB2Moves(String[] db_moves) {
        final int[][] xlat = {
                {R.id.posA1, R.id.posB1, R.id.posC1, R.id.posD1, R.id.posE1, R.id.posF1, R.id.posG1, R.id.posH1},
                {R.id.posA2, R.id.posB2, R.id.posC2, R.id.posD2, R.id.posE2, R.id.posF2, R.id.posG2, R.id.posH2},
                {R.id.posA3, R.id.posB3, R.id.posC3, R.id.posD3, R.id.posE3, R.id.posF3, R.id.posG3, R.id.posH3},
                {R.id.posA4, R.id.posB4, R.id.posC4, R.id.posD4, R.id.posE4, R.id.posF4, R.id.posG4, R.id.posH4},
                {R.id.posA5, R.id.posB5, R.id.posC5, R.id.posD5, R.id.posE5, R.id.posF5, R.id.posG5, R.id.posH5},
                {R.id.posA6, R.id.posB6, R.id.posC6, R.id.posD6, R.id.posE6, R.id.posF6, R.id.posG6, R.id.posH6},
                {R.id.posA7, R.id.posB7, R.id.posC7, R.id.posD7, R.id.posE7, R.id.posF7, R.id.posG7, R.id.posH7},
                {R.id.posA8, R.id.posB8, R.id.posC8, R.id.posD8, R.id.posE8, R.id.posF8, R.id.posG8, R.id.posH8}
        };
        int[] rc = new int[db_moves.length];

        for (String move : db_moves) {
            String[] pieces = move.split("[|]");
            int num = Integer.valueOf(pieces[0]) - 1;
            int y = Integer.valueOf(pieces[1]);
            int x = Integer.valueOf(pieces[2]);

            rc[num] = xlat[x][y];
        }

        return (rc);
    }
}
