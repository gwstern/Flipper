package com.gwstern.flipper4;

import android.content.res.Resources;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.matcher.RootMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper4.toolbar.SETTING_KEYS;
import com.gwstern.flipper4.util.MyLog;
import com.gwstern.flipper4.util.MyProps;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withSpinnerText;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.IsAnything.anything;
import static org.hamcrest.core.IsNot.not;
import static org.hamcrest.core.StringContains.containsString;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class SettingsTest {
    private Resources _resources;

    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Called before every test
     */
    @Before
    public void setUp () {
        _resources = main.getActivity().getResources();
    }

    /**
     * Test that things can be changed on the board. Sorta neat to watch.
     */
    @Test
    public void testPlayer1() {
        MyLog.d("SettingsTest.testPlayer1 ()");

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        // Can't enter name if not human
        Espresso.onView(withId(R.id.edit_player1_name))
                .check(matches(isEnabled()));
        Espresso.onView(withId(R.id.h_or_c1))
                .perform(click());
        Espresso.onView(withId(R.id.edit_player1_name))
                .check(matches(not(isEnabled())));

        // Test name entry
        Espresso.onView(withId(R.id.h_or_c1))
                .perform(click());
        Espresso.onView(withId(R.id.edit_player1_name))
                .perform(replaceText("HumanPlayer"), closeSoftKeyboard());
        Espresso.onView(withId(R.id.edit_player1_name))
                .check(matches(withText("HumanPlayer")));

        // Test icon selection for player 1
        Espresso.onView(withId(R.id.spinner1))
                .perform(click());
        Espresso.onData(anything()).inRoot(RootMatchers.isPlatformPopup()).atPosition(0)
                .perform(click());
        Espresso.onView(withId(R.id.spinner1))
                .check(matches(withSpinnerText(containsString("piece1a"))));

        // Test the other switches
        Espresso.onView(withId(R.id.capture))
                .perform(click());
        Espresso.onView(withId(R.id.starting_layout))
                .perform(click());

        Espresso.onView(withId(R.id.ok))
                .perform(click());

        // Get the properties from MainActivity
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        Assert.assertEquals("H", props.get(SETTING_KEYS.PLAYER1_TYPE));
        Assert.assertEquals("HumanPlayer", props.get(SETTING_KEYS.PLAYER1_NAME));
        Assert.assertEquals("piece1a", props.get(SETTING_KEYS.PLAYER1_ICON));
        MyLog.d ("#2="+props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals(main.getActivity().getResources().getText(R.string.computer_player2_text), props.get(SETTING_KEYS.PLAYER2_NAME));
        Assert.assertEquals("piece4b", props.get(SETTING_KEYS.PLAYER2_ICON));
        Assert.assertEquals("false", props.get(SETTING_KEYS.FORCE_CAPTURE));
        Assert.assertEquals("true", props.get(SETTING_KEYS.START_WITH_4));
    }

    /**
     * Test that things can be changed on the board. Sorta neat to watch.
     */
    @Test
    public void testPlayer2() {
        MyLog.d("SettingsTest.testPlayer12()");

        // Bring up the settings dialog
        Espresso.openActionBarOverflowOrOptionsMenu(main.getActivity().getBaseContext());
        Espresso.onView(withText("Settings"))
                .perform(click());

        // Can't enter name if not human
        Espresso.onView(withId(R.id.h_or_c1))
                .perform(click());
        Espresso.onView(withId(R.id.edit_player1_name))
                .check(matches(not(isEnabled())));
        Espresso.onView(withId(R.id.edit_player1_name))
                .check(matches(withText(_resources.getString(R.string.computer_player1_text))));

        // Test name entry
        Espresso.onView(withId(R.id.h_or_c2))
                .perform(click());
        Espresso.onView(withId(R.id.h_or_c2))
                .perform(click()); // Should be a noop
        Espresso.onView(withId(R.id.edit_player2_name))
                .check(matches(not(isEnabled())));
        Espresso.onView(withId(R.id.edit_player2_name))
                .check(matches(withText(_resources.getString(R.string.computer_player2_text))));

        // Test icon selection for player 2
        Espresso.onView(withId(R.id.spinner2))
                .perform(click());
        Espresso.onData(anything()).inRoot(RootMatchers.isPlatformPopup()).atPosition(3)
                .perform(click());
        Espresso.onView(withId(R.id.spinner2))
                .check(matches(withSpinnerText(containsString("piece2b"))));

        Espresso.onView(withId(R.id.ok)).perform(click());

        // Get the properties from MainActivity
        MyProps<SETTING_KEYS> props = main.getActivity()._game_props;

        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER1_TYPE));
        Assert.assertEquals(_resources.getText(R.string.computer_player1_text), props.get(SETTING_KEYS.PLAYER1_NAME));
        Assert.assertEquals("piece4a", props.get(SETTING_KEYS.PLAYER1_ICON));
        Assert.assertEquals("C", props.get(SETTING_KEYS.PLAYER2_TYPE));
        Assert.assertEquals(main.getActivity().getResources().getText(R.string.computer_player2_text), props.get(SETTING_KEYS.PLAYER2_NAME));
        Assert.assertEquals("piece2b", props.get(SETTING_KEYS.PLAYER2_ICON));
        Assert.assertEquals("true", props.get(SETTING_KEYS.FORCE_CAPTURE));
        Assert.assertEquals("false", props.get(SETTING_KEYS.START_WITH_4));
    }
}
