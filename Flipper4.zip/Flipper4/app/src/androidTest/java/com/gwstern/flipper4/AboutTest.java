package com.gwstern.flipper4;

import android.content.res.Resources;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper4.toolbar.AboutActivity;
import com.gwstern.flipper4.util.MyLog;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isCompletelyDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.core.AllOf.allOf;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class AboutTest {
    private Resources _resources;

    // Annotation for testing the About Box Activity
    @Rule
    public final ActivityTestRule<AboutActivity> main = new ActivityTestRule<>(AboutActivity.class, true);

    /**
     * Called before every test
     */
    @Before
    public void setUp () {
        _resources = main.getActivity().getResources();
    }

    /**
     * Test the help dialog comes up and that everything can be selected.
     */
    @Test
    public void testAboutBox() {
        MyLog.d("AboutTest.testAboutBox()");

        Espresso.onView(allOf(withId(R.id.about_title), isCompletelyDisplayed()))
                .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)))
                .check(matches(withText(_resources.getString(R.string.about_title))));

        Espresso.onView(allOf(withId(R.id.about_details), isCompletelyDisplayed()))
                .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)))
                .check(matches(withText(_resources.getString(R.string.about_content))));

        Espresso.onView(withId(R.id.ok)).perform(click());

        try {
            main.getActivityResult();
        } catch (IllegalStateException ise) {
            Assert.assertTrue(false);
        }
    }
}
