package com.gwstern.flipper4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Defines all the tests that are part of this suite
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        MyPropsTest.class,
        SQUARETest.class,
})

public class TestSuite {
}
