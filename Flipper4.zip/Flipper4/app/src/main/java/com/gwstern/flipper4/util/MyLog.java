package com.gwstern.flipper4.util;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

/**
 * Helper functions for logging. Cuze I get tired of typing '#GWS' on all my
 * log messages.
 *
 * There should be enough variety that you should never need to remove or comment
 * out logging. Cuze as soon as you do something will go horribly wrong and when you
 * add the logging statements back in things will work.
 */
public class MyLog {
    /**
     * The equivalent of android.util.Log.d. Used for debugging.
     *
     * @param msg The message.
     */
    public static void d(String msg) {
        Log.d("#GWS", msg);
    }

    /**
     * The equivalent of android.util.Log.e. Used when something bad happens.
     *
     * @param msg The message.
     */
    public static void e(String msg) {
        Log.e("#GWS", msg);
    }

    /**
     * The equivalent of android.util.Log.w. Used when this might be something bad.
     *
     * @param msg The message.
     */
    public static void w(String msg) {
        Log.w("#GWS", msg);
    }

    /**
     * The equivalent of android.util.Log.i. Used for general logging purposes.
     *
     * @param msg The message.
     */
    public static void i(String msg) {
        Log.i("#GWS", msg);
    }

    /**
     * The equivalent of android.util.Log.v. Used for *very* detailed logging.
     *
     * @param msg The message.
     */
    public static void v(String msg) {
        Log.v("#GWS", msg);
    }

    /**
     * Called when the program has lost its marbles and there's no hope of recovery.
     * The equivalent of android.util.Log.wtf but with a Toast message.
     *
     * @param ctx App context.
     * @param msg What happened.
     * @param ex Java's view of what happened.
     */
    public static void wtf(Context ctx,
                           String msg,
                           Throwable ex) {
        Toast.makeText(ctx,
                msg + ex,
                Toast.LENGTH_LONG).show();

        Log.wtf("#GWS", msg, ex);
    }

    public static void wtf(Context ctx,
                           String msg) {
        Toast.makeText(ctx,
                msg,
                Toast.LENGTH_LONG).show();

        Log.wtf("#GWS", msg);
    }

    public static void wtf(String msg) {
        Log.wtf("#GWS", msg);
    }
}