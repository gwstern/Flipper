package com.gwstern.flipper6.database;

import com.gwstern.flipper6.toolbar.SETTING_KEYS;
import com.gwstern.flipper6.util.MyProps;

/**
 * Interface defining storage operations that can be performed on MyProps
 */
public interface IMyPropsDAO {
    /**
     * Retrieve MyProps from whatever data storage is used.
     *
     * @return MyProps.
     */
    MyProps<SETTING_KEYS> getAll();

    /**
     * Store the passed MyProps.
     *
     * @param to_save The instance to save.
     */
    void saveAll(MyProps<SETTING_KEYS> to_save);

    /**
     * Reset this instance back to default values. Sometimes things get so out
     * of wack we need to reset back to good/known values. Useful for unit
     * testing as well.
     */
    void reset();
}
