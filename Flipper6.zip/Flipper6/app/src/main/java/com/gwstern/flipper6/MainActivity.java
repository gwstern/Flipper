/**
 * This is a simple Reversi/Othello-type program designed to show how one might
 * build an Android application. Each successive app builds on the previous one.
 * <p>
 * History:
 * 10 Jul 2019 Added logging, improved comments, brought up to production
 *             standards
 * 17 Jul 2019 Converted to use AndroidX
 *             Added unit testing
 *             Added layouts
 *             Updated manifest
 * 25 Jul 2019 Added fragments and intents
 *  1 Jul 2019 Added styles and themes
 *             Added action bar and menus
 * 10 Jul 2019 Added navigation bar
 *             Incorporated expresson testing for navigation bar
 * 22 Jul 2019 Added serialization and SQLite capabilities
 *             Expanded unit testing
 *             Fixed various bugs
 */
package com.gwstern.flipper6;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.os.Parcelable;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.gwstern.flipper6.database.IMyPropsDAO;
import com.gwstern.flipper6.database.MoveSQLITEImpl;
import com.gwstern.flipper6.database.MyPropsHardcodeImpl;
import com.gwstern.flipper6.game.Board;
import com.gwstern.flipper6.game.Human;
import com.gwstern.flipper6.game.Move;
import com.gwstern.flipper6.game.Players;
import com.gwstern.flipper6.game.SQUARE;
import com.gwstern.flipper6.help.HelpDialogFragment;
import com.gwstern.flipper6.ticker.TickerImpl;
import com.gwstern.flipper6.toolbar.AboutActivity;
import com.gwstern.flipper6.toolbar.RateItActivity;
import com.gwstern.flipper6.toolbar.SETTING_KEYS;
import com.gwstern.flipper6.toolbar.SettingsDialogFragment;
import com.gwstern.flipper6.util.MyLog;
import com.gwstern.flipper6.util.MyProps;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This is where it all begins. Class currently does nothing more than run a
 * app that has a simple menu, FAB and greeting
 * <p>
 * <p>
 * https://en.wikipedia.org/wiki/Reversi
 * https://bonaludo.com/2016/02/18/reversi-and-othello-two-different-games-do-you-know-their-different-rules/
 * https://www.yourturnmyturn.com/rules/reversi.php
 */
public class MainActivity extends AppCompatActivity implements SettingsDialogFragment.SettingsListener, NavigationView.OnNavigationItemSelectedListener {

    /*package*/ MyProps<SETTING_KEYS> _game_props = new MyProps<>();
    /*package*/ TickerImpl _ticker;
    /*package*/ Players _players;
    /*package*/ Board _board;
    private MoveSQLITEImpl _db;
    private boolean _paused;

    /**
     * I like to have at least *some* information displayed if the program
     * exists unexpectedly.
     */
    public MainActivity() {
        Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread,
                                          Throwable ex) {
                MyLog.wtf(getApplicationContext(), "uncaughtException - ", ex);
            }
        });
    }

    /**
     * Called when the window is created.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it
     *                           has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("MainActivity.onCreate (" + savedInstanceState + ")");

        // Create the layout
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Create the navigation drawer
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_bar, R.string.close_bar);

        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        // Create the instance that will handle MyProps
        IMyPropsDAO myprops_dao = new MyPropsHardcodeImpl();

        _game_props = myprops_dao.getAll();
        _paused = false;

        // Create a timer
        _ticker = new TickerImpl();
        _ticker.start((TextView) findViewById(R.id.ticker));
        _ticker.stop();

        // Create the database
        _db = new MoveSQLITEImpl(getApplicationContext());
        _db.eraseAll();

        // Define some actions for the buttons on the bottom
        final ImageButton ib = findViewById(R.id.pause);

        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (_paused) {
                    unpauseGame(view.getRootView());
                } else {
                    pauseGame(view.getRootView());
                }
            }
        });

        // Both the way below and the way above are valid syntax. One can also
        // have MainActivity implement View.OnClickListener() as well. I like the
        // lower one if I will never use the variable and the action is simple.
        findViewById(R.id.quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<quit> (" + view + ")");

                resetGame(view.getRootView());
            }
        });

        findViewById(R.id.help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<help> (" + view + ")");

                pauseGame(view.getRootView());

                HelpDialogFragment hdf = HelpDialogFragment.newInstance();
                hdf.show(getSupportFragmentManager(), "help fragement");
            }
        });

        // Currently not selectable by the user
        findViewById(R.id.undo).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<undoLastMove> (" + view + ")");

                if (_board.undoLastMove(_db.getAll())) {
                    _players.prev();
                    _db.deleteLastMove();
                }
            }
        });

        // Yeah, still a bit ugly but at least it's an array and a loop rather
        // than a bunch of statements.
        View[][] views = {
                {findViewById(R.id.posA1), findViewById(R.id.posB1), findViewById(R.id.posC1), findViewById(R.id.posD1), findViewById(R.id.posE1), findViewById(R.id.posF1), findViewById(R.id.posG1), findViewById(R.id.posH1)},
                {findViewById(R.id.posA2), findViewById(R.id.posB2), findViewById(R.id.posC2), findViewById(R.id.posD2), findViewById(R.id.posE2), findViewById(R.id.posF2), findViewById(R.id.posG2), findViewById(R.id.posH2)},
                {findViewById(R.id.posA3), findViewById(R.id.posB3), findViewById(R.id.posC3), findViewById(R.id.posD3), findViewById(R.id.posE3), findViewById(R.id.posF3), findViewById(R.id.posG3), findViewById(R.id.posH3)},
                {findViewById(R.id.posA4), findViewById(R.id.posB4), findViewById(R.id.posC4), findViewById(R.id.posD4), findViewById(R.id.posE4), findViewById(R.id.posF4), findViewById(R.id.posG4), findViewById(R.id.posH4)},
                {findViewById(R.id.posA5), findViewById(R.id.posB5), findViewById(R.id.posC5), findViewById(R.id.posD5), findViewById(R.id.posE5), findViewById(R.id.posF5), findViewById(R.id.posG5), findViewById(R.id.posH5)},
                {findViewById(R.id.posA6), findViewById(R.id.posB6), findViewById(R.id.posC6), findViewById(R.id.posD6), findViewById(R.id.posE6), findViewById(R.id.posF6), findViewById(R.id.posG6), findViewById(R.id.posH6)},
                {findViewById(R.id.posA7), findViewById(R.id.posB7), findViewById(R.id.posC7), findViewById(R.id.posD7), findViewById(R.id.posE7), findViewById(R.id.posF7), findViewById(R.id.posG7), findViewById(R.id.posH7)},
                {findViewById(R.id.posA8), findViewById(R.id.posB8), findViewById(R.id.posC8), findViewById(R.id.posD8), findViewById(R.id.posE8), findViewById(R.id.posF8), findViewById(R.id.posG8), findViewById(R.id.posH8)}
        };
        MyLog.d("force=" + _game_props.get(SETTING_KEYS.FORCE_CAPTURE));
        MyLog.d("4=" + _game_props.get(SETTING_KEYS.START_WITH_4));
        _board = new Board(views,
                !_game_props.get(SETTING_KEYS.FORCE_CAPTURE).equalsIgnoreCase("false"),
                !_game_props.get(SETTING_KEYS.START_WITH_4).equalsIgnoreCase("false"));

        // Set player info
        ((TextView) findViewById(R.id.player1_name)).setText(_game_props.get(SETTING_KEYS.PLAYER1_NAME));
        ((TextView) findViewById(R.id.player2_name)).setText(_game_props.get(SETTING_KEYS.PLAYER2_NAME));

        Human player1 = new Human(_game_props.get(SETTING_KEYS.PLAYER1_NAME), R.drawable.light_piece, SQUARE.LIGHT);
        Human player2 = new Human(_game_props.get(SETTING_KEYS.PLAYER2_NAME), R.drawable.dark_piece, SQUARE.DARK);
        _players = new Players(player1, player2);
    }

    /**
     * Helper function to ensure that everywhere the game is reset it does
     * the same thing.
     *
     * @param view The parent view of what's being updated.
     */
    private void resetGame(View view) {
        MyLog.d("MainActivity.resetGame (" + view + ")");

        ImageButton ib = view.findViewById(R.id.pause);
        ib.setImageResource(android.R.drawable.ic_media_pause);

        _ticker.stop();
        _paused = false;
        _board.reset();
        _players.reset();

        updateCaptureCount(view,
                0,
                0,
                0);
    }

    /**
     * Helper function to ensure that everywhere the game is paused it does
     * the same thing.
     *
     * @param view The parent view of what's being updated.
     */
    private void pauseGame(View view) {
        MyLog.d("MainActivity.pauseGame (" + view + ")");

        ImageButton ib = view.findViewById(R.id.pause);
        ib.setImageResource(android.R.drawable.ic_media_play);

        _ticker.pause();
        _paused = true;
    }

    /**
     * Helper function to ensure that everywhere the game is unpaused it does
     * the same thing.
     *
     * @param view The parent view of what's being updated.
     */
    private void unpauseGame(View view) {
        MyLog.d("MainActivity.unpauseGame (" + view + ")");

        ImageButton ib = view.findViewById(R.id.pause);
        ib.setImageResource(android.R.drawable.ic_media_pause);

        _ticker.resume();
        _paused = false;
    }

    /**
     * Helper function to ensure that everywhere the game sets the player piece
     * count it's done the same way.
     *
     * @param view    The parent view of what's being updated.
     * @param player1 The number of pieces captured for player #1.
     * @param player2 The number of pieces captured for player #2.
     */
    private void updateCaptureCount(View view, int current_player, int player1, int player2) {
        MyLog.d("MainActivity.updateCaptureCount (" + view + "," + current_player + "," + player1 + "," + player2 + ")");

        TextView tv = view.getRootView().findViewById(R.id.player1_score);
        String count = Integer.toString(player1); // Needs to be a String otherwise it conflicts with TextView.setText(<resource id>)

        // Set the first player's name, count and active status
        tv = view.getRootView().findViewById(R.id.player1_score);
        tv.setText(count);
        if (current_player == 0) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }

        tv = view.getRootView().findViewById(R.id.player1_name);
        if (current_player == 0) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }

        // Set the second player's name, count and active status
        tv = view.getRootView().findViewById(R.id.player2_score);
        count = Integer.toString(player2);
        tv.setText(count);
        if (current_player == 1) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }

        tv = view.getRootView().findViewById(R.id.player2_name);
        if (current_player == 1) {
            tv.setTypeface(null, Typeface.BOLD);
        } else {
            tv.setTypeface(null, Typeface.NORMAL);
        }
    }

    /**
     * Rather than setting setOnClickListener() for every board piece as we did in the
     * previous versions we simply define a method that handles the clicks and set
     * onClick in styles.xml.
     *
     * @param view The view (ImageView) of this board position.
     */
    public void handleBoardClick(View view) {
        MyLog.d("MainActivity.handleBoardClick (" + view + ")");

        ImageView iv = (ImageView) view;

        // In order to translate click coordinates we need to know where the
        // board is relative to the screen because the coordinates are given
        // relative to the screen. So view is the piece position, view.getParent()
        // is the TableRow, view.getParent().getParent() is the TableLayout
        // and view.getParent().getParent().getParent() is the ConstraintLayout
        // everything is in. So getChildVisibleRect asks ConstraintLayout
        // where the TableLayout is.
        Rect table = new Rect(0, 0, 42, 42);
        view.getParent().getParent().getParent().getChildVisibleRect((View) (view.getParent().getParent()), table, null);

        Rect r = new Rect(0, 0, 42, 42);
        view.getParent().getChildVisibleRect(view, r, null);

        int x = Math.round((float) (r.left - table.left) / (float) view.getWidth());
        int y = Math.round((float) (r.top - table.top) / (float) view.getHeight());

        // Check desired move
        if (_board.isValid(x, y, _players.getCurrentPlayer().getPiece())) {
            // stop timer
            _ticker.stop();

            // Move piece and flip any captures
            _board.makeMove(x, y, _players.getCurrentPlayer());
            _db.add(_board.getMoveNum(), x, y, _players.getCurrentPlayer().getPiece());

            _players.next();

            // Update board
            updateCaptureCount(view,
                    _players.getCurrentPlayerNumber(),
                    _board.countPlayerPieces(_players.getPlayer(0)),
                    _board.countPlayerPieces(_players.getPlayer(1)));

            if (!_board.stillMoves(_players.getCurrentPlayer())) {
                if (_board.stillMoves(_players.checkNextPlayer())) {
                    MyLog.d ("a player is in deep doodoo");
                    Snackbar.make(view, _players.getCurrentPlayer().getName() + " has no moves left!", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                } else {
                    MyLog.d ("game is done");
                    Snackbar.make(view, "Nobody has moves left!", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }

            // start timer
            _ticker.restart();
        }
    }

    /**
     * Called when a fragment is attached as a child of this fragment.
     *
     * @param f Child fragment being attached.
     */
    @Override
    public void onAttachFragment(Fragment f) {
        MyLog.d("MainActivity.onAttachFragment (" + f + ")");

        if (f instanceof SettingsDialogFragment) {
            ((SettingsDialogFragment) f).setMyListener(this);
        }
    }

    /**
     * Method called when the settings have changed.
     *
     * @param new_settings New settings if !null
     */
    public void getNewSettings(MyProps<SETTING_KEYS> new_settings) {
        MyLog.d("MainActivity.getNewSettings (" + new_settings + ")");

        if (new_settings != null) {
            _game_props.clear();
            _game_props.putAll(new_settings);
        }
    }

    /**
     * Creates the options menu for the main activity.
     *
     * @param menu The instance selected.
     * @return true to display the menu; false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MyLog.d("MainActivity.onCreateOptionsMenu (" + menu + ")");

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callAboutActivity(MenuItem item) {
        MyLog.d("MainActivity.callAboutActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), AboutActivity.class);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);

            // To be consistent with the other menu items we close the navigation drawer
            ((DrawerLayout) findViewById(R.id.drawer_layout)).closeDrawer(GravityCompat.START);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'AboutActivity'");
        }
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callRateItActivity(MenuItem item) {
        MyLog.d("MainActivity.callRateItActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), RateItActivity.class);

        intent.putExtra("PROPS", (Parcelable) _game_props);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'RateItActivity'");
        }
    }

    /**
     * Since some menu items can be called from the nav drawer or from the drop
     * down menu we handle all menu items here.
     *
     * @param item The item selected.
     * @return true if the selection has been processed.
     */
    private boolean handleMenuItems(MenuItem item) {
        MyLog.d("MainActivity.handleMenuItems (" + item + ")");
        boolean rc = false;

        switch (item.getItemId()) {
            case R.id.app_settings:
                SettingsDialogFragment sdf = SettingsDialogFragment.newInstance(_game_props);
                // Seems the default for dialogs is no window title after API 23
                // so we have to 'fix' that by setting R.style.DialogFragment
                sdf.setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragment);
                sdf.show(getSupportFragmentManager(), "settings_fragment");

                rc = true;
                break;

            case R.id.report_bug:
                // Create a popup dialog with an entry field and two buttons
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                final EditText et = new EditText(getApplicationContext());

                alertDialogBuilder.setView(et);

                // Send the bug report
                alertDialogBuilder.setCancelable(false).setPositiveButton(getApplicationContext().getString(R.string.submit_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d("MainActivity.onClick<ok> (" + dialog + "," + id + ")");

                        // Send a email bug report via email
                        Intent email_intent = new Intent(Intent.ACTION_SENDTO);
                        String[] addresses = {getApplicationContext().getString(R.string.bug_email_text),};

                        email_intent.setData (Uri.fromParts(
                                "mailto", getApplicationContext().getString(R.string.bug_email_text), null));
                        email_intent.putExtra(Intent.EXTRA_SUBJECT, getApplicationContext().getString(R.string.email_subject_text));
                        email_intent.putExtra(Intent.EXTRA_TEXT, et.getText());
                        email_intent.putExtra(Intent.EXTRA_EMAIL, addresses); // Android 4.3 requires an additional field with email addresses

                        try {
                            ArrayList<Move> moves = _db.getAll();
                            File file = new File(getApplicationContext().getExternalCacheDir(), "moves.txt");
                            FileWriter writer = new FileWriter(file);

                            for(Move m: moves) {
                                writer.write(m + System.lineSeparator());
                            }
                            writer.close();

                            Uri uri = Uri.fromFile(file);
                            email_intent.putExtra(Intent.EXTRA_STREAM, uri);
                        } catch (IOException e) {
                            MyLog.e ("Unable to retrieve lists of moves!!!");
                        }

                        startActivity(Intent.createChooser(email_intent, getApplicationContext().getString(R.string.sending_email_text)));
                    }
                });

                // Close the report and return to program
                alertDialogBuilder.setCancelable(false).setNegativeButton(getApplicationContext().getString(R.string.cancel_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d("MainActivity.onClick<cancel> (" + dialog + "," + id + ")");
                    }
                });

                // Show the dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.setTitle(R.string.describe_bug_text);
                alertDialog.show();

                rc = true;
                break;

            default:
                rc = super.onOptionsItemSelected(item);
                break;
        }

        return (rc);
    }

    /**
     * Handle action bar item clicks here. The action bar will
     * automatically handle clicks on the Home/Up button, so long
     * as you specify a parent activity in AndroidManifest.xml.
     *
     * @param item The menu item selected.
     * @return false to allow normal menu processing; true to consume it.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onOptionsItemSelected (" + item + ")");

        boolean rc = handleMenuItems(item);

        if (!rc) {
            rc = super.onOptionsItemSelected(item);
        }

        return (rc);
    }

    /**
     * Called when an item in the navigation drawer is selected.
     *
     * @param item The item selected.
     * @return true to display the item; (?) false not to display it.
     */
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onNavigationItemSelected (" + item + ")");

        // Handle navigation view item clicks here.

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        handleMenuItems(item);

        return true;
    }

    /**
     * Called when the back key is pressed. Here we close the drawer if it's
     * open otherwise let Android handle it.
     */
    @Override
    public void onBackPressed() {
        MyLog.d("MainActivity.onBackPressed ()");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
