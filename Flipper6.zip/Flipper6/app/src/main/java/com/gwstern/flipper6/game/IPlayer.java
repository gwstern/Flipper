package com.gwstern.flipper6.game;

/**
 * The interface that defines a player's methods.
 */
public interface IPlayer {
    /**
     * Return the name of the player.
     *
     * @return The player's name.
     */
    String getName();

    /**
     * Get the ID representing the player's piece.
     *
     * @return Android ID of the player's piece
     */
    int getIconId();

    /**
     * Return the piece (i.e. DARK/LIGHT) that represents this player.
     *
     * @return DARK/LIGHT.
     */
    SQUARE getPiece();

    /**
     * Convert this player to a readable string.
     *
     * @return The player, in a line (or two).
     */
    String toString();
}
