package com.gwstern.flipper6.game;

import com.gwstern.flipper6.util.MyLog;

public class Human implements IPlayer {
    private String _name;
    private int _icon_id;
    private SQUARE _piece;

    public Human(String name,
                 int icon_id,
                 SQUARE piece) {
        MyLog.d ("Human.Human (" + name + "," + icon_id + "," + piece + ")");

        _name = name;
        _icon_id = icon_id;
        _piece = piece;
    }

    public String getName() {
        return (_name);
    }

    public int getIconId() {
        return (_icon_id);
    }

    public SQUARE getPiece () {
        return (_piece);
    }

    @Override
    public String toString () {
        return ("Human: " + _name);
    }
}
