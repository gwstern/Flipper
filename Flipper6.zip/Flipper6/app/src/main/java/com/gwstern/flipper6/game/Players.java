package com.gwstern.flipper6.game;

import com.gwstern.flipper6.util.IntCycle;
import com.gwstern.flipper6.util.MyLog;

import java.util.Arrays;
import java.util.Iterator;

/**
 * This class handles the players and requests for players to do things
 */
public class Players implements Iterable<IPlayer> {
    private IPlayer[] _players;
    private IntCycle _curr_player;

    /**
     * Create a player handler with however many players are needed.
     *
     * @param args The various players.
     */
    public Players(IPlayer... args) {
        MyLog.d ("Players.Players (" + Arrays.toString(args) + ")");

        int num_players = args.length;

        _players = new IPlayer[num_players];
        _curr_player = new IntCycle(num_players);

        num_players = 0;
        for (IPlayer p : args) {
            _players[num_players++] = p;
        }
    }

    /**
     * Change starting player
     */
    public void flip () {
        IPlayer tmp = _players[0];
        _players[0] = _players[1];
        _players[1] = tmp;
    }

    /**
     * Return the number of the current player.
     *
     * @return The current player number.
     */
    public int getCurrentPlayerNumber() {
        MyLog.d ("Players.getCurrentPlayerNumber ()");

        return (_curr_player.getCount());
    }

    /**
     * Return the current player.
     *
     * @return The current player.
     */
    public IPlayer getCurrentPlayer() {
        MyLog.d ("Players.getCurrentPlayer ()");

        return (_players[_curr_player.getCount()]);
    }

    /**
     * Return who the next player would be.
     *
     * @return Who the next player would be.
     */
    public IPlayer checkNextPlayer() {
        MyLog.d ("Players.checkNextPlayer ()");

        return (_players[_curr_player.checkNext()]);
    }

    /**
     * Retrieve a specific player.
     *
     * @param which_one Which player to retrieve.
     * @return The player's information.
     */
    public IPlayer getPlayer (int which_one) {
        MyLog.d ("Players.getPlayer(" + which_one + ")");

        return (_players[which_one]);
    }

    /**
     * Go to the next player, wrapping to the first one if necessary.
     *
     * @return The next player.
     */
    public IPlayer next() {
//        MyLog.d ("Players.next ()");

        return (_players[_curr_player.next()]);
    }

    /**
     * Go to the previous player, wrapping to the last player if necessary.
     *
     * @return The previous player.
     */
    public IPlayer prev() {
//        MyLog.d ("Players.prev ()");

        return (_players[_curr_player.prev()]);
    }

    /**
     * Reset the player handler.
     */
    public void reset() {
        MyLog.d ("Players.reset ()");

        _curr_player.reset();
    }

    /*
     * Implements Iterator interface
     */

    /**
     * Returns an iterator over a set of elements of type IPlayer.
     *
     * @return The Iterator.
     */
    @Override
    public Iterator<IPlayer> iterator() {
        Iterator<IPlayer> it = new Iterator<IPlayer>() {

            private int currentIndex = 0;

            @Override
            public boolean hasNext() {
                return currentIndex < _players.length && _players[currentIndex] != null;
            }

            @Override
            public IPlayer next() {
                return _players[currentIndex++];
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };

        return (it);
    }
}
