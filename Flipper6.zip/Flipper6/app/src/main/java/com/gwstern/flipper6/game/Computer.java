package com.gwstern.flipper6.game;


import com.gwstern.flipper6.util.MyLog;

public class Computer implements IPlayer {
    private String _name;
    private int _icon_id;
    private SQUARE _piece;

    public Computer(String name,
                    int icon_id,
                    SQUARE piece) {
        MyLog.d("Computer.Computer (" + name + "," + icon_id + "," + piece + ")");

        _name = name;
        _icon_id = icon_id;
    }

    public String getName() {
        return (_name);
    }

    public int getIconId() {
        return (_icon_id);
    }

    public SQUARE getPiece() {
        return (_piece);
    }

    @Override
    public String toString() {
        return ("Computer: " + _name);
    }
}
