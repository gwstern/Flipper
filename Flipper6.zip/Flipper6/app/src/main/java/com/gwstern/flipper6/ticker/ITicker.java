package com.gwstern.flipper6.ticker;

import android.widget.TextView;

/**
 * An interface for a simple timer.
 */
public interface ITicker {
    /**
     * Starts the timer.
     *
     * @param widget Where to put the countdown.
     */
    void start(TextView widget);

    /**
     * Restarts the timer, resets the time and reuses the previously passed widget.
     */
    void restart();

    /**
     * Stops, but does not reset, the counter. No more counting is allowed.
     */
    void stop();

    /**
     * Pause the counter.
     */
    void pause();

    /**
     * Resumes the counter.
     */
    void resume();

    /**
     * Return the number of ticks (seonds) since start/reset/stop that weren't during a pause.
     *
     * @return Current number of seconds on this counter.
     */
    long getTicks();
}
