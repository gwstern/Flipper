package com.gwstern.flipper6.game;

/**
 * Used to define a 'move'.
 */
public class Move {
    private int _num;
    private int _x;
    private int _y;
    private SQUARE _piece;

    /**
     * Create a move.
     *
     * @param x X coordinate of move.
     * @param y Y coordinate of move.
     * @param piece Which player is making the move.
     */
    public Move(int x, int y, SQUARE piece) {
        _x = x;
        _y = y;
        _piece = piece;
        _num = -1;
    }

    /**
     * Create a move.
     *
     * @param num Which move number it is.
     * @param x X coordinate of move.
     * @param y Y coordinate of move.
     * @param piece Which player is making the move.
     */
    public Move(int num, int x, int y, SQUARE piece) {
        _x = x;
        _y = y;
        _piece = piece;
        _num = num;
    }

    // getters
    public int getX() {
        return (_x);
    }

    public int getY() {
        return (_y);
    }

    public SQUARE getPiece() {
        return (_piece);
    }

    public int getNum() {
        return (_num);
    }

    /**
     * Want something a bit more descriptive than an address.
     *
     * @return Descriptive text.
     */
    @Override
    public String toString() {
        return (_piece + " @ " + _x + "," + _y + " #" + _num);
    }
}