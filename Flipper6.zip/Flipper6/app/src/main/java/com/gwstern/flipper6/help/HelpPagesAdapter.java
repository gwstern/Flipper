package com.gwstern.flipper6.help;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.gwstern.flipper6.R;
import com.gwstern.flipper6.util.MyLog;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to one of the sections/tabs/pages.
 */
public class HelpPagesAdapter extends FragmentPagerAdapter {

    // Strings are stored in strings.xml
    @StringRes
    private static final int[] TITLES = new int[] {
            R.string.help_page1_title,
            R.string.help_page2_title,
            R.string.help_page3_title,
    };

    private Context _context;

    /**
     * Creates the adapter. Does nothing more than save the context
     * for use later on.
     *
     * @param fm The fragment manager used for this.
     */
    public HelpPagesAdapter(Context context, FragmentManager fm) {
        super(fm);
        MyLog.d("HelpPagesAdapter.HelpPagesAdapter (" + context + "," + fm + ")");

        _context = context;
    }

    /**
     * Called when the ViewPager needs to instantiate the fragment for the requested page.
     *
     * @param position The page the ViewPager needs.
     * @return The page fragment for the ViewPager to display.
     */
    @Override
    public Fragment getItem(int position) {
        MyLog.d("HelpPagesAdapter.getItem (" + position + ")");

        Fragment page = null;

        page = PageFragment.newInstance(position);

        return page;
    }

    /**
     * Called when the ViewPager needs a title.
     *
     * @param position The page the ViewPager needs a title for.
     * @return The title.
     */
    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        MyLog.v("HelpPagesAdapter.getPageTitle (" + position + ")");

        return (_context.getResources().getString(TITLES[position]));
    }

    /**
     * Called when the ViewPager wants to know how many pages it's dealing with.
     *
     * @return The number of pages.
     */
    @Override
    public int getCount() {
        MyLog.v("HelpPagesAdapter.getCount ()");

        return (TITLES.length);
    }
}
