package com.gwstern.flipper6.toolbar;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;

import com.gwstern.flipper6.R;
import com.gwstern.flipper6.util.MyLog;
import com.gwstern.flipper6.util.MyProps;

import java.util.Map;

/**
 * Handle the game settings menu.
 */
public class SettingsDialogFragment extends DialogFragment {
    // Listener callback for changes
    private SettingsListener _callback;

    /**
     * The listener to use to communicate the results of this back to the
     * activity that spawned it.
     */
    public interface SettingsListener {
        void getNewSettings(MyProps<SETTING_KEYS> settings);
    }

    /**
     * Empty constructor is required for DialogFragment. Make sure not to add
     * arguments to the constructor. Use `newInstance()` instead as shown below
     */
    public SettingsDialogFragment() {
    }

    /**
     * Create an instance of this fragment.
     *
     * @return The instance.
     */
    public static SettingsDialogFragment newInstance(MyProps<SETTING_KEYS> game_props) {
        MyLog.d("SettingsDialogFragment.newInstance (" + game_props + ")");

        SettingsDialogFragment adf = new SettingsDialogFragment();
        Bundle args = new Bundle();

        for (Map.Entry<SETTING_KEYS,String> prop : game_props.entrySet()) {
            args.putString((prop.getKey()).toString(), prop.getValue());
            MyLog.d((prop.getKey()).toString() + "=>" + prop.getValue());
        }
        adf.setArguments(args);

        return (adf);
    }

    /**
     * Sets the 'changes made' listener.
     *
     * @param cb Who to notify when changes occur.
     */
    public void setMyListener (SettingsListener cb) {
        MyLog.d ("SettingsDialogFragment.setMyListener (" + cb + ")");
        _callback = cb;
    }

    /**
     * Creates and returns the view hierarchy associated with the fragment.
     *
     * @param inflater The LayoutInflater used to inflate Views of this Fragment.
     * @param container If non-null, this is the parent view that the fragment's
     *                  UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state.
     * @return The created view.
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        MyLog.d("SettingsDialogFragment.onCreateView (" + inflater + "," + container + "," + savedInstanceState + ")");

        return inflater.inflate(R.layout.settings_fragment, container);
    }

    /**
     * This gives subclasses a chance to initialize themselves once they know
     * their view hierarchy has been completely created.
     *
     * @param view The view being updated/created.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state.
     */
    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MyLog.d("SettingsDialogFragment.onViewCreated (" + view + "," + savedInstanceState + ")");

        MyProps<SETTING_KEYS> props = new MyProps<>();

        // Set title
        getDialog().setTitle(R.string.settings_menu);

        // Get the game properties
        for (SETTING_KEYS e : SETTING_KEYS.values()) {
            props.put(e, getArguments().getString(e.toString()));
        }

        // General player information
        Switch sw;
        EditText et;
        Spinner icons;
        String[] items = new String[]{
                "piece1a", "piece1b", "piece2a", "piece2b", "piece3a", "piece3b", "piece4a", "piece4b"
        };
        ArrayAdapter adapter = new ArrayAdapter<>(this.getContext(), R.layout.spinner_row, items);

        // Set player 1's information
        sw = view.findViewById(R.id.h_or_c1);
        sw.setChecked(props.get(SETTING_KEYS.PLAYER1_TYPE).equals("H"));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                MyLog.d("SettingsDialogFragment.onCheckedChanged<player1> (" + compoundButton + "," + b + ")");

                View root_view = compoundButton.getRootView();

                if (compoundButton.isChecked()) {
                    root_view.findViewById(R.id.edit_player1_name).setEnabled(true);
                } else {
                    // Switching to the computer should use the canned name
                    EditText et_inner = root_view.findViewById(R.id.edit_player1_name);

                    root_view.findViewById(R.id.edit_player1_name).setEnabled(false);
                    et_inner.setText(getResources().getText(R.string.computer_player1_text));
                }
            }
        });

        et = view.findViewById(R.id.edit_player1_name);
        et.setText(props.get(SETTING_KEYS.PLAYER1_NAME));

        icons = view.findViewById(R.id.spinner1);
        icons.setAdapter(adapter);
        for (int i = 0;
             i < items.length;
             i++) {
            if (items[i].equals(props.get(SETTING_KEYS.PLAYER1_ICON))) {
                icons.setSelection(i);
                break;
            }
        }

        // Set player 2's information
        sw = view.findViewById(R.id.h_or_c2);
        sw.setChecked(props.get(SETTING_KEYS.PLAYER2_TYPE).equals("C"));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                MyLog.d("SettingsDialogFragment.onCheckedChanged<player2> (" + compoundButton + "," + b + ")");

                View root_view = compoundButton.getRootView();

                if (compoundButton.isChecked()) {
                    root_view.findViewById(R.id.edit_player2_name).setEnabled(false);
                } else {
                    // Switching to the computer should use the canned name
                    EditText et_inner = root_view.findViewById(R.id.edit_player2_name);

                    root_view.findViewById(R.id.edit_player2_name).setEnabled(true);
                    et_inner.setText(getResources().getText(R.string.computer_player2_text));
                }
            }
        });

        et = view.findViewById(R.id.edit_player2_name);
        et.setText(props.get(SETTING_KEYS.PLAYER2_NAME));

        icons = view.findViewById(R.id.spinner2);
        icons.setAdapter(adapter);
        for (int i = 0;
             i < items.length;
             i++) {
            if (items[i].equals(props.get(SETTING_KEYS.PLAYER2_ICON))) {
                icons.setSelection(i);
                break;
            }
        }

        // Handle the OK button
        view.findViewById(R.id.ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyLog.d("SettingsDialogFragment.onClick<ok> (" + v + ")");

                // While we could call a method in MainActivity directly it's
                // discouraged by Android. Instead the use of a listener is
                // recommended.
                MyProps<SETTING_KEYS> props = new MyProps<>();
                View root_view = v.getRootView();
                EditText et = root_view.findViewById(R.id.edit_player1_name);

                props.put (SETTING_KEYS.PLAYER1_NAME, et.getText().toString());
                et = root_view.findViewById(R.id.edit_player2_name);
                props.put (SETTING_KEYS.PLAYER2_NAME, et.getText().toString());

                Switch sw = root_view.findViewById(R.id.h_or_c1);
                props.put (SETTING_KEYS.PLAYER1_TYPE, sw.isChecked() ? "H" : "C");

                sw = root_view.findViewById(R.id.h_or_c2);
                props.put (SETTING_KEYS.PLAYER2_TYPE, sw.isChecked() ? "C" : "H");

                Spinner sp = root_view.findViewById(R.id.spinner1);
                props.put (SETTING_KEYS.PLAYER1_ICON, sp.getSelectedItem().toString());
                sp = root_view.findViewById(R.id.spinner2);
                props.put (SETTING_KEYS.PLAYER2_ICON, sp.getSelectedItem().toString());

                sw = root_view.findViewById(R.id.capture);
                props.put (SETTING_KEYS.FORCE_CAPTURE, sw.isChecked() ? "true" : "false");
                sw = root_view.findViewById(R.id.starting_layout);
                props.put (SETTING_KEYS.START_WITH_4, sw.isChecked() ? "true" : "false");

                _callback.getNewSettings(props);

                dismiss();
            }
        });

        // Handle the cancel button
        view.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("SettingsDialogFragment.onClick<cancel> (" + view + ")");

                _callback.getNewSettings(null);

                dismiss();
            }
        });
    }
}
