package com.gwstern.flipper6.ticker;

import android.os.Looper;
import android.widget.TextView;

import com.gwstern.flipper6.util.MyLog;

import android.os.Handler;

/**
 * Implements the ITicker interface.
 */
public class TickerImpl implements ITicker {
    private TextView _timer_gui = null;
    private Handler _timer_handler = null;
    private long startTime = 0;
    private long diff = 0;
    private Runnable _gui_update_thread = null;

    // Because it's possible to call reset(), then getTicks(), then start()
    // that means getTicks() will get the value of when the clocks stopped
    // and not 0. To account for GUI delays we added this boolean to let
    // getTicks() know that things have been reset.
    private boolean _resetting;

    /**
     * Class wrapper for the runnable function. I like having things that are
     * moderately complex in their own class/method/function rather than inline.
     */
    class TickerUpdater implements Runnable {
        @Override
        public void run() {
            MyLog.v("TickerImpl.run()");

            if (_resetting) {
                _timer_gui.setText(String.format("%02d:%02d", 0, 0));
                _resetting = false;
            } else {
                long millis = System.currentTimeMillis() - startTime;
                int seconds = (int) (millis / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;

                _timer_gui.setText(String.format("%02d:%02d", minutes, seconds));
            }

            _timer_handler.postDelayed(this, 500);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void start(TextView widget) {
        MyLog.d("TickerImpl.start(" + widget + ")");

        _resetting = false;
        _timer_gui = widget;
        startTime = System.currentTimeMillis();

        // Note: Looper is needed by AndroidJUnit4
        _timer_handler = new Handler(Looper.getMainLooper());
        _gui_update_thread = new TickerUpdater();
        _timer_handler.post(_gui_update_thread);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void restart() {
        MyLog.d("TickerImpl.restart()");

        if ((_timer_gui == null) || (_timer_handler == null) || (_gui_update_thread == null)) {
            MyLog.w("start() not called - ignoring");
        } else {
            _resetting = true;

            _timer_handler.post(_gui_update_thread);
            startTime = System.currentTimeMillis();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop() {
        MyLog.d("TickerImpl.stop()");

        if ((_timer_gui == null) || (_timer_handler == null) || (_gui_update_thread == null)) {
            MyLog.w("start() not called - ignoring");
        } else {
            _timer_handler.removeCallbacks(_gui_update_thread);

        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void pause() {
        MyLog.d("TickerImpl.pause()");

        if ((_timer_gui == null) || (_timer_handler == null) || (_gui_update_thread == null)) {
            MyLog.w("start() not called - ignoring");
        } else {
            // How long the timer had been running till it was paused
            diff = System.currentTimeMillis() - startTime;

            _timer_handler.removeCallbacks(_gui_update_thread);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void resume() {
        MyLog.d("TicketImpl.resume()");

        if ((_timer_gui == null) || (_timer_handler == null) || (_gui_update_thread == null)) {
            MyLog.w("start() not called - ignoring");
        } else {
            // We want the clock to start from the paused time, not from the actual time
            // so we 'cheat' by _resetting the start time to be the current time minus
            // the paused time, basically jumping the timing clock forward to compensate
            // for the pause
            startTime = System.currentTimeMillis() - diff;

            _timer_handler.postDelayed(_gui_update_thread, 0);
        }
    }

    /**
     * {@inheritDoc}
     * <p>
     * We use the value in the text field, rather than the 'real' time because
     * that's what the user sees and it's possible to call getTicks() before
     * the GUI has been updated but the time has increased.
     */
    @Override
    public long getTicks() {
        long rc = 0;

        if ((_timer_gui == null) || (_timer_handler == null) || (_gui_update_thread == null)) {
            MyLog.w("start() not called - ignoring");
        } else {
            String[] pieces = _timer_gui.getText().toString().split(":");

            if (_resetting) {
                rc = 0;
            } else {
                rc = Integer.parseInt(pieces[0]) * 60 + Integer.parseInt(pieces[1]);
            }
        }

        return (rc);
    }

}
