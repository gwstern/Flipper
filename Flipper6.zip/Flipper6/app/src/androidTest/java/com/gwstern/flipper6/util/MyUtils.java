package com.gwstern.flipper6.util;

import org.junit.Assert;

/**
 * Routines I find useful during unit testing.
 */
public class MyUtils {
    /**
     * Just a helper function to make the testing code easier to read.
     *
     * @param wait How long to sleep/pause/yield in seconds.
     */
    public static void sleep(long wait) {
        try {
            Thread.sleep(wait * 1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
            Assert.fail("Thread.sleep() failed - " + ie);
        }
    }
}
