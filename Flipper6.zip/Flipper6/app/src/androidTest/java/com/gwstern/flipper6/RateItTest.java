package com.gwstern.flipper6;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper6.toolbar.RateIt;
import com.gwstern.flipper6.toolbar.SETTING_KEYS;
import com.gwstern.flipper6.util.MyLog;
import com.gwstern.flipper6.util.MyProps;
import com.gwstern.flipper6.util.MyUtils;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.Date;

import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isCompletelyDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.hamcrest.core.AllOf.allOf;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class RateItTest {
    private Resources _resources;

    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Called before every test
     */
    @Before
    public void setUp() {
        _resources = main.getActivity().getResources();
    }

    /**
     * Test the help dialog comes up and that everything can be selected.
     */
    @Test
    public void testRateIt() {
        MyLog.d("RateItTest.testRateIt()");

        final int MILLI_SECS_IN_DAY = 24 * 60 * 60 * 1000;

        RateIt ri = new RateIt();

        MyProps<SETTING_KEYS> props = new MyProps<>();
        int launches_until_prompt = 5;
        int days_until_prompt = 3;

        props.put(SETTING_KEYS.DAYS_UNTIL_PROMPT, Integer.toString(days_until_prompt));
        props.put(SETTING_KEYS.LAUNCHES_UNTIL_PROMPT, Integer.toString(launches_until_prompt));
        props.put(SETTING_KEYS.PREF_NAME, "apprater");
        props.put(SETTING_KEYS.DSA_KEY, "dontshowagain");
        props.put(SETTING_KEYS.LAUNCH_COUNT_KEY, "launch_count");
        props.put(SETTING_KEYS.DATE_KEY, "date_firstlaunch");

        SharedPreferences prefs = main.getActivity().getSharedPreferences(props.get(SETTING_KEYS.PREF_NAME), 0);
        SharedPreferences.Editor editor = prefs.edit();

        Context context = main.getActivity().getWindow().getContext();

        // No matter how many times the app is launched it won't prompt because
        // there hasn't been DAYS_UNTIL_PROMPT
        ri.reset(context, props);

        for (int i = 0; i < launches_until_prompt + 1; i++) {
            ri.rateApp(context, props);

            try {
                Espresso.onView(allOf(withId(R.id.rate_description), isCompletelyDisplayed()))
                        .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));
                Assert.fail("RateIt shouldn't be visible");
            } catch (NoMatchingViewException nmve) {
                // This means the Rate It popup didn't popup. Which is what we want in this case.
            }

            Assert.assertEquals(i + 1, prefs.getLong(props.get(SETTING_KEYS.LAUNCH_COUNT_KEY), 0));
        }

        // Now keep the number of launches constant and change the date. Still
        // shouldn't popup
        ri.reset(context, props);

        Long past = System.currentTimeMillis() - ((days_until_prompt + 1) * MILLI_SECS_IN_DAY);
        editor.putLong(props.get(SETTING_KEYS.DATE_KEY), past);
        MyLog.d("past=" + new Date(past));
        editor.commit();

        // Now launch the app until just before the dialog is due
        for (int i = 0; i < launches_until_prompt - 1; i++) {
            ri.rateApp(context, props);

            try {
                Espresso.onView(allOf(withId(R.id.rate_description), isCompletelyDisplayed()))
                        .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));
                Assert.fail("RateIt shouldn't be visible");
            } catch (NoMatchingViewException nmve) {
                // This means the Rate It popup didn't popup. Which is what we want in this case.
            }

            Assert.assertEquals(i + 1, prefs.getLong(props.get(SETTING_KEYS.LAUNCH_COUNT_KEY), 0));
        }

        ri.rateApp(context, props);

        try {
            Espresso.onView(allOf(withId(R.id.rate_description), isCompletelyDisplayed()))
                    .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));
        } catch (NoMatchingViewException nmve) {
            Assert.fail("RateIt should be visible");
        }
        MyLog.d("done");
        MyUtils.sleep(42);
    }
}
