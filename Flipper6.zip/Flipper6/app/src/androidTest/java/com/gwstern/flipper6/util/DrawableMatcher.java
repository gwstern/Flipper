package com.gwstern.flipper6.util;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

/**
 * Based on code written by Daniele Bottillo (https://medium.com/@dbottillo/android-ui-test-espresso-matcher-for-imageview-1a28c832626f)
 *
 * This class allows an Espresso unit test to compare an image on the screen with
 * another image in drawable/ like:
 *   onView(withId(R.id.your_image_on screen)).check(matches(withDrawable(R.drawable.your_image_in_drawable)));
 *
 * Unfortunately there is no ‘withDrawable’ out of the box with Espresso, but
 * with the help of Bottillio's blog it could be built.
 */
public class DrawableMatcher extends TypeSafeMatcher<View> {

    private final int _expected_id;
    private String _resource_name;
    static final int EMPTY = -1;
    static final int ANY = -2;

    /**
     * Create a matcher for comparing drawables.
     *
     * @param id The expected item to compare against.
     */
    public DrawableMatcher(int id) {
        super(View.class);
        MyLog.v ("DrawableMatcher.DrawableMatcher (" + id + ")");

        this._expected_id = id;
    }

    /**
     * Match passed target with expected.
     *
     * @param target The object against which the matcher is evaluated. Guaranteed
     *               to be checked for a specific type and will not be null.
     * @return true if matches; false otherwise.
     */
    @Override
    protected boolean matchesSafely(View target) {
        MyLog.v ("Drawable.matchesSafely (" + target + ")");

        // Check type
        if (!(target instanceof ImageView)) {
            return false;
        }

        // Make sure the image is valid
        ImageView imageView = (ImageView)target;

        if (_expected_id == EMPTY) {
            return imageView.getDrawable() == null;
        }
        if (_expected_id == ANY) {
            return imageView.getDrawable() != null;
        }

        // Get resources and drawable info
        Resources resources = target.getContext().getResources();
        Drawable expectedDrawable = resources.getDrawable(_expected_id);

        _resource_name = resources.getResourceEntryName(_expected_id);

        if (expectedDrawable == null) {
            return false;
        }

        // Get the bitmaps and compare them
        Bitmap bitmap = getBitmap(imageView.getDrawable());
        Bitmap otherBitmap = getBitmap(expectedDrawable);

        return (bitmap.sameAs(otherBitmap));
    }

    /**
     * Retrieve the bitmap from the passed drawable.
     *
     * @param drawable The drawable to retrieve a bitmap from.
     * @return The bitmap representing the passed drawable.
     */
    private Bitmap getBitmap(Drawable drawable) {
        MyLog.v ("DrawableMatcher.getBitmap (" + drawable + ")");

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return (bitmap);
    }

    /**
     * Generates a description of the object.
     *
     * @param description The description to be built or appended to.
     */
    @Override
    public void describeTo(Description description) {
        MyLog.v ("DrawableMatcher.describeTo (" + description + ")");

        description.appendText("with drawable from resource id: ");
        description.appendValue(_expected_id);

        if (_resource_name != null) {
            description.appendText("[" + _resource_name + "]");
        }
    }
}
