package com.gwstern.flipper6.util;

import android.os.IBinder;

import androidx.test.espresso.Root;

import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

/**
 * Handles determining if a toast message isn't displayed.
 *
 * Based on a stackoverflow posting (https://stackoverflow.com/questions/29896223/android-espresso-how-to-check-that-toast-message-is-not-shown)
 * by TWiStErRob
 */
public class ToastTypeMatcher extends TypeSafeMatcher<Root> {
    private final String _description;
    private final int _toast_type;
    private final boolean _token_match;

    /**
     * Create a toast matcher.
     *
     * @param desc A description - for display only.
     * @param toast_type The type of toast being matched.
     */
    public ToastTypeMatcher(String desc, int toast_type) {
        this(desc, toast_type, true);

        MyLog.v ("ToastTypeMatcher.ToastTypeMatcher (" + desc + "," + toast_type + ")");
    }

    /**
     * Create a toast matcher.
     *
     * @param desc A description - for display only.
     * @param toast_type The type of toast being matched.
     */
    public ToastTypeMatcher(String desc, int toast_type, boolean token_match) {
        MyLog.v ("ToastTypeMatcher.ToastTypeMatcher (" + desc + "," + toast_type + "," + token_match + ")");

        _description = desc;
        _toast_type = toast_type;
        _token_match = token_match;
    }

    /**
     * @see TypeSafeMatcher#describeTo(Description)
     */
    @Override
    public void describeTo(Description desc) {
        MyLog.v ("ToastTypeMatcher.describeTo(" + desc + ")");

        desc.appendText(_description);
    }

    /**
     * @see TypeSafeMatcher#matchesSafely(Object)
     */
    @Override
    public boolean matchesSafely(Root root) {
        MyLog.v ("ToastTypeMatcher.matchesSafely(" + root + ")");

        if (_toast_type == root.getWindowLayoutParams().get().type) {
            IBinder windowToken = root.getDecorView().getWindowToken();
            IBinder appToken = root.getDecorView().getApplicationWindowToken();
            if (windowToken == appToken == _token_match) {
                // windowToken == appToken means this window isn't contained by any other windows.
                // if it was a window for an activity, it would have TYPE_BASE_APPLICATION.
                return (true);
            }
        }
        return (false);
    }
}