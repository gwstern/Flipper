package com.gwstern.flipper6;

import android.graphics.Point;
import android.view.View;
import android.view.WindowManager;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.Root;
import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper6.game.Board;
import com.gwstern.flipper6.game.Players;
import com.gwstern.flipper6.util.MyLog;
import com.gwstern.flipper6.util.MyUtils;
import com.gwstern.flipper6.util.MissingRoot;
import com.gwstern.flipper6.util.ToastTypeMatcher;

import org.hamcrest.Matcher;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isEnabled;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.isRoot;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.gwstern.flipper6.util.EspressoTestMatchers.withDrawable;
import static org.hamcrest.CoreMatchers.anything;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.AllOf.allOf;
import static org.hamcrest.core.IsNot.not;

/**
 * Test the placement of pieces on the board. This class starts out simple and
 * as I test and play the game things I missed or edge cases or random thoughts
 * late at night get added. Personally, I prefer arrays and loops to simply
 * repeating perform(click()) or check().
 * And yes, I know it's not real Points I'm using but neither Java or Android has
 * a generic Pair class and I didn't feel the need to create one.
 */
@RunWith(AndroidJUnit4.class)
public class BoardTest {

    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    // 'Presses' the 'undoLastMove' button even if that button is invisible.
    private ViewAction _undo_action = new ViewAction() {
        @Override
        public Matcher<View> getConstraints() {
            return ViewMatchers.isEnabled(); // no constraints, they are checked above
        }

        @Override
        public String getDescription() {
            return ("don't care - required");
        }

        @Override
        public void perform(UiController uiController, View view) {
            view.performClick();
        }
    };

    // 'Presses' the 'quit' button
    private ViewAction _quit_action = new ViewAction() {
        @Override
        public Matcher<View> getConstraints() {
            return ViewMatchers.isEnabled(); // no constraints, they are checked above
        }

        @Override
        public String getDescription() {
            return ("don't care - required");
        }

        @Override
        public void perform(UiController uiController, View view) {
            view.performClick();
        }
    };

    /**
     * Since I find some of these tests by playing the game I wrote this routine
     * to take what's saved in FlipperMoves.db and convert it to a series of moves.
     * Since FlipperMoves.db isn't saved between runs and I didn't want to deal with
     * copying it, storing it, reading it I simply dump the contents (via sqlite3)
     * and paste it into an array of Strings.
     */
    private int[] cvtDB2Moves(String[] db_moves) {
        final int[][] xlat = {
                {R.id.posA1, R.id.posB1, R.id.posC1, R.id.posD1, R.id.posE1, R.id.posF1, R.id.posG1, R.id.posH1},
                {R.id.posA2, R.id.posB2, R.id.posC2, R.id.posD2, R.id.posE2, R.id.posF2, R.id.posG2, R.id.posH2},
                {R.id.posA3, R.id.posB3, R.id.posC3, R.id.posD3, R.id.posE3, R.id.posF3, R.id.posG3, R.id.posH3},
                {R.id.posA4, R.id.posB4, R.id.posC4, R.id.posD4, R.id.posE4, R.id.posF4, R.id.posG4, R.id.posH4},
                {R.id.posA5, R.id.posB5, R.id.posC5, R.id.posD5, R.id.posE5, R.id.posF5, R.id.posG5, R.id.posH5},
                {R.id.posA6, R.id.posB6, R.id.posC6, R.id.posD6, R.id.posE6, R.id.posF6, R.id.posG6, R.id.posH6},
                {R.id.posA7, R.id.posB7, R.id.posC7, R.id.posD7, R.id.posE7, R.id.posF7, R.id.posG7, R.id.posH7},
                {R.id.posA8, R.id.posB8, R.id.posC8, R.id.posD8, R.id.posE8, R.id.posF8, R.id.posG8, R.id.posH8}
        };
        int[] rc = new int[db_moves.length];

        for (String move : db_moves) {
            String[] pieces = move.split("[|]");
            int num = Integer.valueOf(pieces[0]) - 1;
            int y = Integer.valueOf(pieces[1]);
            int x = Integer.valueOf(pieces[2]);

            rc[num] = xlat[x][y];
        }

        return (rc);
    }

    /**
     * Test that pieces on the board are removed properly.
     */
    @Test
    public void testUndo() {
        MyLog.d("TickerTest.testUndo ()");

        int[] ids;
        Point[] tiles;

        // The first four moves for the default of not starting with four filled
        // in should be to fill in the middle tiles
        ids = new int[]{
                R.id.posD4, R.id.posE4, R.id.posE5, R.id.posD5,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Undo one move and then move back
        Espresso.onView(withId(R.id.undo))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_undo_action);
        Espresso.onView(withId(R.id.posD5))
                .perform(click());

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Undo two moves and then move back
        for (int i = 0; i < 2; i++) {
            Espresso.onView(withId(R.id.undo))
                    .check(matches(allOf(isEnabled(), isClickable())))
                    .perform(_undo_action);
        }

        ids = new int[]{
                R.id.posE5, R.id.posD5,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Undo three moves and then move back
        for (int i = 0; i < 3; i++) {
            Espresso.onView(withId(R.id.undo))
                    .check(matches(allOf(isEnabled(), isClickable())))
                    .perform(_undo_action);
        }

        ids = new int[]{
                R.id.posE4, R.id.posE5, R.id.posD5,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Undo all four moves and then move back
        for (int i = 0; i < 4; i++) {
            Espresso.onView(withId(R.id.undo))
                    .check(matches(allOf(isEnabled(), isClickable())))
                    .perform(_undo_action);
        }
        Espresso.onView(withId(R.id.undo)) // Shouldn't do anything
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_undo_action);

        ids = new int[]{
                R.id.posD4, R.id.posE4, R.id.posE5, R.id.posD5,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // LD
        //  LDL
        //  DDD

        // Make a few moves which cause flipping and then back them out
        ids = new int[]{
                R.id.posF4, R.id.posD3, R.id.posC3, R.id.posF5,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }

        // Check that things look right before backing them out
        tiles = new Point[]{
                new Point(R.id.posC3, R.drawable.light_piece),
                new Point(R.id.posD3, R.drawable.dark_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posF4, R.drawable.light_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.dark_piece),
                new Point(R.id.posF5, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Back the last move out - should end up with:
        //  LD
        //   LLL
        //   DL
        Espresso.onView(withId(R.id.undo))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_undo_action);

        tiles = new Point[]{
                new Point(R.id.posC3, R.drawable.light_piece),
                new Point(R.id.posD3, R.drawable.dark_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.light_piece),
                new Point(R.id.posF4, R.drawable.light_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Back the last move out - should end up with:
        //  D
        //  DLL
        //  DL
        Espresso.onView(withId(R.id.undo))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_undo_action);

        tiles = new Point[]{
                new Point(R.id.posD3, R.drawable.dark_piece),
                new Point(R.id.posD4, R.drawable.dark_piece),
                new Point(R.id.posE4, R.drawable.light_piece),
                new Point(R.id.posF4, R.drawable.light_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Back the last move out - should end up with:
        //  LLL
        //  DL
        Espresso.onView(withId(R.id.undo))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_undo_action);

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.light_piece),
                new Point(R.id.posF4, R.drawable.light_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // Back the last move out - should end up with:
        //  LD
        //  DL
        Espresso.onView(withId(R.id.undo))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_undo_action);

        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }
    }

    /**
     * Test that the center pieces are placed properly if not starting with four
     * in the middle.
     */
    @Test
    public void testFirst4MoveCheck() {
        MyLog.d("TickerTest.testFirst4MoveCheck ()");

        int[] ids;
        Point[] tiles;

        // The first four moves for the default of not starting with four filled
        // in should be to fill in the middle tiles
        ids = new int[]{
                R.id.posD4, R.id.posE4, R.id.posD5, R.id.posE5,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }
        tiles = new Point[]{
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.light_piece),
                new Point(R.id.posE5, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        // nnny
        // nLDy
        // nLDy
        // nnny

        // Everywhere there's an 'n' we shouldn't be able to place a piece
        ids = new int[]{
                R.id.posE3, R.id.posD3, R.id.posC3, R.id.posC4, R.id.posC5, R.id.posC6, R.id.posD6, R.id.posE6,
        };
        for (int id : ids) {
            Espresso.onView(withId(id)).perform(click());
            Espresso.onView(withId(id))
                    .check(matches(withDrawable(R.drawable.empty)));
        }

        // Everywhere there's an 'y' we should be able to place a piece
        ids = new int[]{
                R.id.posF3, R.id.posF4, R.id.posF5, R.id.posF6,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
            Espresso.onView(withId(id))
                    .check(matches(withDrawable(R.drawable.light_piece)));

            // Remove the piece so we can test the next placement
            Espresso.onView(withId(R.id.undo))
                    .check(matches(allOf(isEnabled(), isClickable())))
                    .perform(_undo_action);
        }
    }

    /**
     * Test that captured pieces are flipped properly.
     */
    @Test
    public void testFlipping() {
        MyLog.d("TickerTest.testFlipping ()");

        int[] ids;
        Point[] tiles;

        //   L
        // Ld
        // LD

        ids = new int[]{
                R.id.posD4, R.id.posE4, R.id.posD5, R.id.posE5, R.id.posF3,
        };
        for (int id : ids) {
            Espresso.onView(withId(id))
                    .perform(click());
        }

        // Only 'd' should flip
        tiles = new Point[]{
                new Point(R.id.posF3, R.drawable.light_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.light_piece),
                new Point(R.id.posD5, R.drawable.light_piece),
                new Point(R.id.posE5, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        //  DL
        // Ll
        // LD

        Espresso.onView(withId(R.id.posE3))
                .perform(click());

        // Only 'l' should flip
        tiles = new Point[]{
                new Point(R.id.posE3, R.drawable.dark_piece),
                new Point(R.id.posF3, R.drawable.light_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.light_piece),
                new Point(R.id.posE5, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        //  DL
        // LD
        // LdL

        Espresso.onView(withId(R.id.posF5))
                .perform(click());

        // Only 'd' should flip
        tiles = new Point[]{
                new Point(R.id.posE3, R.drawable.dark_piece),
                new Point(R.id.posF3, R.drawable.light_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.light_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
                new Point(R.id.posF5, R.drawable.light_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        //   DL
        //  LD
        //  lLL
        // D

        Espresso.onView(withId(R.id.posC6))
                .perform(click());

        // Only 'l' should flip
        tiles = new Point[]{
                new Point(R.id.posE3, R.drawable.dark_piece),
                new Point(R.id.posF3, R.drawable.light_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.dark_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
                new Point(R.id.posF5, R.drawable.light_piece),
                new Point(R.id.posC6, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        //   DL
        //  LD
        // LdLL
        // D

        Espresso.onView(withId(R.id.posC5))
                .perform(click());

        // Only 'd' should flip
        tiles = new Point[]{
                new Point(R.id.posE3, R.drawable.dark_piece),
                new Point(R.id.posF3, R.drawable.light_piece),
                new Point(R.id.posD4, R.drawable.light_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posC5, R.drawable.light_piece),
                new Point(R.id.posD5, R.drawable.light_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
                new Point(R.id.posF5, R.drawable.light_piece),
                new Point(R.id.posC6, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }

        //   DL
        // DlD
        // lLLL
        // D

        Espresso.onView(withId(R.id.posC4))
                .perform(click());

        // Only 'l' should flip
        tiles = new Point[]{
                new Point(R.id.posE3, R.drawable.dark_piece),
                new Point(R.id.posF3, R.drawable.light_piece),
                new Point(R.id.posC4, R.drawable.dark_piece),
                new Point(R.id.posD4, R.drawable.dark_piece),
                new Point(R.id.posE4, R.drawable.dark_piece),
                new Point(R.id.posC5, R.drawable.dark_piece),
                new Point(R.id.posD5, R.drawable.light_piece),
                new Point(R.id.posE5, R.drawable.light_piece),
                new Point(R.id.posF5, R.drawable.light_piece),
                new Point(R.id.posC6, R.drawable.dark_piece),
        };
        for (Point p : tiles) {
            Espresso.onView(withId(p.x))
                    .check(matches(withDrawable(p.y)));
        }
    }

    /**
     * An method in the Espresso fashion that checks for a toast message being
     * displayed.
     *
     * @return A matcher for the toast message.
     */
    private static Matcher<Root> isToast() {
        return new ToastTypeMatcher("is toast", WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
    }

    /**
     * Test that pieces on the board are removed properly.
     */
    @Test
    public void testEndGameDetermination() {
        MyLog.d("TickerTest.testEndGameDetermination ()");

        Board b = main.getActivity()._board;
        Players p = main.getActivity()._players;

        // At the start of the game there are moves available
        Assert.assertTrue(b.stillMoves(p.getPlayer(0)));
        Assert.assertTrue(b.stillMoves(p.getPlayer(1)));

        // A game that fills the entire board
        int[] moves = {
                R.id.posD4, R.id.posD5, R.id.posE5, R.id.posE4, R.id.posE3, R.id.posF3,
                R.id.posC5, R.id.posD3, R.id.posE2, R.id.posD6, R.id.posC3, R.id.posB3,
                R.id.posD7, R.id.posC6, R.id.posD2, R.id.posD8, R.id.posA3, R.id.posD1,
                R.id.posC7, R.id.posB5, R.id.posC4, R.id.posB4, R.id.posA5, R.id.posB6,
                R.id.posC2, R.id.posA4, R.id.posC1, R.id.posE6, R.id.posC8, R.id.posA6,
                R.id.posF6, R.id.posF5, R.id.posF4, R.id.posE1, R.id.posF1, R.id.posF2,
                R.id.posA7, R.id.posG5, R.id.posH5, R.id.posH6, R.id.posH7, R.id.posF7,
                R.id.posF8, R.id.posG4, R.id.posH4, R.id.posH3, R.id.posE7, R.id.posH8,
                R.id.posG3, R.id.posG8, R.id.posG6, R.id.posB7, R.id.posE8, R.id.posH2,
                R.id.posA2, R.id.posG7, R.id.posA8, R.id.posG1, R.id.posH1, R.id.posB2,
                R.id.posB1, R.id.posB8, R.id.posG2, R.id.posA1,
        };
        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            // Not end game moves
            if ((i > 3) && (i < (moves.length - 2))) {
                Assert.assertTrue(b.stillMoves(p.getPlayer(0)));
                Assert.assertTrue(b.stillMoves(p.getPlayer(1)));
            }

            // Very last move
            if (i > (moves.length - 2)) {
                // Game is over
                Espresso.onView(withText("Nobody has moves left!"))
                        .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                        .check(matches(isDisplayed()));
            } else if (i > (moves.length - 3)) {  // Only one move left
                // Only the last player has a move
                Espresso.onView(isRoot())
                        .inRoot(isToast())
                        .withFailureHandler(new MissingRoot())
                        .check(matches(not(anything("moves left!"))));
            }
        }
        MyUtils.sleep(5); // Wait for previous toast go go away

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);

        // Some games where the board isn't filled up but there are no moves
        p.flip();

        // Test #1
        moves = new int[]{
                R.id.posE4, R.id.posD4, R.id.posD5, R.id.posE5, R.id.posF5, R.id.posD6,
                R.id.posC5, R.id.posF4, R.id.posE3, R.id.posF6, R.id.posG5, R.id.posE6,
                R.id.posE7,
        };

        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            if ((i > 3) && (i < (moves.length-1))) {
                Assert.assertTrue(b.stillMoves(p.getPlayer(0)));
                Assert.assertTrue(b.stillMoves(p.getPlayer(1)));
            }
        }
        Assert.assertFalse(b.stillMoves(p.getPlayer(0)));
        Assert.assertFalse(b.stillMoves(p.getPlayer(1)));

        Espresso.onView(withText("Nobody has moves left!"))
                .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                .check(matches(isDisplayed()));
        MyUtils.sleep(5); // Wait for previous toast go go away

        Espresso.onView(withId(R.id.quit))
                .check(matches(allOf(isEnabled(), isClickable())))
                .perform(_quit_action);

        // Test #2
        moves = cvtDB2Moves(new String[]{
                "1|3|4|LIGHT",
                "2|4|3|DARK",
                "3|4|4|LIGHT",
                "4|3|3|DARK",
                "5|2|2|LIGHT",
                "6|2|3|DARK",
                "7|2|4|LIGHT",
                "8|1|3|DARK",
                "9|4|2|LIGHT",
                "10|2|1|DARK",
                "11|1|2|LIGHT",
                "12|0|3|DARK",
                "13|2|0|LIGHT",
                "14|3|2|DARK",
                "15|0|2|LIGHT",
                "16|0|1|DARK",
        });

        MyLog.d ("mothra");
        for (int i = 0; i < moves.length; i++) {
            // Make the move
            Espresso.onView(withId(moves[i]))
                    .perform(click());

            if ((i > 3) && (i < (moves.length-1))) {
                Assert.assertTrue(b.stillMoves(p.getPlayer(0)));
                Assert.assertTrue(b.stillMoves(p.getPlayer(1)));
            }
        }

        Espresso.onView(withText("Human (D) has no moves left!"))
                .inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView())))
                .check(matches(isDisplayed()));

        Assert.assertFalse(b.stillMoves(p.getPlayer(0)));
        Assert.assertTrue(b.stillMoves(p.getPlayer(1))); // Still moves for this player
    }
}