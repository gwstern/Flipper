package com.gwstern.flipper2;

import java.util.HashMap;
import java.util.Map;

/**
 * Enumeration for a square - i.e. it can be empty or have the light or dark
 * piece on it.
 */
public enum SQUARE {
    EMPTY ("EMPTY"),
    LIGHT ("LIGHT"),
    DARK ("DARK");

    private String _value;
    private static Map<String,SQUARE> _xlat = new HashMap<>();

    /*
     * Convert integers to their enum representation
     */
    static {
        for (SQUARE sq : SQUARE.values()) {
            _xlat.put (sq._value, sq);
        }
    }

    /**
     * Create this enum. It's private because we down want additional enums.
     *
     * @param value THe value to assign to the enum.
     */
    private SQUARE (String value) { _value = value;}

    /**
     * Map the passed value to the appropriate enum.
     *
     * @param value The book value to map.
     * @return The representative enum.
     */
    static public SQUARE map (String value) {
        SQUARE xlat = EMPTY;

        if ((value != null) && (value != "") && (!value.equals("")))
            xlat = (SQUARE)_xlat.get(value.toUpperCase());
        else
            // Since we're dealing with data that might be modified by a user
            // we'll leave this in to help with debugging
            throw new Error ("Invalid SQUARE type of null or empty");

        return xlat;
    }
}
