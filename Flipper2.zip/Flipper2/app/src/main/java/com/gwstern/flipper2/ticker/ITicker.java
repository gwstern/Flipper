package com.gwstern.flipper2.ticker;

import android.widget.TextView;

/**
 * An interface for a simple timer.
 */
public interface ITicker {
    /**
     * Starts the timer.
     *
     * @param widget Where to put the countdown.
     */
    void start (TextView widget);

    /**
     * Stops the counter. No more counting is allowed.
     */
    void stop ();

    /**
     * Pause the counter.
     */
    void pause ();

    /**
     * Resumes the counter.
     */
    void resume ();

    /**
     * Resets the counter to 0 and starts counting again.
     */
    void reset ();

    /**
     * Return the number of ticks (seonds) since start/reset/stop that weren't during a pause.
     *
     * @return Current number of seconds on this counter.
     */
    long getTicks ();
}
