/**
 * This is a simple Reversi/Othello-type program designed to show how one might
 * build an Android application. Each successive app builds on the previous one.
 * <p>
 * History:
 * 10 Jul 2019 Added logging, improved comments, brought up to production
 *             standards
 * 17 Jul 2019 Converted to use AndroidX
 *             Added unit testing
 *             Added layouts
 *             Updated manifest
 */
package com.gwstern.flipper2;

import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.snackbar.Snackbar;
import com.gwstern.flipper2.ticker.TickerImpl;
import com.gwstern.flipper2.util.MyLog;

/**
 * This is where it all begins. Class currently does nothing more than run a
 * app that has a simple menu, FAB and greeting
 */
public class MainActivity extends AppCompatActivity {

    /*private*/ TickerImpl _ticker;

    /**
     * I like to have at least *some* information displayed if the program
     * exists unexpectedly.
     */
    public MainActivity() {
        Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread,
                                          Throwable ex) {
                MyLog.wtf(getApplicationContext(), "uncaughtException - ", ex);
            }
        });
    }

    /**
     * Called when the window is created.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("MainActivity.onCreate (" + savedInstanceState + ")");

        // Create the layout
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        // Create a timer
        _ticker = new TickerImpl();

        // Define some actions for the buttons on the bottom
        ImageButton ib = findViewById(R.id.pause);

        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<pause> (" + view + ")");

                Snackbar.make(view, "<pause>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Both the way below and the way above are valid syntax. One can also
        // have MainActivity implement View.OnClickListener() as well. I like the
        // lower one if I will never use the variable and the action is simple.
        findViewById(R.id.quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<quit> (" + view + ")");

                Snackbar.make(view, "<quit>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        findViewById(R.id.reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<reset> (" + view + ")");

                Snackbar.make(view, "<reset>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        findViewById(R.id.help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<help> (" + view + ")");

                Snackbar.make(view, "<help>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Here's where putting everything in content_main.xml gets kinda ugly.
        // Because we don't know if R.id.pos1a through R.id.pos8h are in sequence
        // we can't use a loop. Which leaves us with the following code...
        BoardListener bl = new BoardListener();

        findViewById(R.id.posA1).setOnClickListener(bl);
        findViewById(R.id.posB1).setOnClickListener(bl);
        findViewById(R.id.posC1).setOnClickListener(bl);
        findViewById(R.id.posD1).setOnClickListener(bl);
        findViewById(R.id.posE1).setOnClickListener(bl);
        findViewById(R.id.posF1).setOnClickListener(bl);
        findViewById(R.id.posG1).setOnClickListener(bl);
        findViewById(R.id.posH1).setOnClickListener(bl);

        findViewById(R.id.posA2).setOnClickListener(bl);
        findViewById(R.id.posB2).setOnClickListener(bl);
        findViewById(R.id.posC2).setOnClickListener(bl);
        findViewById(R.id.posD2).setOnClickListener(bl);
        findViewById(R.id.posE2).setOnClickListener(bl);
        findViewById(R.id.posF2).setOnClickListener(bl);
        findViewById(R.id.posG2).setOnClickListener(bl);
        findViewById(R.id.posH2).setOnClickListener(bl);

        findViewById(R.id.posA3).setOnClickListener(bl);
        findViewById(R.id.posB3).setOnClickListener(bl);
        findViewById(R.id.posC3).setOnClickListener(bl);
        findViewById(R.id.posD3).setOnClickListener(bl);
        findViewById(R.id.posE3).setOnClickListener(bl);
        findViewById(R.id.posF3).setOnClickListener(bl);
        findViewById(R.id.posG3).setOnClickListener(bl);
        findViewById(R.id.posH3).setOnClickListener(bl);

        findViewById(R.id.posA4).setOnClickListener(bl);
        findViewById(R.id.posB4).setOnClickListener(bl);
        findViewById(R.id.posC4).setOnClickListener(bl);
        findViewById(R.id.posD4).setOnClickListener(bl);
        findViewById(R.id.posE4).setOnClickListener(bl);
        findViewById(R.id.posF4).setOnClickListener(bl);
        findViewById(R.id.posG4).setOnClickListener(bl);
        findViewById(R.id.posH4).setOnClickListener(bl);

        findViewById(R.id.posA5).setOnClickListener(bl);
        findViewById(R.id.posB5).setOnClickListener(bl);
        findViewById(R.id.posC5).setOnClickListener(bl);
        findViewById(R.id.posD5).setOnClickListener(bl);
        findViewById(R.id.posE5).setOnClickListener(bl);
        findViewById(R.id.posF5).setOnClickListener(bl);
        findViewById(R.id.posG5).setOnClickListener(bl);
        findViewById(R.id.posH5).setOnClickListener(bl);

        findViewById(R.id.posA6).setOnClickListener(bl);
        findViewById(R.id.posB6).setOnClickListener(bl);
        findViewById(R.id.posC6).setOnClickListener(bl);
        findViewById(R.id.posD6).setOnClickListener(bl);
        findViewById(R.id.posE6).setOnClickListener(bl);
        findViewById(R.id.posF6).setOnClickListener(bl);
        findViewById(R.id.posG6).setOnClickListener(bl);
        findViewById(R.id.posH6).setOnClickListener(bl);

        findViewById(R.id.posA7).setOnClickListener(bl);
        findViewById(R.id.posB7).setOnClickListener(bl);
        findViewById(R.id.posC7).setOnClickListener(bl);
        findViewById(R.id.posD7).setOnClickListener(bl);
        findViewById(R.id.posE7).setOnClickListener(bl);
        findViewById(R.id.posF7).setOnClickListener(bl);
        findViewById(R.id.posG7).setOnClickListener(bl);
        findViewById(R.id.posH7).setOnClickListener(bl);

        findViewById(R.id.posA8).setOnClickListener(bl);
        findViewById(R.id.posB8).setOnClickListener(bl);
        findViewById(R.id.posC8).setOnClickListener(bl);
        findViewById(R.id.posD8).setOnClickListener(bl);
        findViewById(R.id.posE8).setOnClickListener(bl);
        findViewById(R.id.posF8).setOnClickListener(bl);
        findViewById(R.id.posG8).setOnClickListener(bl);
        findViewById(R.id.posH8).setOnClickListener(bl);
    }

    /**
     * Creates the options menu for the main activity.
     *
     * @param menu The instance selected.
     * @return true to display the menu; false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MyLog.d("MainActivity.onCreateOptionsMenu (" + menu + ")");

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * Handle action bar item clicks here. The action bar will
     * automatically handle clicks on the Home/Up button, so long
     * as you specify a parent activity in AndroidManifest.xml.
     *
     * @param item The menu item selected.
     * @return false to allow normal menu processing; true to consume it.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onOptionsItemSelected (" + item + ")");

        int id = item.getItemId();
        boolean rc;

        switch (id) {
            case R.id.app_settings:
                Snackbar.make(getWindow().getDecorView(), "<settings>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null)
                        .show();
                rc = true;
                break;

            case R.id.rate:
                Snackbar.make(getWindow().getDecorView(), "<rate>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null)
                        .show();
                rc = true;
                break;

            case R.id.report_bug:
                Snackbar.make(getWindow().getDecorView(), "<bug>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                rc = true;
                break;

            case R.id.about:
                Snackbar.make(getWindow().getDecorView(), "<about>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                rc = true;
                break;

            default:
                rc = super.onOptionsItemSelected(item);
                break;
        }

        return (rc);
    }
}
