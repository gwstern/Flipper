package com.gwstern.flipper2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

// Runs all unit tests.
@RunWith(Suite.class)
@Suite.SuiteClasses({
    TickerTests.class,
    ClickTests.class,
})

public class TestAndroidSuite {
}
