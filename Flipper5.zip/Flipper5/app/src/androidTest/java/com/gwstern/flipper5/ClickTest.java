package com.gwstern.flipper5;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.contrib.NavigationViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper5.util.AssertFailureHandler;
import com.gwstern.flipper5.util.MyLog;
import com.gwstern.flipper5.util.MyUtils;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.contrib.DrawerActions.open;
import static androidx.test.espresso.contrib.DrawerMatchers.isOpen;
import static androidx.test.espresso.matcher.RootMatchers.isDialog;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isCompletelyDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withEffectiveVisibility;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.gwstern.flipper5.util.EspressoTestMatchers.withDrawable;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.AllOf.allOf;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class ClickTest {

    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Test that things can be changed on the board. Sorta neat to watch.
     */
    @Test
    public void testBoard() {
        MyLog.d("TickerTest.testBoard ()");

        int[] widgets = {
                R.id.posA1, R.id.posB1, R.id.posC1, R.id.posD1, R.id.posE1, R.id.posF1, R.id.posG1, R.id.posH1,
                R.id.posA2, R.id.posB2, R.id.posC2, R.id.posD2, R.id.posE2, R.id.posF2, R.id.posG2, R.id.posH2,
                R.id.posA3, R.id.posB3, R.id.posC3, R.id.posD3, R.id.posE3, R.id.posF3, R.id.posG3, R.id.posH3,
                R.id.posA4, R.id.posB4, R.id.posC4, R.id.posD4, R.id.posE4, R.id.posF4, R.id.posG4, R.id.posH4,
                R.id.posA5, R.id.posB5, R.id.posC5, R.id.posD5, R.id.posE5, R.id.posF5, R.id.posG5, R.id.posH5,
                R.id.posA6, R.id.posB6, R.id.posC6, R.id.posD6, R.id.posE6, R.id.posF6, R.id.posG6, R.id.posH6,
                R.id.posA7, R.id.posB7, R.id.posC7, R.id.posD7, R.id.posE7, R.id.posF7, R.id.posG7, R.id.posH7,
                R.id.posA8, R.id.posB8, R.id.posC8, R.id.posD8, R.id.posE8, R.id.posF8, R.id.posG8, R.id.posH8,
        };

        AssertFailureHandler fh = new AssertFailureHandler();

        for (int drawable : widgets) {
            Espresso.onView(withId(drawable)).perform(click());
            Espresso.onView(withId(drawable)).
                    withFailureHandler(fh).check(matches(withDrawable(R.drawable.light_piece)));
            Espresso.onView(withId(drawable)).perform(click());
            Espresso.onView(withId(drawable)).
                    withFailureHandler(fh).check(matches(withDrawable(R.drawable.dark_piece)));
            Espresso.onView(withId(drawable)).perform(click());
            Espresso.onView(withId(drawable)).
                    withFailureHandler(fh).check(matches(withDrawable(R.drawable.empty)));
        }
    }

    /**
     * Test the buttons in the actionbar and overflow menu.
     */
    @Test
    public void testNavDrawer() {
        MyLog.d("TickerTest.testNavDrawer ()");

        Espresso.onView(withId(R.id.drawer_layout))
                .perform(open());

        // Various ways of checking that the navigation drawer is open
        Espresso.onView(withId(R.id.version))
                .check(matches(withText(R.string.app_name)));
        Espresso.onView(withId(R.id.drawer_layout))
                .check(matches(isDisplayed()));
        Espresso.onView(withId(R.id.drawer_layout))
                .check(matches(isOpen()));

        // Testing of RateIt is done in RateItTest. We just want to check that
        // it come sup.
        Espresso.onView(withId(R.id.nav_view))
                .perform(NavigationViewActions.navigateTo(R.id.rate));

        Espresso.onView(allOf(withId(R.id.rate_description), isCompletelyDisplayed()))
                .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));

        Espresso.pressBack();

        // Since this is an alert dialog we test if the string is visible
        Espresso.onView(withId(R.id.nav_view))
                .perform(NavigationViewActions.navigateTo(R.id.report_bug));

        Espresso.onView(withText(R.string.describe_bug_text))
                .check(matches(isDisplayed()));

        // Press back doesn't work for alert dialogs
        Espresso.onView(withText("CANCEL"))
                .inRoot(isDialog())
                .check(matches(isDisplayed()))
                .perform(click());

        // Testing of Settings is done in SettingsTest. We just want to check
        // it comes up.
        Espresso.onView(withId(R.id.drawer_layout))
                .perform(open());

        Espresso.onView(withId(R.id.nav_view)).perform(NavigationViewActions.navigateTo(R.id.app_settings));

        Espresso.onView(allOf(withId(R.id.h_or_c1), isCompletelyDisplayed()))
                .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));
        Espresso.pressBack();

        // About box testing is done in AboutTest. We just want to make sure it
        // comes up.
        Espresso.onView(withId(R.id.drawer_layout))
                .perform(open());
        Espresso.onView(withId(R.id.nav_view)).perform(NavigationViewActions.navigateTo(R.id.about));

        Espresso.onView(allOf(withId(R.id.about_title), isCompletelyDisplayed()))
                .check(matches(withEffectiveVisibility(ViewMatchers.Visibility.VISIBLE)));

        Espresso.pressBack();
    }

    /**
     * Test the buttons at the bottom of the screen.
     */
    @Test
    public void testBottomNavigation() {
        MyLog.d("TickerTest.testBottomNavigation ()");

        Espresso.onView(withId(R.id.pause)).perform(click());
        Espresso.onView(withText("<pause>")).
                inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        MyUtils.sleep(5); // Wait for previous toast go go away

        Espresso.onView(withId(R.id.reset)).perform(click());
        Espresso.onView(withText("<reset>")).
                inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        MyUtils.sleep(5); // Wait for previous toast go go away

        Espresso.onView(withId(R.id.quit)).perform(click());
        Espresso.onView(withText("<quit>")).
                inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        // Help is tested in HelpTest
    }
}
