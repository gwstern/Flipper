package com.gwstern.flipper5;

import android.os.Parcel;

import com.gwstern.flipper5.toolbar.SETTING_KEYS;
import com.gwstern.flipper5.util.MyLog;
import com.gwstern.flipper5.util.MyProps;

import org.junit.Assert;
import org.junit.Test;

/**
 * Test the MyProps Property replacement. Because this tests uses Parcel we
 * need to run it under 'androidTest' instead of simply 'test'.
 */
public class MyPropsParcelTest {
    /**
     * Test that the Property-type methods all work
     */
    @Test
    public void PropertyTests() {
        MyProps<SETTING_KEYS> props1 = new MyProps<>();

        props1.put(SETTING_KEYS.PLAYER1_NAME, "mothra");
        props1.put(SETTING_KEYS.PLAYER2_NAME, "rodan");

        Parcel parcel = Parcel.obtain();
        props1.writeToParcel(parcel, 0);
        parcel.setDataPosition(0);
        MyProps<SETTING_KEYS> parceledFoo = MyProps.CREATOR.createFromParcel(parcel);
        MyLog.d ("props1="+props1);
        MyLog.d ("parceled="+parceledFoo);
        Assert.assertTrue (props1.equals(parceledFoo));
    }
}
