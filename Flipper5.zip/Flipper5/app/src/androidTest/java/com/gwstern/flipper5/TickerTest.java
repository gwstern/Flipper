package com.gwstern.flipper5;

import android.widget.TextView;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper5.ticker.TickerImpl;
import com.gwstern.flipper5.util.MyLog;
import com.gwstern.flipper5.util.MyUtils;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class TickerTest {

    private TickerImpl _ticker_under_test;

    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Called before each test
     */
    @Before
    public void getTicker() {
        _ticker_under_test = main.getActivity()._ticker;
        _ticker_under_test.start((TextView) main.getActivity().findViewById(R.id.ticker));
    }

    /**
     * Test the ticker.
     */
    @Test
    public void testTicker() {
        MyLog.d("TickerTest.testTicker ()");

        long start;
        long end;

        // Timer should start and count to 1
        start = _ticker_under_test.getTicks();
//        MyLog.d ("start="+start);
        MyUtils.sleep(1);
        end = _ticker_under_test.getTicks();
//        MyLog.d ("end="+end);
        Assert.assertTrue(start <= end && end <= start + 1);

        // Timer should run for 30 seconds
        start = _ticker_under_test.getTicks();
//        MyLog.d("start=" + start);
        MyUtils.sleep(30);
        end = _ticker_under_test.getTicks();
//        MyLog.d("end=" + end);
        Assert.assertTrue(start <= end && end <= start + 31);

        _ticker_under_test.stop();

        // Timer should stop and not count anymore
        start = _ticker_under_test.getTicks();
//        MyLog.d("start=" + start);
        MyUtils.sleep(30);
//        MyLog.d("end=" + end);
        Assert.assertEquals(start, end);
    }

    /**
     * Test pausing/resuming of ticker.
     */
    @Test
    public void testPauseResume() {
        MyLog.d("TickerTest.testPauseResume ()");

        long start;
        long end;

        // Timer should run for 5 seconds (basially put some time on it)
        start = _ticker_under_test.getTicks();
//        MyLog.d("start=" + start);
        MyUtils.sleep(5);
        end = _ticker_under_test.getTicks();
//        MyLog.d("end=" + end);
        Assert.assertTrue(start <= end && end <= start + 6);

        // Pause the timer - no time should accrue
        start = _ticker_under_test.getTicks();
//        MyLog.d("before pause: " + start);
        _ticker_under_test.pause();
        MyUtils.sleep(10);
        end = _ticker_under_test.getTicks();
//        MyLog.d("after pause: " + end);
        Assert.assertTrue(start <= end && end <= start + 1);

        // Start the timer. Time should start accruing.
//        MyLog.d("before resume: " + _ticker_under_test.getTicks());
        _ticker_under_test.resume();
        start = _ticker_under_test.getTicks();
        MyUtils.sleep(10);
//        MyLog.d("after resume: " + _ticker_under_test.getTicks());
        Assert.assertTrue(start <= end && end <= start + 11);

        _ticker_under_test.stop();
    }
}
