package com.gwstern.flipper5.toolbar;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gwstern.flipper5.R;
import com.gwstern.flipper5.util.MyLog;
import com.gwstern.flipper5.util.MyProps;

/**
 * This class shows how a simple 'Rate Me' dialog might work. Of course, there are
 * a lot of good third-party routines to do this but this is a teaching app.
 *
 * Based on a stackoverflow posting by Raghav Sood:
 *   https://stackoverflow.com/questions/14514579/how-to-implement-rate-it-feature-in-android-app
 */
public class RateItActivity extends AppCompatActivity {
    /**
     * Called when the window is created. All it does is display information
     * about this app.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("RateItActivity.onCreate (" + savedInstanceState + ")");

        final MyProps<SETTING_KEYS> props = getIntent().getExtras().getParcelable("PROPS");
        SharedPreferences prefs = getSharedPreferences(props.get(SETTING_KEYS.PREF_NAME), 0);
        final SharedPreferences.Editor editor = prefs.edit();
        final Dialog dialog = new Dialog(this);

        dialog.setTitle(getString(R.string.rate_title));

        // Rather than using XML this layout/dialog/window is built programmatically.
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

        TextView tv = new TextView(this);
        tv.setText(getString(R.string.rate_description));
        tv.setId(R.id.rate_description); // Needed for unit testing. Note that values/ids.xml is created for this
        tv.setWidth(240);
        tv.setPadding(4, 0, 4, 10);
        ll.addView(tv);

        Button b = new Button(this);
        b.setText(getString(R.string.rate_button));
        b.setId(R.id.rate_app); // Needed for unit testing.
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // This won't work because the app isn't part of google play, but
                // it shows how it could be done.
                String package_name = "com.gwstern.flipper5";

                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + package_name)));
                dialog.dismiss();
            }
        });
        ll.addView(b);

        b = new Button(this);
        b.setText(R.string.remind_button);
        b.setId(R.id.remind); // Needed for unit testing
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//                editor.putLong(props.get(SETTING_KEYS.LAUNCH_COUNT_KEY), 0);
                dialog.dismiss();
            }
        });
        ll.addView(b);

        b = new Button(this);
        b.setText(getString(R.string.stop_asking_button));
        b.setId(R.id.stop_asking); // Needed for unit testing
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (editor != null) {
                    editor.putBoolean(props.get(SETTING_KEYS.DSA_KEY), true);
                    editor.commit();
                }
                dialog.dismiss();
            }
        });
        ll.addView(b);

        dialog.setCancelable(true);
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                finish();
            }
        });

        dialog.setContentView(ll);
        dialog.show();
    }
}
