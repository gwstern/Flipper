/**
 * This is a simple Reversi/Othello-type program designed to show how one might
 * build an Android application. Each successive app builds on the previous one.
 * <p>
 * History:
 * 10 Jul 2019 Added logging, improved comments, brought up to production
 *             standards
 * 17 Jul 2019 Converted to use AndroidX
 *             Added unit testing
 *             Added layouts
 *             Updated manifest
 * 25 Jul 2019 Added fragments and intents
 *  1 Jul 2019 Added styles and themes
 *             Added action bar and menus
 * 10 Jul 2019 Added navigation bar
 *             Incorporated expresson testing for navigation bar
 */
package com.gwstern.flipper5;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.gwstern.flipper5.help.HelpDialogFragment;
import com.gwstern.flipper5.ticker.TickerImpl;
import com.gwstern.flipper5.toolbar.AboutActivity;
import com.gwstern.flipper5.toolbar.RateItActivity;
import com.gwstern.flipper5.toolbar.SETTING_KEYS;
import com.gwstern.flipper5.toolbar.SettingsDialogFragment;
import com.gwstern.flipper5.util.MyLog;
import com.gwstern.flipper5.util.MyProps;

/**
 * This is where it all begins. Class currently does nothing more than run a
 * app that has a simple menu, FAB and greeting
 *
 *
 * https://en.wikipedia.org/wiki/Reversi
 * https://bonaludo.com/2016/02/18/reversi-and-othello-two-different-games-do-you-know-their-different-rules/
 * https://www.yourturnmyturn.com/rules/reversi.php
 *
 */
public class MainActivity extends AppCompatActivity implements SettingsDialogFragment.SettingsListener, NavigationView.OnNavigationItemSelectedListener  {

    /*package*/ MyProps<SETTING_KEYS> _game_props = new MyProps<> ();

    /*package*/ TickerImpl _ticker;

    /**
     * I like to have at least *some* information displayed if the program
     * exists unexpectedly.
     */
    public MainActivity() {
        Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread,
                                          Throwable ex) {
                MyLog.wtf(getApplicationContext(), "uncaughtException - ", ex);
            }
        });
    }

    /**
     * Called when the window is created.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it
     *                           has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("MainActivity.onCreate (" + savedInstanceState + ")");

        // Create the layout
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Create the navigation drawer
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open_bar, R.string.close_bar);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        // Create a timer
        _ticker = new TickerImpl();

        // Define some actions for the buttons on the bottom
        ImageButton ib = findViewById(R.id.pause);

        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<pause> (" + view + ")");

                Snackbar.make(view, "<pause>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Both the way below and the way above are valid syntax. One can also
        // have MainActivity implement View.OnClickListener() as well. I like the
        // lower one if I will never use the variable and the action is simple.
        findViewById(R.id.quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<quit> (" + view + ")");

                Snackbar.make(view, "<quit>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        findViewById(R.id.reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<reset> (" + view + ")");

                Snackbar.make(view, "<reset>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        findViewById(R.id.help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<help> (" + view + ")");

                HelpDialogFragment hdf = HelpDialogFragment.newInstance();
                hdf.show(getSupportFragmentManager(), "help fragement");
            }
        });

        // For now we just hardcode things - permanent storage comes in a later version.
        _game_props.put (SETTING_KEYS.PLAYER1_TYPE, "H");
        _game_props.put (SETTING_KEYS.PLAYER1_NAME, "Mr. Human");
        _game_props.put (SETTING_KEYS.PLAYER1_ICON, "piece4a");
        _game_props.put (SETTING_KEYS.PLAYER2_TYPE, "C");
        _game_props.put (SETTING_KEYS.PLAYER2_NAME, getResources().getText(R.string.computer_player2_text).toString());
        _game_props.put (SETTING_KEYS.PLAYER2_ICON, "piece4b");
        _game_props.put (SETTING_KEYS.FORCE_CAPTURE, "false");
        _game_props.put (SETTING_KEYS.START_WITH_4, "false");
        _game_props.put (SETTING_KEYS.DAYS_UNTIL_PROMPT, "3");
        _game_props.put (SETTING_KEYS.LAUNCHES_UNTIL_PROMPT, "3");
        _game_props.put (SETTING_KEYS.PREF_NAME, "apprater");
        _game_props.put (SETTING_KEYS.DSA_KEY, "dontshowagain");
        _game_props.put (SETTING_KEYS.LAUNCH_COUNT_KEY, "launch_count");
        _game_props.put (SETTING_KEYS.DATE_KEY, "date_firstlaunch");
    }

    /**
     * Rather than setting setOnClickListener() for every board piece as we did in the
     * previous versions we simply define a method that handles the clicks and define
     * onClick in styles.xml.
     *
     * @param view The view (ImageView) of this board position.
     */
    public void handleBoardClick(View view) {
        MyLog.d ("MainActivity.handleBoardClick (" + view + ")");

        ImageView iv = (ImageView)view;

        switch (SQUARE.map(iv.getTag().toString())) {
            case EMPTY:
                iv.setImageResource(R.drawable.light_piece);
                iv.setTag(SQUARE.LIGHT);
                break;
            case LIGHT:
                iv.setImageResource(R.drawable.dark_piece);
                iv.setTag(SQUARE.DARK);
                break;
            case DARK:
                iv.setImageResource(R.drawable.empty);
                iv.setTag(SQUARE.EMPTY);
                break;
            default:
                MyLog.wtf (null, "Unexpected board type");
                break;
        }
    }

    /**
     * Called when a fragment is attached as a child of this fragment.
     *
     * @param f Child fragment being attached.
     */
    @Override
    public void onAttachFragment (Fragment f) {
        MyLog.d ("MainActivity.onAttachFragment (" + f + ")");

        if (f instanceof SettingsDialogFragment) {
            ((SettingsDialogFragment) f).setMyListener(this);
        }
    }

    /**
     * Method called when the settings have changed.
     *
     * @param new_settings New settings if !null
     */
    public void getNewSettings(MyProps<SETTING_KEYS> new_settings) {
        MyLog.d ("MainActivity.getNewSettings (" + new_settings + ")");

        if (new_settings != null) {
            _game_props.clear();
            _game_props.putAll(new_settings);
        }
    }

    /**
     * Creates the options menu for the main activity.
     *
     * @param menu The instance selected.
     * @return true to display the menu; false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MyLog.d("MainActivity.onCreateOptionsMenu (" + menu + ")");

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return (true);
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callAboutActivity(MenuItem item) {
        MyLog.d("MainActivity.callAboutActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), AboutActivity.class);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);

            // To be consistent with the other menu items we close the navigation drawer
            ((DrawerLayout)findViewById(R.id.drawer_layout)).closeDrawer(GravityCompat.START);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'AboutActivity'");
        }
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callRateItActivity(MenuItem item) {
        MyLog.d("MainActivity.callRateItActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), RateItActivity.class);

        intent.putExtra("PROPS", _game_props);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'RateItActivity'");
        }
    }

    /**
     * Since some menu items can be called from the nav drawer or from the drop
     * down menu we handle all menu items here.
     *
     * @param item The item selected.
     * @return true if the selection has been processed.
     */
    private boolean handleMenuItems (MenuItem item) {
        MyLog.d ("MainActivity.handleMenuItems (" + item + ")");
        boolean rc = false;

        switch (item.getItemId()) {
            case R.id.app_settings:
                SettingsDialogFragment sdf = SettingsDialogFragment.newInstance(_game_props);
                // Seems the default for dialogs is no window title after API 23
                // so we have to 'fix' that by setting R.style.DialogFragment
                sdf.setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragment);
                sdf.show(getSupportFragmentManager(), "settings_fragment");

                rc = true;
                break;

            case R.id.report_bug:
                // Create a popup dialog with an entry field and two buttons
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                final EditText et = new EditText(getApplicationContext());

                alertDialogBuilder.setView(et);

                // Send the bug report
                alertDialogBuilder.setCancelable(false).setPositiveButton(getApplicationContext().getString(R.string.submit_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d ("MainActivity.onClick<ok> (" + dialog + "," + id + ")");

                        // Send a email bug report via email
                        Intent email_intent = new Intent(Intent.ACTION_SENDTO);
                        String[] addresses = {getApplicationContext().getString(R.string.bug_email_text),};

                        email_intent.setData (Uri.fromParts(
                                "mailto", getApplicationContext().getString(R.string.bug_email_text), null));
                        email_intent.putExtra(Intent.EXTRA_SUBJECT, getApplicationContext().getString(R.string.email_subject_text));
                        email_intent.putExtra(Intent.EXTRA_TEXT, et.getText());
                        email_intent.putExtra(Intent.EXTRA_EMAIL, addresses); // Android 4.3 requires an additional field with email addresses

                        startActivity(Intent.createChooser(email_intent, getApplicationContext().getString(R.string.sending_email_text)));
                    }
                });

                // Close the report and return to program
                alertDialogBuilder.setCancelable(false).setNegativeButton(getApplicationContext().getString(R.string.cancel_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d ("MainActivity.onClick<cancel> (" + dialog + "," + id + ")");
                    }
                });

                // Show the dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.setTitle(R.string.describe_bug_text);
                alertDialog.show();

                rc = true;
                break;

            default:
                rc = super.onOptionsItemSelected(item);
                break;
        }

        return (rc);
    }

    /**
     * Handle action bar item clicks here. The action bar will
     * automatically handle clicks on the Home/Up button, so long
     * as you specify a parent activity in AndroidManifest.xml.
     *
     * @param item The menu item selected.
     * @return false to allow normal menu processing; true to consume it.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onOptionsItemSelected (" + item + ")");

        boolean rc = handleMenuItems(item);

        if (!rc) {
            rc = super.onOptionsItemSelected(item);
        }

        return (rc);
    }

    /**
     * Called when an item in the navigation drawer is selected.
     *
     * @param item The item selected.
     * @return true to display the item; (?) false not to display it.
     */
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        MyLog.d ("MainActivity.onNavigationItemSelected (" + item + ")");

        // Handle navigation view item clicks here.

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        handleMenuItems(item);

        return true;
    }

    /**
     * Called when the back key is pressed. Here we close the drawer if it's
     * open otherwise let Android handle it.
     */
    @Override
    public void onBackPressed() {
        MyLog.d ("MainActivity.onBackPressed ()");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
