package com.gwstern.flipper5.toolbar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.gwstern.flipper5.util.MyLog;
import com.gwstern.flipper5.util.MyProps;

import java.util.Date;

/**
 * This class handles all the rating functionality such as making sure the
 * user isn't prompted to frequently and respects the 'go away and never
 * bother me again' state.
 */
public class RateIt {
    /**
     * Resets/Erases all shared preferences for this app. Probably not something
     * you want to do frequently but useful when first getting this to work.
     *
     * @param context App context.
     * @param props Properties for this app.
     */
    public void reset (Context context, MyProps<SETTING_KEYS> props) {
        MyLog.d ("AppRater.reset (" + context + "," + props + ")");

        SharedPreferences prefs = context.getSharedPreferences(props.get(SETTING_KEYS.PREF_NAME), 0);
        SharedPreferences.Editor editor = prefs.edit();

        editor.clear();
        editor.apply();
    }

    /**
     * Will bring up the 'please rate me' dialog if the user hasn't selected to
     * never rate or the number of launches and date thresholds have been
     * reached. Does nothing otherwise.
     *
     * Yes, we could have used data structures other than of SharedPreferences
     * but 1) this is a teaching app, 2) SharedPreferences allows multiple apps
     * to use the same settings.
     *
     * @param context App context.
     * @param props Properties for this app.
     */
    public void rateApp(Context context, MyProps<SETTING_KEYS> props) {
        MyLog.d ("AppRater.rateApp (" + context + "," + props + ")");

        final int MILLI_SECS_IN_DAY = 24 * 60 * 60 * 1000;

        String launch_count_key = props.get(SETTING_KEYS.LAUNCH_COUNT_KEY);
        String date_key = props.get(SETTING_KEYS.DATE_KEY);
        int launches_until_prompt = Integer.parseInt(props.get(SETTING_KEYS.LAUNCHES_UNTIL_PROMPT));
        int days_until_prompt = Integer.parseInt(props.get(SETTING_KEYS.DAYS_UNTIL_PROMPT));

        SharedPreferences prefs = context.getSharedPreferences(props.get(SETTING_KEYS.PREF_NAME), 0);
        if (prefs.getBoolean(props.get(SETTING_KEYS.DSA_KEY), false)) {
            MyLog.d ("User doesn't want to be bothered anymore");
            return;
        }
        SharedPreferences.Editor editor = prefs.edit();

        // Increment launch counter
        long launch_count = prefs.getLong(launch_count_key, 0) + 1;
        editor.putLong(launch_count_key, launch_count);
        MyLog.d ("Updating launch counter");

        // Get date of first launch
        Long date_firstLaunch = prefs.getLong(date_key, 0);
        if (date_firstLaunch == 0) {
            date_firstLaunch = System.currentTimeMillis();
            editor.putLong(date_key, date_firstLaunch);
            MyLog.d ("Updating date");
        }

        // Wait at least n days before opening
        MyLog.d (launch_count + ">=" + launches_until_prompt);
        MyLog.d (new Date(System.currentTimeMillis()) + ">=" + new Date (date_firstLaunch+(days_until_prompt*MILLI_SECS_IN_DAY)));
        if (launch_count >= launches_until_prompt) {
            if (System.currentTimeMillis() >= date_firstLaunch +
                    (days_until_prompt * MILLI_SECS_IN_DAY)) {
                MyLog.d ("Launching");

                Intent intent = new Intent(context, RateItActivity.class);

                intent.putExtra("PROPS", props);

                if (intent.resolveActivity(context.getPackageManager()) != null) {
                    context.startActivity(intent);
                } else {
                    MyLog.wtf(context, "Unable to start 'RateItActivity'");
                }
            }
        }

        editor.apply();
    }
}
