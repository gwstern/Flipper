package com.gwstern.flipper3;

import com.gwstern.flipper3.toolbar.SETTING_KEYS;
import com.gwstern.flipper3.util.MyProps;

import org.junit.Assert;
import org.junit.Test;

import java.util.AbstractMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Test the MyProps Property replacement
 */
public class MyPropsTest {
    /**
     * Test that the Property-type methods all work
     */
    @Test
    public void PropertyTests() {
        MyProps<SETTING_KEYS> props1 = new MyProps<>();
        MyProps<SETTING_KEYS> props1a = new MyProps<>();

        // Test that only one enum is allowed
// This fails at compile time, as it should.        props1.put (SQUARE.DARK, "42");

        // clear()
        props1.put(SETTING_KEYS.PLAYER1_NAME, "mothra");
        props1.put(SETTING_KEYS.PLAYER2_NAME, "rodan");
        Assert.assertEquals(2, props1.size());
        props1.clear();
        Assert.assertEquals(0,props1.size());

        // containsValue()
        props1.put(SETTING_KEYS.PLAYER1_NAME, "mothra");
        props1.put(SETTING_KEYS.PLAYER2_NAME, "rodan");
        Assert.assertTrue(props1.containsValue("mothra"));
        Assert.assertFalse(props1.containsValue("godzilla"));

        // containsKey()
        Assert.assertTrue(props1.containsKey(SETTING_KEYS.PLAYER1_NAME));
        Assert.assertFalse(props1.containsKey(SETTING_KEYS.DATE_KEY));

        // equals()
        props1a.put(SETTING_KEYS.PLAYER1_NAME, "mothra");
        props1a.put(SETTING_KEYS.PLAYER2_NAME, "rodan");
        Assert.assertTrue (props1a.equals(props1));

        props1a.put(SETTING_KEYS.FORCE_CAPTURE, "false");
        Assert.assertFalse (props1a.equals(props1));

        // entrySet()
        HashSet<Map.Entry<SETTING_KEYS,String>> expected = new HashSet<> ();

        expected.add (new AbstractMap.SimpleEntry<>(SETTING_KEYS.PLAYER1_NAME, "mothra"));
        expected.add (new AbstractMap.SimpleEntry<>(SETTING_KEYS.PLAYER2_NAME, "rodan"));

        Assert.assertEquals (expected, props1.entrySet());

        // remove
        Assert.assertEquals(3, props1a.size());
        props1a.remove(SETTING_KEYS.FORCE_CAPTURE);
        Assert.assertEquals(2, props1a.size());
        props1a.remove(SETTING_KEYS.LAUNCH_COUNT_KEY);
        Assert.assertEquals(2, props1a.size());
        props1a.remove(SETTING_KEYS.PLAYER1_NAME);
        Assert.assertEquals(1, props1a.size());
        props1a.remove(SETTING_KEYS.PLAYER2_NAME);
        Assert.assertEquals(0, props1a.size());
    }
}