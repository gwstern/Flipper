package com.gwstern.flipper3;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Defines all the tests that are part of this suite
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
        AboutTest.class,
        ClickTest.class,
        HelpTest.class,
        MyPropsParcelTest.class,
        RateItTest.class,
        SettingsTest.class,
        TickerTest.class,
})

public class TestAndroidSuite {
}
