package com.gwstern.flipper3.util;

import android.view.View;

import org.hamcrest.Matcher;
import org.junit.Assert;

/**
 * I want a bit more information than an exception trace.
 */
public class AssertFailureHandler implements androidx.test.espresso.FailureHandler {
    /**
     * Called when there's an assertion failure in the Hamcrest checks.
     *
     * @param error What caused the exception.
     * @param viewMatcher The match that the exception occurred in.
     */
    @Override
    public void handle(Throwable error, Matcher<View> viewMatcher) {
        Assert.assertTrue (viewMatcher.toString() + " threw " + error, false);
    }
}
