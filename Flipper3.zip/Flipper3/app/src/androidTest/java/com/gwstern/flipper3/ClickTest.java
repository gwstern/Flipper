package com.gwstern.flipper3;

import androidx.test.espresso.Espresso;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.gwstern.flipper3.util.AssertFailureHandler;
import com.gwstern.flipper3.util.MyLog;
import com.gwstern.flipper3.util.MyUtils;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.gwstern.flipper3.util.EspressoTestMatchers.withDrawable;
import static org.hamcrest.CoreMatchers.is;

/**
 * Instrumented test, which will execute on an Android device.
 */
@RunWith(AndroidJUnit4.class)
public class ClickTest {

    // Annotation for testing the MainActivity
    @Rule
    public final ActivityTestRule<MainActivity> main = new ActivityTestRule<>(MainActivity.class, true);

    /**
     * Test that things can be changed on the board. Sorta neat to watch.
     */
    @Test
    public void testBoard() {
        MyLog.d("TickerTest.testBoard ()");

        int[] widgets = {
                R.id.posA1, R.id.posB1, R.id.posC1, R.id.posD1, R.id.posE1, R.id.posF1, R.id.posG1, R.id.posH1,
                R.id.posA2, R.id.posB2, R.id.posC2, R.id.posD2, R.id.posE2, R.id.posF2, R.id.posG2, R.id.posH2,
                R.id.posA3, R.id.posB3, R.id.posC3, R.id.posD3, R.id.posE3, R.id.posF3, R.id.posG3, R.id.posH3,
                R.id.posA4, R.id.posB4, R.id.posC4, R.id.posD4, R.id.posE4, R.id.posF4, R.id.posG4, R.id.posH4,
                R.id.posA5, R.id.posB5, R.id.posC5, R.id.posD5, R.id.posE5, R.id.posF5, R.id.posG5, R.id.posH5,
                R.id.posA6, R.id.posB6, R.id.posC6, R.id.posD6, R.id.posE6, R.id.posF6, R.id.posG6, R.id.posH6,
                R.id.posA7, R.id.posB7, R.id.posC7, R.id.posD7, R.id.posE7, R.id.posF7, R.id.posG7, R.id.posH7,
                R.id.posA8, R.id.posB8, R.id.posC8, R.id.posD8, R.id.posE8, R.id.posF8, R.id.posG8, R.id.posH8,
        };

        AssertFailureHandler fh = new AssertFailureHandler();

        for (int drawable : widgets) {
            Espresso.onView(withId(drawable)).perform(click());
            Espresso.onView(withId(drawable)).
                    withFailureHandler(fh).check(matches(withDrawable(R.drawable.light)));
            Espresso.onView(withId(drawable)).perform(click());
            Espresso.onView(withId(drawable)).
                    withFailureHandler(fh).check(matches(withDrawable(R.drawable.dark)));
            Espresso.onView(withId(drawable)).perform(click());
            Espresso.onView(withId(drawable)).
                    withFailureHandler(fh).check(matches(withDrawable(R.drawable.empty)));
        }
    }

    /**
     * Test the buttons in the actionbar and overflow menu.
     */
    @Test
    public void testToolbar() {
        MyLog.d("TickerTest.testToolbar ()");

        // All other toolbar items are tested separably
    }

    /**
     * Test the buttons at the bottom of the screen.
     */
    @Test
    public void testBottomNavigation() {
        MyLog.d("TickerTest.testBottomNavigation ()");

        Espresso.onView(withId(R.id.pause)).perform(click());
        Espresso.onView(withText("<pause>")).
                inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        MyUtils.sleep(5); // Wait for previous toast go go away

        Espresso.onView(withId(R.id.reset)).perform(click());
        Espresso.onView(withText("<reset>")).
                inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        MyUtils.sleep(5); // Wait for previous toast go go away

        Espresso.onView(withId(R.id.quit)).perform(click());
        Espresso.onView(withText("<quit>")).
                inRoot(withDecorView(is(main.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        //GWS test help
    }
}
