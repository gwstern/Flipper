package com.gwstern.flipper3.ticker;

import android.os.Looper;
import android.widget.TextView;

import com.gwstern.flipper3.util.MyLog;

import android.os.Handler;

/**
 * Implements the ITicker interface.
 */
public class TickerImpl implements ITicker {
    private TextView _timer_gui;
    private Handler _timer_handler;
    private long startTime = 0;
    private long diff = 0;
    private Runnable _gui_update_thread;

    /**
     * Class wrapper for the runnable function. I like having things that are
     * moderately complex in their own class/method/function rather than inline.
     */
    class TickerUpdater implements Runnable {
        @Override
        public void run() {
            MyLog.v("TickerImpl.run()");

            long millis = System.currentTimeMillis() - startTime;
            int seconds = (int) (millis / 1000);
            int minutes = seconds / 60;
            seconds = seconds % 60;

            _timer_gui.setText(String.format("%02d:%02d", minutes, seconds));

            _timer_handler.postDelayed(this, 500);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void start(TextView widget) {
        MyLog.d("TickerImpl.start(" + widget + ")");

        _timer_gui = widget;

        // Runs without a timer by reposting this handler at the end of the runnable
        // Note the Looper is needed by AndroidJUnit4
        _timer_handler = new Handler(Looper.getMainLooper());

        _gui_update_thread = new TickerUpdater();

        reset();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void stop() {
        MyLog.d("TickerImpl.stop()");

        _timer_handler.removeCallbacks(_gui_update_thread);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void pause() {
        MyLog.d("TickerImpl.pause()");

        // How long the timer had been running till it was paused
        diff = System.currentTimeMillis() - startTime;

        _timer_handler.removeCallbacks(_gui_update_thread);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void resume() {
        MyLog.d("TicketImpl.resume()");

        // We want the clock to start from the paused time, not from the actual time
        // so we 'cheat' by resetting the start time to be the current time minus
        // the paused time, basically jumping the timing clock forward to compensate
        // for the pause
        startTime = System.currentTimeMillis() - diff;

        _timer_handler.postDelayed(_gui_update_thread, 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void reset() {
        MyLog.d("TickerImpl.reset()");

        _timer_handler.postDelayed(_gui_update_thread,0);
        startTime = System.currentTimeMillis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public long getTicks() {
        long rc = 0;
        String[] pieces = _timer_gui.getText().toString().split(":");

        rc = Integer.parseInt(pieces[0])*60 + Integer.parseInt(pieces[1]);

        return (rc);
    }

}
