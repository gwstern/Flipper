package com.gwstern.flipper3.toolbar;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.gwstern.flipper3.R;
import com.gwstern.flipper3.util.MyLog;

/**
 * An activity that displays information about this app.
 */
public class AboutActivity extends AppCompatActivity {

    /**
     * Called when the window is created. All it does is display information
     * about this app.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d ("AboutActivity.onCreate (" + savedInstanceState + ")");

        setContentView(R.layout.about_activity);

        TextView tv = findViewById(R.id.about_title);
        tv.setText(R.string.about_title);

        tv = findViewById(R.id.about_details);
        tv.setText(R.string.about_content);

        findViewById(R.id.ok).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d ("AboutActivity.onClick (" + view + ")");

                finish();
            }
        });
    }
}
