package com.gwstern.flipper3.help;

import android.os.Bundle;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.DialogFragment;
import androidx.viewpager.widget.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gwstern.flipper3.R;
import com.gwstern.flipper3.util.MyLog;

/**
 * Handle the game settings menu.
 */
public class HelpDialogFragment extends DialogFragment {

    /**
     * Empty constructor is required for DialogFragment. Make sure not to add
     * arguments to the constructor. Use `newInstance()` instead as shown below
     */
    public HelpDialogFragment() {
    }

    /**
     * Create an instance of this fragment.
     *
     * @return The instance.
     */
    public static HelpDialogFragment newInstance() {
        MyLog.d("HelpDialogFragment.newInstance ()");

        HelpDialogFragment adf = new HelpDialogFragment();

        return (adf);
    }

    /**
     * Creates and returns the view hierarchy associated with the fragment.
     *
     * @param inflater The LayoutInflater used to inflate Views of this Fragment.
     * @param container If non-null, this is the parent view that the fragment's
     *                  UI should be attached to.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state/
     * @return The view that's created
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        MyLog.d("HelpDialogFragment.onCreateView (" + inflater + "," + container + "," + savedInstanceState + ")");

        View view = inflater.inflate(R.layout.help_fragment, container);

        // This is a bit of overkill for help but it's a good demonstration of
        // fragments, ViewPager and tabs
        HelpPagesAdapter adapter = new HelpPagesAdapter (getContext(), getChildFragmentManager());

        ViewPager vp = view.findViewById(R.id.view_pager);
        vp.setAdapter(adapter);

        TabLayout tabs = view.findViewById(R.id.tabs);
        tabs.setupWithViewPager(vp);

        return (view);
    }
}