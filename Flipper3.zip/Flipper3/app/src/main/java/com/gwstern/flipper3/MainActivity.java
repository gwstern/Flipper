/**
 * This is a simple Reversi/Othello-type program designed to show how one might
 * build an Android application. Each successive app builds on the previous one.
 * <p>
 * History:
 * 10 Jul 2019 Added logging, improved comments, brought up to production
 *             standards
 * 17 Jul 2019 Converted to use AndroidX
 *             Added unit testing
 *             Added layouts
 *             Updated manifest
 * 25 Jul 2019 Added fragments and intents
 */
package com.gwstern.flipper3;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;

import com.gwstern.flipper3.help.HelpDialogFragment;
import com.gwstern.flipper3.ticker.TickerImpl;
import com.gwstern.flipper3.toolbar.AboutActivity;
import com.gwstern.flipper3.toolbar.RateItActivity;
import com.gwstern.flipper3.toolbar.SETTING_KEYS;
import com.gwstern.flipper3.toolbar.SettingsDialogFragment;
import com.gwstern.flipper3.util.MyLog;
import com.gwstern.flipper3.util.MyProps;

/**
 * This is where it all begins. Class currently does nothing more than run a
 * app that has a simple menu, FAB and greeting
 *
 *
 * https://en.wikipedia.org/wiki/Reversi
 * https://bonaludo.com/2016/02/18/reversi-and-othello-two-different-games-do-you-know-their-different-rules/
 * https://www.yourturnmyturn.com/rules/reversi.php
 *
 */
public class MainActivity extends AppCompatActivity implements SettingsDialogFragment.SettingsListener {

    /*package*/ MyProps<SETTING_KEYS> _game_props = new MyProps<> ();

    /*package*/ TickerImpl _ticker;

    /**
     * I like to have at least *some* information displayed if the program
     * exists unexpectedly.
     */
    public MainActivity() {
        Thread.currentThread().setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread,
                                          Throwable ex) {
                MyLog.wtf(getApplicationContext(), "uncaughtException - ", ex);
            }
        });
    }

    /**
     * Called when the window is created.
     *
     * @param savedInstanceState null if this is a new instance; otherwise it
     *                           has instance data.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("MainActivity.onCreate (" + savedInstanceState + ")");

        // Create the layout
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        // Create a timer
        _ticker = new TickerImpl();

        // Define some actions for the buttons on the bottom
        ImageButton ib = findViewById(R.id.pause);

        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<pause> (" + view + ")");

                Snackbar.make(view, "<pause>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Both the way below and the way above are valid syntax. One can also
        // have MainActivity implement View.OnClickListener() as well. I like the
        // lower one if I will never use the variable and the action is simple.
        findViewById(R.id.quit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<quit> (" + view + ")");

                Snackbar.make(view, "<quit>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        findViewById(R.id.reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<reset> (" + view + ")");

                Snackbar.make(view, "<reset>", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        findViewById(R.id.help).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyLog.d("MainActivity.onClick<help> (" + view + ")");

                HelpDialogFragment hdf = HelpDialogFragment.newInstance();
                hdf.show(getSupportFragmentManager(), "help fragement");
            }
        });

        // Here's where putting everything in content_main.xml gets kinda ugly.
        // Because we don't know if R.id.pos1a through R.id.pos8h are in sequence
        // we can't use a loop. Which leaves us with the following code...
        BoardListener bl = new BoardListener();

        findViewById(R.id.posA1).setOnClickListener(bl);
        findViewById(R.id.posB1).setOnClickListener(bl);
        findViewById(R.id.posC1).setOnClickListener(bl);
        findViewById(R.id.posD1).setOnClickListener(bl);
        findViewById(R.id.posE1).setOnClickListener(bl);
        findViewById(R.id.posF1).setOnClickListener(bl);
        findViewById(R.id.posG1).setOnClickListener(bl);
        findViewById(R.id.posH1).setOnClickListener(bl);

        findViewById(R.id.posA2).setOnClickListener(bl);
        findViewById(R.id.posB2).setOnClickListener(bl);
        findViewById(R.id.posC2).setOnClickListener(bl);
        findViewById(R.id.posD2).setOnClickListener(bl);
        findViewById(R.id.posE2).setOnClickListener(bl);
        findViewById(R.id.posF2).setOnClickListener(bl);
        findViewById(R.id.posG2).setOnClickListener(bl);
        findViewById(R.id.posH2).setOnClickListener(bl);

        findViewById(R.id.posA3).setOnClickListener(bl);
        findViewById(R.id.posB3).setOnClickListener(bl);
        findViewById(R.id.posC3).setOnClickListener(bl);
        findViewById(R.id.posD3).setOnClickListener(bl);
        findViewById(R.id.posE3).setOnClickListener(bl);
        findViewById(R.id.posF3).setOnClickListener(bl);
        findViewById(R.id.posG3).setOnClickListener(bl);
        findViewById(R.id.posH3).setOnClickListener(bl);

        findViewById(R.id.posA4).setOnClickListener(bl);
        findViewById(R.id.posB4).setOnClickListener(bl);
        findViewById(R.id.posC4).setOnClickListener(bl);
        findViewById(R.id.posD4).setOnClickListener(bl);
        findViewById(R.id.posE4).setOnClickListener(bl);
        findViewById(R.id.posF4).setOnClickListener(bl);
        findViewById(R.id.posG4).setOnClickListener(bl);
        findViewById(R.id.posH4).setOnClickListener(bl);

        findViewById(R.id.posA5).setOnClickListener(bl);
        findViewById(R.id.posB5).setOnClickListener(bl);
        findViewById(R.id.posC5).setOnClickListener(bl);
        findViewById(R.id.posD5).setOnClickListener(bl);
        findViewById(R.id.posE5).setOnClickListener(bl);
        findViewById(R.id.posF5).setOnClickListener(bl);
        findViewById(R.id.posG5).setOnClickListener(bl);
        findViewById(R.id.posH5).setOnClickListener(bl);

        findViewById(R.id.posA6).setOnClickListener(bl);
        findViewById(R.id.posB6).setOnClickListener(bl);
        findViewById(R.id.posC6).setOnClickListener(bl);
        findViewById(R.id.posD6).setOnClickListener(bl);
        findViewById(R.id.posE6).setOnClickListener(bl);
        findViewById(R.id.posF6).setOnClickListener(bl);
        findViewById(R.id.posG6).setOnClickListener(bl);
        findViewById(R.id.posH6).setOnClickListener(bl);

        findViewById(R.id.posA7).setOnClickListener(bl);
        findViewById(R.id.posB7).setOnClickListener(bl);
        findViewById(R.id.posC7).setOnClickListener(bl);
        findViewById(R.id.posD7).setOnClickListener(bl);
        findViewById(R.id.posE7).setOnClickListener(bl);
        findViewById(R.id.posF7).setOnClickListener(bl);
        findViewById(R.id.posG7).setOnClickListener(bl);
        findViewById(R.id.posH7).setOnClickListener(bl);

        findViewById(R.id.posA8).setOnClickListener(bl);
        findViewById(R.id.posB8).setOnClickListener(bl);
        findViewById(R.id.posC8).setOnClickListener(bl);
        findViewById(R.id.posD8).setOnClickListener(bl);
        findViewById(R.id.posE8).setOnClickListener(bl);
        findViewById(R.id.posF8).setOnClickListener(bl);
        findViewById(R.id.posG8).setOnClickListener(bl);
        findViewById(R.id.posH8).setOnClickListener(bl);

        // For now we just hardcode things - permanent storage comes in a later version.
        _game_props.put (SETTING_KEYS.PLAYER1_TYPE, "H");
        _game_props.put (SETTING_KEYS.PLAYER1_NAME, "Mr. Human");
        _game_props.put (SETTING_KEYS.PLAYER1_ICON, "piece4a");
        _game_props.put (SETTING_KEYS.PLAYER2_TYPE, "C");
        _game_props.put (SETTING_KEYS.PLAYER2_NAME, getResources().getText(R.string.computer_player2_text).toString());
        _game_props.put (SETTING_KEYS.PLAYER2_ICON, "piece4b");
        _game_props.put (SETTING_KEYS.FORCE_CAPTURE, "false");
        _game_props.put (SETTING_KEYS.START_WITH_4, "false");
        _game_props.put (SETTING_KEYS.DAYS_UNTIL_PROMPT, "3");
        _game_props.put (SETTING_KEYS.LAUNCHES_UNTIL_PROMPT, "3");
        _game_props.put (SETTING_KEYS.PREF_NAME, "apprater");
        _game_props.put (SETTING_KEYS.DSA_KEY, "dontshowagain");
        _game_props.put (SETTING_KEYS.LAUNCH_COUNT_KEY, "launch_count");
        _game_props.put (SETTING_KEYS.DATE_KEY, "date_firstlaunch");
    }

    /**
     * Called when a fragment is attached as a child of this fragment.
     *
     * @param f Child fragment being attached.
     */
    @Override
    public void onAttachFragment (Fragment f) {
        MyLog.d ("MainActivity.onAttachFragment (" + f + ")");

        if (f instanceof SettingsDialogFragment) {
            ((SettingsDialogFragment) f).setMyListener(this);
        }
    }

    /**
     * Method called when the settings have changed.
     *
     * @param new_settings New settings if !null
     */
    public void getNewSettings(MyProps<SETTING_KEYS> new_settings) {
        MyLog.d ("MainActivity.getNewSettings (" + new_settings + ")");

        if (new_settings != null) {
            _game_props.clear();
            _game_props.putAll(new_settings);
        }
    }

    /**
     * Creates the options menu for the main activity.
     *
     * @param menu The instance selected.
     * @return true to display the menu; false otherwise.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MyLog.d("MainActivity.onCreateOptionsMenu (" + menu + ")");

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callAboutActivity(MenuItem item) {
        MyLog.d("MainActivity.callAboutActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), AboutActivity.class);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'AboutActivity'");
        }
    }

    /**
     * Invoked by the menu handler this is called when the user selects 'About'
     *
     * @param item The menu item that invoked this.
     */
    public void callRateItActivity(MenuItem item) {
        MyLog.d("MainActivity.callRateItActivity (" + item + ")");

        Intent intent = new Intent(getApplicationContext(), RateItActivity.class);

        intent.putExtra("PROPS", _game_props);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            MyLog.wtf(getApplicationContext(), "Unable to start 'RateItActivity'");
        }
    }

    /**
     * Handle action bar item clicks here. The action bar will
     * automatically handle clicks on the Home/Up button, so long
     * as you specify a parent activity in AndroidManifest.xml.
     *
     * @param item The menu item selected.
     * @return false to allow normal menu processing; true to consume it.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        MyLog.d("MainActivity.onOptionsItemSelected (" + item + ")");

        int id = item.getItemId();
        boolean rc;

        switch (id) {
            case R.id.app_settings:
                SettingsDialogFragment sdf = SettingsDialogFragment.newInstance(_game_props);
                // Seems the default for dialogs is no window title after API 23
                // so we have to 'fix' that by setting R.style.DialogFragment
                sdf.setStyle(DialogFragment.STYLE_NORMAL, R.style.DialogFragment);
                sdf.show(getSupportFragmentManager(), "settings_fragment");

                rc = true;
                break;

            case R.id.report_bug:
                // Create a popup dialog with an entry field and two buttons
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                EditText et = new EditText(getApplicationContext());

                alertDialogBuilder.setView(et);

                // Send the bug report
                alertDialogBuilder.setCancelable(false).setPositiveButton(getApplicationContext().getString(R.string.submit_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d ("MainActivity.onClick<ok> (" + dialog + "," + id + ")");

                        // Send a email bug report via email
                        Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                                "mailto",getApplicationContext().getString(R.string.bug_email_text), null));
                        String[] addresses = {getApplicationContext().getString(R.string.bug_email_text),};

                        intent.putExtra(Intent.EXTRA_SUBJECT, getApplicationContext().getString(R.string.email_subject_text));
                        intent.putExtra(Intent.EXTRA_TEXT, getApplicationContext().getString(R.string.email_body));
                        intent.putExtra(Intent.EXTRA_EMAIL, addresses); // Android 4.3 requires an additional field of email addresses

                        startActivity(Intent.createChooser(intent, getApplicationContext().getString(R.string.sending_email_text)));
                    }
                });

                // Close the report and return to program
                alertDialogBuilder.setCancelable(false).setNegativeButton(getApplicationContext().getString(R.string.cancel_button), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        MyLog.d ("MainActivity.onClick<cancel> (" + dialog + "," + id + ")");
                    }
                });

                // Show the dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                alertDialog.setTitle(R.string.describe_bug_text);
                alertDialog.show();

                rc = true;
                break;

            default:
                rc = super.onOptionsItemSelected(item);
                break;
        }

        return (rc);
    }
}
