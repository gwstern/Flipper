package com.gwstern.flipper3.help;

import androidx.lifecycle.ViewModelProviders;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.gwstern.flipper3.R;
import com.gwstern.flipper3.util.MyLog;

/**
 * This class handles all the stuff related to a single page (i.e. list of books, etc...)
 */
public class PageFragment extends Fragment {

    // Used to pass arguments between singleton creation and instance
    private static final String ARG_SECTION_NUMBER = "page_number";

    // The view model for a page
    private PageViewModel _page_view_model;

    /**
     * Create an instance of this page fragment.
     *
     * @param index Which page is being created.
     * @return The fragment for this page.
     */
    public static PageFragment newInstance(int index) {
        MyLog.d("PageFragment.newInstance (" + index + ")");

        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);

        PageFragment fragment = new PageFragment();
        fragment.setArguments(bundle);

        return fragment;
    }

    /**
     * Called when this instance is created.
     *
     * @param savedInstanceState Any previously saved state information.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MyLog.d("PageFragment.onCreate (" + savedInstanceState + ")");

        int page = getArguments().getInt(ARG_SECTION_NUMBER);

        _page_view_model = ViewModelProviders.of(this).get(PageViewModel.class);
        _page_view_model.setPage(getActivity().getResources(), page);
    }

    /**
     * Called when the fragment becomes visible.
     *
     * @param inflater The layout inflater to use.
     * @param container The container this is part of.
     * @param savedInstanceState Any previously saved state information.
     * @return The view for this fragment.
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        MyLog.d("PageFragment.onCreateView (" + inflater + "," + container + "," + savedInstanceState + ")");

        View root = null;

        root = inflater.inflate(R.layout.page_fragment, container, false);

        TextView tv = root.findViewById(R.id.help_text);

        tv.setText(_page_view_model.getHelp().getValue());

        return root;
    }
}