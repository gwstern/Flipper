package com.gwstern.flipper3;

import android.view.View;
import android.widget.ImageView;

import com.gwstern.flipper3.util.MyLog;

/**
 * Since clicking on a board position is the same regardless of what position
 * is clicked on we put that functionality here.
 */
public class BoardListener implements View.OnClickListener {
    /**
     * Called when a board position is clicked on.
     *
     * @param view The view (ImageView) of this board position.
     */
    @Override
    public void onClick(View view) {
        MyLog.d ("BoardListener.onClick (" + view + ")");

        ImageView iv = (ImageView)view;

        switch (SQUARE.map(iv.getTag().toString())) {
            case EMPTY:
                iv.setImageResource(R.drawable.light);
                iv.setTag(SQUARE.LIGHT);
                break;
            case LIGHT:
                iv.setImageResource(R.drawable.dark);
                iv.setTag(SQUARE.DARK);
                break;
            case DARK:
                iv.setImageResource(R.drawable.empty);
                iv.setTag(SQUARE.EMPTY);
                break;
            default:
                MyLog.wtf (null, "Unexpected board type");
                break;
        }
    }
}
